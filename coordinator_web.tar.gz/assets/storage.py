"""Tiny storage layer: browser localStorage when running in the web build, plain files otherwise."""
import os
import sys

IS_WEB = sys.platform == "emscripten"


def _ls():
    if not IS_WEB:
        return None
    try:
        import platform
        return platform.window.localStorage
    except Exception:
        return None


def _key(path):
    return os.path.basename(path)


def read_text(path):
    ls = _ls()
    if ls is not None:
        v = ls.getItem(_key(path))
        if v is None or str(v) in ("null", "undefined"):
            raise FileNotFoundError(_key(path))
        return str(v)
    with open(path, "r") as f:
        return f.read()


def write_text(path, text):
    ls = _ls()
    if ls is not None:
        ls.setItem(_key(path), text)
        return
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        f.write(text)
    os.replace(tmp, path)
