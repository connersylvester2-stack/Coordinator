CFB Coordinator Suite - browser / iPad edition
==============================================
Files (all must stay together in ONE folder, e.g. Coordinator_web):
  main.py  cfb_coordinator.py  cfb_engine.py  cfb_playbooks.py  storage.py  gfxcfg.py

Try it on your Mac first (desktop window, same code):
  python3 main.py

Build and test the browser version:
  1. pip install pygbag
  2. From the folder that CONTAINS Coordinator_web:   python3 -m pygbag Coordinator_web
     (first run downloads the web runtime; then open http://localhost:8000)
  3. To open it on your iPad on the same Wi-Fi:
       python3 -m pygbag --bind 0.0.0.0 Coordinator_web
     then in Safari on the iPad go to  http://<your-Mac-IP>:8000
     (Mac IP: System Settings > Wi-Fi > Details)
  4. To publish: python3 -m pygbag --build Coordinator_web
     Upload the contents of Coordinator_web/build/web to GitHub Pages (or itch.io),
     open the link on the iPad and use Share > Add to Home Screen.

Notes
  * Screen shape: the menu has a SCREEN SHAPE button (TABLET 1280x880 for an iPad in landscape, WIDE 1280x720
    for widescreen). Default in the browser is TABLET. Reload after changing it.
  * Sharpness: the main menu has a GRAPHICS button (FAST 1x / SHARP 1.5x / ULTRA 2x). Higher = crisper but slower.
    The choice is remembered by the browser; reload the page after changing it.
  * Use the iPad in landscape. Tap = click, drag a list to scroll.
  * Saves, the playbook and the season are stored inside the browser (localStorage).
    Clearing Safari website data erases them.
  * Not in the browser edition: sound effects and the HTML game-summary export.
  * pygbag options change between versions; if a command above is rejected,
    run  python3 -m pygbag --help  or see the pygbag documentation.
