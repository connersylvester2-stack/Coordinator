CFB Coordinator Suite - browser / iPad edition
==============================================
Files (all must stay together in ONE folder, e.g. Coordinator_web):
  main.py  cfb_coordinator.py  cfb_engine.py  cfb_playbooks.py  storage.py

Try it on your Mac first (desktop window, same code):
  python3 main.py

Build and test the browser version:
  1. pip install pygbag
  2. From the folder that CONTAINS Coordinator_web:   python3 -m pygbag Coordinator_web
     (first run downloads the web runtime; then open http://localhost:8000)
  3. To open it on your iPad on the same Wi-Fi:
       python3 -m pygbag --bind 0.0.0.0 Coordinator_web
     then in Safari on the iPad go to  http://<your-Mac-IP>:8000
     (Mac IP: System Settings > Wi-Fi > Details)
  4. To publish: python3 -m pygbag --build Coordinator_web
     Upload the contents of Coordinator_web/build/web to GitHub Pages (or itch.io),
     open the link on the iPad and use Share > Add to Home Screen.

Notes
  * Use the iPad in landscape. Tap = click, drag a list to scroll.
  * Saves, the playbook and the season are stored inside the browser (localStorage).
    Clearing Safari website data erases them.
  * Not in the browser edition: sound effects and the HTML game-summary export.
  * pygbag options change between versions; if a command above is rejected,
    run  python3 -m pygbag --help  or see the pygbag documentation.
