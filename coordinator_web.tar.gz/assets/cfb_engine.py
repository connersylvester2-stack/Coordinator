"""
Pure football logic for the CFB Coordinator Suite (no pygame):
matchups, play simulation, penalties, special teams, clock rules, grading and AI decisions.
"""
import copy
import math
import random

from cfb_playbooks import DEPTHS


# =============================================================================
# Helpers
# =============================================================================
def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def ordinal(n):
    return {1: "1st", 2: "2nd", 3: "3rd"}.get(n, f"{n}th")


def fmt_clock(sec):
    sec = max(0, math.ceil(sec - 1e-9))
    return f"{sec // 60}:{sec % 60:02d}"


def spot_text(yard):
    yard = int(yard)
    if yard < 50:
        return f"OWN {yard}"
    if yard == 50:
        return "50"
    return f"OPP {100 - yard}"


def dd_text(down, dist, yard):
    return f"{ordinal(down)} & {'Goal' if yard + dist >= 100 else dist}"


def other(who):
    return "AI" if who == "USER" else "USER"


# expected-points style position value (only used to compare penalty options)
def ep(yard):
    y = clamp(yard, 1, 99)
    return 0.00045 * y * y + 0.02 * y - 0.1


DOWN_PEN = {1: 0.0, 2: -0.55, 3: -1.2, 4: -2.0}


def posval(yard, down, dist):
    return ep(yard) + DOWN_PEN.get(down, -2.0) - 0.06 * (dist - 10)


# =============================================================================
# Play descriptions / matchups
# =============================================================================
STYLE_WORD = {"INSIDE": "inside", "OUTSIDE": "outside", "OPTION": "option", "DRAW": "draw",
              "QB_RUN": "quarterback", "TRICK": "trick"}


def play_style(meta):
    return meta.get("style") or ("INSIDE" if meta["is_run"] else "DROPBACK")


def kind_desc(meta):
    if "is_run" in meta:
        st = play_style(meta)
        if meta["is_run"]:
            return f"a {STYLE_WORD.get(st, 'inside')} run"
        return {"SCREEN": "a screen pass", "RPO": "an RPO", "TRICK": "a trick play",
                "HAIL_MARY": "a Hail Mary", "PLAY_ACTION": f"a play-action {meta['depth'].lower()} pass"
                }.get(st, f"a {meta['depth'].lower()} pass")
    return f"{meta['coverage'].lower()} coverage" + (" with a blitz" if meta["blitz"] else "")


def play_tag(meta):
    if "is_run" in meta:
        st = play_style(meta)
        if meta["is_run"]:
            return f"RUN - {st.replace('_', ' ')}"
        return f"PASS - {meta['depth']}" + ("" if st == "DROPBACK" else f" ({st.replace('_', ' ')})")
    return meta["coverage"] + (" + BLITZ" if meta["blitz"] else "") + f" | {meta.get('box', 'NORMAL')} BOX"


def short_tag(meta):
    if "is_run" in meta:
        if meta["is_run"]:
            return "R"
        return {"SCREEN": "S", "PLAY_ACTION": "A", "RPO": "O", "TRICK": "T", "HAIL_MARY": "H"}.get(play_style(meta), "P")
    return ("Z" if meta["coverage"] == "ZONE" else "M") + ("B" if meta["blitz"] else "")


PASS_MATCHUP = {
    ("SHORT", True, True): (1.0, "Quick short throws beat a man blitz before the pressure arrives."),
    ("SHORT", True, False): (0.6, "A short throw gets the ball out fast against zone pressure."),
    ("SHORT", False, True): (0.5, "Short crossing routes create picks and separation against man coverage."),
    ("SHORT", False, False): (-0.5, "Underneath zone defenders sit right on short routes."),
    ("MEDIUM", True, True): (0.8, "The man blitz leaves receivers one-on-one on intermediate routes."),
    ("MEDIUM", True, False): (0.2, "The zone blitz drops defenders into the intermediate windows."),
    ("MEDIUM", False, True): (0.1, "Intermediate routes can win against man, but defenders stay tight."),
    ("MEDIUM", False, False): (-0.2, "Intermediate routes must find soft spots in the zone."),
    ("DEEP", True, True): (1.5, "A deep shot against a man blitz leaves a receiver one-on-one with no safety help."),
    ("DEEP", True, False): (0.4, "The zone blitz keeps safeties deep, but the pressure shortens the QB's time."),
    ("DEEP", False, True): (0.4, "Man coverage can be stretched vertically with a deep route."),
    ("DEEP", False, False): (-0.7, "Zone coverage with safeties over the top takes away the deep shot."),
}
RUN_BOX = {
    "INSIDE": {"LIGHT": 0.6, "NORMAL": 0.0, "HEAVY": -0.6},
    "OUTSIDE": {"LIGHT": 0.3, "NORMAL": 0.0, "HEAVY": 0.2},
    "OPTION": {"LIGHT": 0.4, "NORMAL": 0.2, "HEAVY": 0.0},
    "DRAW": {"LIGHT": 0.4, "NORMAL": 0.1, "HEAVY": -0.4},
    "QB_RUN": {"LIGHT": 0.5, "NORMAL": 0.2, "HEAVY": -0.2},
    "TRICK": {"LIGHT": 0.0, "NORMAL": 0.0, "HEAVY": 0.0},
}
PA_BOX = {"HEAVY": 0.6, "NORMAL": 0.2, "LIGHT": -0.3}


def matchup(off, dfn):
    """(advantage for the offense, one-line reason). Roughly -1 .. +2."""
    blitz = dfn["blitz"]
    man = dfn["coverage"] == "MAN"
    box = dfn.get("box", "NORMAL")
    st = play_style(off)
    if off["is_run"]:
        if blitz:
            adv, why = (1.5, "The blitz can't stop a delayed draw.") if st == "DRAW" else \
                (1.0, "The blitz sent extra defenders upfield, which opens running lanes.")
        elif man:
            adv, why = 0.4, "Man coverage pulls defenders out of the box, helping the run game."
        else:
            adv, why = -0.2, "Disciplined zone defenders with no blitz flow to the ball against the run."
        b = RUN_BOX.get(st, RUN_BOX["INSIDE"])[box]
        if b > 0.1:
            why += f" The {box.lower()} box leaves room for {STYLE_WORD.get(st, 'this')} runs."
        elif b < -0.1:
            why += f" The {box.lower()} box has extra defenders waiting for {STYLE_WORD.get(st, 'this')} runs."
        return adv + b, why
    depth = off["depth"]
    base, why = PASS_MATCHUP[(depth, blitz, man)]
    if st == "SCREEN":
        adv = 1.1 if blitz else 0.4 if man else -0.2
        return adv, ("A screen turns an aggressive pass rush into blockers in space." if blitz
                     else "Screens need defenders to over-pursue; this look doesn't give them away.")
    if st == "RPO":
        adv = 0.3 + (0.3 if box == "HEAVY" else 0.0) - (0.2 if blitz else 0.0)
        return adv, "The RPO puts a conflict defender in a bind; the quarterback just reads him."
    if st == "PLAY_ACTION":
        return base + PA_BOX[box], why + f" The play fake works {'best' if box == 'HEAVY' else 'less'} against this box."
    if st == "TRICK":
        return 0.0, "Trick plays depend on surprise, not on the matchup."
    if st == "HAIL_MARY":
        return 0.0, "A Hail Mary is a prayer; the coverage hardly matters."
    return base, why


# =============================================================================
# Simulation
# =============================================================================
DEPTH_EXPECTED = {"SHORT": 6.0, "MEDIUM": 11.0, "DEEP": 24.0}


WEATHER = {
    "CLEAR": dict(comp=0.0, deep=0.0, fum=0.0, gain=0.0, fg=0.0, punt=0, desc="Clear skies"),
    "WIND": dict(comp=-0.03, deep=-0.07, fum=0.0, gain=0.0, fg=-0.12, punt=-3, desc="Gusty winds"),
    "RAIN": dict(comp=-0.05, deep=-0.03, fum=0.012, gain=-0.3, fg=-0.06, punt=-2, desc="Steady rain"),
    "SNOW": dict(comp=-0.08, deep=-0.05, fum=0.015, gain=-0.6, fg=-0.10, punt=-4, desc="Snow"),
}


def _g(attr, key, fallback):
    return attr.get(key, attr.get(fallback, 75))


def rating_edge(off, o, d):
    """Offense minus defense rating (in tens) using the position groups that matter for this play."""
    if off["is_run"]:
        orr = 0.45 * _g(o, "RB", "OFF") + 0.45 * _g(o, "OL", "OFF") + 0.10 * _g(o, "QB", "OFF")
        drr = 0.45 * _g(d, "DL", "DEF") + 0.40 * _g(d, "LB", "DEF") + 0.15 * _g(d, "DB", "DEF")
    else:
        orr = 0.45 * _g(o, "QB", "OFF") + 0.35 * _g(o, "WR", "OFF") + 0.20 * _g(o, "OL", "OFF")
        drr = 0.50 * _g(d, "DB", "DEF") + 0.25 * _g(d, "LB", "DEF") + 0.25 * _g(d, "DL", "DEF")
    return (orr - drr) / 10.0


def simulate_snap(off, dfn, o_attr, d_attr, env=None, geo=0.0):
    """geo: small bonus/penalty (about -0.5..+0.6) from where the players actually ended up on the field."""
    adv, _ = matchup(off, dfn)
    edge = rating_edge(off, o_attr, d_attr) + adv * 0.6 + geo
    rush = (_g(d_attr, "DL", "DEF") - _g(o_attr, "OL", "OFF")) / 10.0
    res = _simulate(off, dfn, o_attr, d_attr, edge, rush, dfn["blitz"], play_style(off), env or {})
    if res["outcome"] in ("RUN", "COMPLETE") and res["gain"] > 0 and random.random() < 0.10:
        res["oob"] = True
    return res


def _simulate(off, dfn, o_attr, d_attr, edge, rush, blitz, st, env):
    gmod = env.get("gain", 0.0)
    if st == "HAIL_MARY":
        r = random.random()
        if r < 0.07 + max(0, edge) * 0.01:
            return {"outcome": "COMPLETE", "gain": random.randint(40, 65)}
        if r < 0.25:
            return {"outcome": "INT", "gain": 0, "air": random.randint(35, 55)}
        return {"outcome": "INCOMPLETE", "gain": 0}
    if off["is_run"]:
        fum = 0.010 + max(0, d_attr["TAK"] - o_attr["BTK"]) / 1500.0 + (0.008 if st == "OPTION" else 0) + env.get("fum", 0.0)
        if random.random() < fum:
            return {"outcome": "FUMBLE", "gain": random.randint(-1, 4)}
        if st == "TRICK":
            if random.random() < 0.40:
                return {"outcome": "RUN", "gain": random.randint(12, 45)}
            return {"outcome": "RUN", "gain": -random.randint(2, 9)}
        gain = int(round(random.gauss(3.9 + edge * 1.5 + gmod, 3.2)))
        if random.random() < 0.07 + max(0, edge) * 0.03 + (0.02 if st in ("OUTSIDE", "OPTION") else 0):
            gain += random.randint(8, 30)
        return {"outcome": "RUN", "gain": max(gain, -4)}
    depth = off["depth"]
    air = {"SHORT": 5, "MEDIUM": 12, "DEEP": 25}[depth]
    hot = bool(off.get("hot"))
    cmod = env.get("comp", 0.0) + (env.get("deep", 0.0) if depth == "DEEP" else 0.0) + (0.06 if hot else 0.0)
    fmod = env.get("fum", 0.0)
    if st == "TRICK":
        r = random.random()
        if r < 0.40:
            return {"outcome": "COMPLETE", "gain": random.randint(18, 60) if depth == "DEEP" else random.randint(10, 35)}
        if r < 0.55:
            return {"outcome": "INT", "gain": 0, "air": air + random.randint(-2, 5)}
        return {"outcome": "INCOMPLETE", "gain": 0}
    if st == "SCREEN":
        if random.random() < 0.012:
            return {"outcome": "SACK", "gain": -random.randint(3, 8)}
        if random.random() < clamp(0.82 + edge * 0.06 + cmod, 0.4, 0.95):
            gain = int(round(random.gauss(5.0 + edge * 1.6 + gmod, 5.5)))
            if random.random() < 0.10 + max(0, edge) * 0.03:
                gain += random.randint(8, 28)
            return {"outcome": "COMPLETE", "gain": max(gain, -2)}
        return {"outcome": "INCOMPLETE", "gain": 0}
    d_idx = DEPTHS.index(depth)
    sack_p = 0.045 + (0.05 if blitz else 0) + d_idx * 0.01 - edge * 0.015 + rush * 0.012 + (0.02 if st == "PLAY_ACTION" else 0)
    sack_p = clamp(sack_p * (0.4 if hot else 1.0), 0.01, 0.2)
    if random.random() < sack_p:
        res = {"outcome": "SACK", "gain": -random.randint(3, 9)}
        if fmod and random.random() < fmod * 2:
            res = {"outcome": "FUMBLE", "gain": res["gain"]}
        return res
    comp = clamp({"SHORT": 0.72, "MEDIUM": 0.58, "DEEP": 0.38}[depth] + edge * 0.10
                 + (0.03 if st in ("PLAY_ACTION", "RPO") else 0) + cmod, 0.12, 0.90)
    int_p = clamp({"SHORT": 0.012, "MEDIUM": 0.02, "DEEP": 0.035}[depth] + max(0, -edge) * 0.015, 0.005, 0.12)
    r = random.random()
    if r < comp:
        sd = {"SHORT": 3.5, "MEDIUM": 5.0, "DEEP": 10.0}[depth]
        mean = DEPTH_EXPECTED[depth] + edge * 1.8 + gmod + (1.0 if st == "PLAY_ACTION" else 0)
        return {"outcome": "COMPLETE", "gain": max(1, int(round(random.gauss(mean, sd))))}
    if r < comp + int_p:
        return {"outcome": "INT", "gain": 0, "air": air + random.randint(-2, 5)}
    return {"outcome": "INCOMPLETE", "gain": 0}


def apply_audible(meta, kind):
    """Return an adjusted copy of a play after an audible, or None if the audible does nothing."""
    m = dict(meta)
    if kind == "HOT":
        if m.get("is_run", True) or m.get("hot") or m.get("style") in ("SCREEN", "HAIL_MARY"):
            return None
        m["depth"], m["hot"] = "SHORT", True
        return m
    if kind == "BLITZ":
        if "coverage" not in m or m["blitz"]:
            return None
        m["blitz"] = True
        return m
    if kind == "SHELL":
        if "coverage" not in m:
            return None
        m["coverage"] = "ZONE" if m["coverage"] == "MAN" else "MAN"
        return m
    return None


# =============================================================================
# Situation ratings (used by grading and by the AI)
# =============================================================================
def situation_bucket(down, dist):
    if down == 1:
        return "FIRST", "a balanced first-down situation"
    if dist <= 2:
        return "SHORT", "short yardage"
    if dist <= 5:
        return "MANAGEABLE", "a manageable distance"
    if dist <= 9:
        return "MEDIUM", "medium yardage"
    return "LONG", "long yardage"


OFF_TABLES = {
    "FIRST": {"RUN": 82, "SHORT": 78, "MEDIUM": 86, "DEEP": 70},
    "SHORT": {"RUN": 92, "SHORT": 72, "MEDIUM": 55, "DEEP": 38},
    "MANAGEABLE": {"RUN": 78, "SHORT": 86, "MEDIUM": 80, "DEEP": 55},
    "MEDIUM": {"RUN": 58, "SHORT": 70, "MEDIUM": 90, "DEEP": 62},
    "LONG": {"RUN": 42, "SHORT": 45, "MEDIUM": 88, "DEEP": 78},
}
DEF_TABLES = {
    "FIRST": {("ZONE", False): 85, ("ZONE", True): 76, ("MAN", False): 74, ("MAN", True): 68},
    "SHORT": {("ZONE", False): 60, ("ZONE", True): 85, ("MAN", False): 70, ("MAN", True): 92},
    "MANAGEABLE": {("ZONE", False): 82, ("ZONE", True): 80, ("MAN", False): 76, ("MAN", True): 72},
    "MEDIUM": {("ZONE", False): 86, ("ZONE", True): 80, ("MAN", False): 72, ("MAN", True): 66},
    "LONG": {("ZONE", False): 92, ("ZONE", True): 80, ("MAN", False): 62, ("MAN", True): 50},
}


def hail_ok(pre):
    q, mq = pre.get("quarter", 1), pre.get("maxq", 4)
    return (pre.get("clock", 999) <= 12 and q in (2, mq) and pre["yard"] >= 35
            and (q != mq or pre.get("lead", 0) < 0))


def offense_situation(meta, down, dist, yard, pre=None):
    bucket, desc = situation_bucket(down, dist)
    key = "RUN" if meta["is_run"] else meta["depth"]
    score = OFF_TABLES[bucket][key]
    st = play_style(meta)
    notes = []
    if down >= 3 and key == "SHORT" and dist > 7:
        score -= 10
        notes.append(f"Short routes average about {DEPTH_EXPECTED['SHORT']:.0f} yards, "
                     f"which rarely reaches {dist} yards to go.")
    if down >= 3 and key == "RUN" and dist >= 6:
        score -= 12
        notes.append("A run on a late down with this much to go is easy to defend.")
    if yard >= 88 and key == "DEEP":
        score -= 15
        notes.append("There is little room for a deep route in the red zone.")
    if bucket == "SHORT" and key == "RUN":
        notes.append("A run is the percentage call when only a couple of yards are needed.")
    if bucket == "LONG" and key == "MEDIUM":
        notes.append("Intermediate routes are the best way to threaten the sticks from long yardage.")
    if st == "TRICK":
        score = min(score, 60)
        notes.append("Trick plays are gambles; they work best as a surprise, not a staple.")
    if st == "HAIL_MARY":
        if pre is not None and hail_ok(pre):
            score = 95
            notes.append("Time is nearly gone and you need a big play, so the Hail Mary is the right desperation call.")
        else:
            score = 6
            notes.append("A Hail Mary this early just wastes a down; it only makes sense as time expires.")
    if st == "SCREEN" and bucket == "SHORT":
        score -= 10
        notes.append("A screen is a poor choice when the sticks are a yard or two away.")
    return clamp(score, 0, 100), notes, desc


def defense_situation(meta, down, dist, yard, pre=None):
    bucket, desc = situation_bucket(down, dist)
    score = DEF_TABLES[bucket][(meta["coverage"], meta["blitz"])]
    box = meta.get("box", "NORMAL")
    notes = []
    if bucket == "SHORT" and meta["blitz"]:
        notes.append("Pressure is the right idea when the offense only needs a couple of yards.")
    if bucket == "SHORT" and not meta["blitz"] and meta["coverage"] == "ZONE":
        notes.append("A passive zone gives the offense an easy short-yardage conversion.")
    if bucket == "LONG" and meta["coverage"] == "MAN" and meta["blitz"]:
        notes.append("Blitzing in man coverage on long yardage risks a big play over the top.")
    if bucket == "LONG" and meta["coverage"] == "ZONE" and not meta["blitz"]:
        notes.append("A deep zone shell is the safest way to defend long yardage.")
    if bucket == "SHORT" and box == "HEAVY":
        score += 8
        notes.append("A heavy box is what you want with the sticks this close.")
    if bucket == "LONG" and box == "HEAVY":
        score -= 6
        notes.append("A heavy box leaves you thin in coverage on long yardage.")
    if bucket == "LONG" and box == "LIGHT":
        score += 4
    if yard >= 90 and not meta["blitz"]:
        score -= 5
        notes.append("Near the goal line, sitting back with four rushers gives up easy scores.")
    return clamp(score, 0, 100), notes, desc


def offense_result_score(res, info, down, dist):
    pen = info.get("pen")
    if pen and info.get("pen_accepted"):
        return 12 if pen["team"] == "OFF" else 85
    out, gain = res["outcome"], info["gain"]
    if info["td"]:
        return 100
    if out in ("INT", "FUMBLE") or info["safety"]:
        return 0
    if out == "SACK":
        return 10
    if info["downs"]:
        return 5
    if gain >= dist:
        return min(100, 88 + (gain - dist))
    if down >= 3:
        return max(8, 20 + 30 * max(gain, 0) / max(dist, 1) - (10 if gain < 0 else 0))
    if gain < 0:
        return 15
    if gain == 0:
        return 30
    if gain <= 2:
        return 42
    if gain <= 4:
        return 58
    if gain <= 6:
        return 72
    if gain <= 9:
        return 84
    return 95


def defense_result_score(res, info, down, dist):
    pen = info.get("pen")
    if pen and info.get("pen_accepted"):
        return 88 if pen["team"] == "OFF" else 15
    out, gain = res["outcome"], info["gain"]
    if info["td"]:
        return 0
    if out in ("INT", "FUMBLE") or info["safety"] or info["downs"]:
        return 100
    if out == "SACK":
        return 92
    if gain >= dist:
        return max(5, 25 - (gain - dist))
    if down >= 3:
        return 80 + 15 * (1 - max(gain, 0) / max(dist, 1))
    if gain < 0:
        return 98
    if gain == 0:
        return 92
    if gain <= 2:
        return 82
    if gain <= 4:
        return 70
    if gain <= 6:
        return 58
    if gain <= 9:
        return 40
    return 22


def result_label(res, info):
    pen = info.get("pen")
    if pen and info.get("pen_accepted"):
        return f"an accepted penalty ({pen['name']})"
    out, gain = res["outcome"], info["gain"]
    if info["td"]:
        return "a touchdown" if not info.get("conv") else "a successful conversion"
    if info["safety"]:
        return "a safety"
    if out == "INT":
        return "an interception"
    if out == "FUMBLE":
        return "a lost fumble"
    if out == "SACK":
        return f"a sack for {-gain} yards lost"
    if out == "INCOMPLETE":
        return "an incomplete pass"
    if info["downs"]:
        return f"a {gain}-yard play that turned the ball over on downs" if not info.get("conv") else "a failed conversion"
    if info["first_down"]:
        return f"a {gain}-yard gain and a first down"
    return f"a {gain}-yard gain" if gain >= 0 else f"a {-gain}-yard loss"


GRADE_CURVE = (1.1, 5.0)


def overall_grade(sit, match, result):
    raw = 0.35 * sit + 0.30 * match + 0.35 * result
    return clamp(raw * GRADE_CURVE[0] + GRADE_CURVE[1], 0, 100)


def rating_word(score):
    if score >= 85:
        return "excellent"
    if score >= 70:
        return "good"
    if score >= 55:
        return "average"
    if score >= 40:
        return "poor"
    return "very poor"


GRADE_STEPS = [(97, "A+"), (93, "A"), (90, "A-"), (87, "B+"), (83, "B"), (80, "B-"),
               (77, "C+"), (73, "C"), (70, "C-"), (67, "D+"), (63, "D"), (60, "D-")]


def letter_grade(score):
    for cutoff, letter in GRADE_STEPS:
        if score >= cutoff:
            return letter
    return "F"


def grade_snap(user_side, pre, off_name, off, def_name, dfn, res, info, off_cat, def_cat):
    down, dist, yard = pre["down"], pre["dist"], pre["yard"]
    adv, reason = matchup(off, dfn)
    off_res = offense_result_score(res, info, down, dist)
    dd = dd_text(down, dist, yard) if not info.get("conv") else "a two-point try"
    analysis = []
    if user_side == "OFFENSE":
        sit, notes, desc = offense_situation(off, down, dist, yard, pre)
        match = clamp(50 + 25 * adv, 5, 100)
        result = off_res
        analysis.append(["SITUATION",
                         f"{dd} at {spot_text(yard)} is {desc}. You called {kind_desc(off)} ({off_name}), "
                         f"which rates as {rating_word(sit)} here ({sit:.0f}/100). " + " ".join(notes)])
        analysis.append(["OPPONENT'S CALL",
                         f"The defense answered with {def_name} ({kind_desc(dfn)}, {dfn.get('box', 'NORMAL').lower()} box). "
                         f"{reason} Matchup score {match:.0f}/100."])
    else:
        sit, notes, desc = defense_situation(dfn, down, dist, yard, pre)
        match = clamp(50 - 25 * adv, 5, 100)
        result = defense_result_score(res, info, down, dist)
        analysis.append(["SITUATION",
                         f"The offense faced {dd} at {spot_text(yard)} ({desc}). You called {def_name} "
                         f"({kind_desc(dfn)}, {dfn.get('box', 'NORMAL').lower()} box), which rates as "
                         f"{rating_word(sit)} here ({sit:.0f}/100). " + " ".join(notes)])
        edge_txt = "favored the offense" if adv > 0.3 else "favored the defense" if adv < -0.3 else "was close to even"
        analysis.append(["OPPONENT'S CALL",
                         f"The offense ran {off_name} ({kind_desc(off)}). The matchup {edge_txt}. "
                         f"{reason} Matchup score {match:.0f}/100."])
    pen = info.get("pen")
    if pen:
        who = "offense" if pen["team"] == "OFF" else "defense"
        analysis.append(["PENALTY",
                         f"{pen['name']} on the {who} ({pen['yards']} yards) was "
                         f"{'accepted' if info.get('pen_accepted') else 'declined'}."])
    analysis.append(["RESULT",
                     f"The play produced {result_label(res, info)} on {dd}. "
                     f"Result score {result:.0f}/100 ({rating_word(result)})."])
    overall = overall_grade(sit, match, result)

    def alt_score(meta):
        if user_side == "OFFENSE":
            s = offense_situation(meta, down, dist, yard, pre)[0]
            m = clamp(50 + 25 * matchup(meta, dfn)[0], 5, 100)
        else:
            s = defense_situation(meta, down, dist, yard, pre)[0]
            m = clamp(50 - 25 * matchup(off, meta)[0], 5, 100)
        return 0.5 * s + 0.5 * m

    catalog = off_cat if user_side == "OFFENSE" else def_cat
    chosen = off_name if user_side == "OFFENSE" else def_name
    opp_name, opp_meta = (def_name, dfn) if user_side == "OFFENSE" else (off_name, off)
    if catalog and chosen in catalog:
        best_name = max(catalog, key=lambda n: alt_score(catalog[n]))
        if best_name != chosen and alt_score(catalog[best_name]) - alt_score(catalog[chosen]) >= 8:
            analysis.append(["IN HINDSIGHT",
                             f"Against {opp_name} ({kind_desc(opp_meta)}) in this situation, {best_name} "
                             f"({kind_desc(catalog[best_name])}) would have scored higher in your playbook."])
        else:
            analysis.append(["IN HINDSIGHT", "Your call was at or near the best option in your playbook for this look."])
    return {"overall": overall, "sit": sit, "match": match, "result": result, "analysis": analysis}


# =============================================================================
# Clock / special-teams decisions (all work on a small context dict)
# =============================================================================
def fg_prob(dist):
    return clamp(1.0 - max(0, dist - 25) * 0.017, 0.05, 0.98)


XP_PROB = 0.945


def special_ctx(s, who):
    lead = (s.user_score - s.ai_score) if who == "USER" else (s.ai_score - s.user_score)
    return dict(lead=lead, quarter=s.quarter, maxq=s.max_quarters, clock=s.clock, running=s.clock_running,
                to_own=s.timeouts[who], to_opp=s.timeouts[other(who)], down=s.down, dist=s.distance,
                yard=s.yard_line, ot=bool(getattr(s, "ot", None)))


def final_period(c):
    return c["quarter"] >= c["maxq"]


def half_end(c):
    return c["quarter"] in (2, c["maxq"])


def kneel_wins(c):
    """Leading late and enough downs to run out the clock (each opponent timeout costs ~40s)."""
    return (final_period(c) and c["lead"] > 0 and c["down"] < 4
            and c["clock"] <= 40 * (4 - c["down"]) - 40 * c["to_opp"])


def spike_useful(c):
    return (c["running"] and c["clock"] <= 45 and c["down"] < 4 and half_end(c)
            and (c["lead"] <= 0 if final_period(c) else c["lead"] <= 7)
            and (c["to_own"] == 0 or c["clock"] <= 20))


def fourth_down_ideal(c):
    yard, dist = c["yard"], c["dist"]
    fg = 117 - yard
    if c.get("ot"):
        return "FG" if fg <= 55 else "GO"
    if final_period(c) and c["lead"] < 0 and c["clock"] < 300:
        if c["lead"] >= -3 and fg <= 52:
            return "FG"
        if c["lead"] < -3:
            return "GO"
    if half_end(c) and c["clock"] <= 8 and fg <= 56:
        return "FG"
    if dist <= 1 and yard >= 88:
        return "GO"
    if fg <= 52:
        return "FG"
    if dist <= 2 and yard >= 40:
        return "GO"
    return "PUNT"


def ai_special_choice(c):
    """What a coach does instead of snapping the ball: PUNT, FG, KNEEL, SPIKE or None."""
    if kneel_wins(c):
        return "KNEEL"
    if spike_useful(c):
        return "SPIKE"
    if c["down"] < 4 and half_end(c) and c["clock"] <= 8 and 117 - c["yard"] <= 56:
        return "FG"
    if c["down"] == 4:
        ideal = fourth_down_ideal(c)
        if ideal != "GO" and c["dist"] <= 3 and random.random() < 0.05:
            return None
        return None if ideal == "GO" else ideal
    return None


def kickoff_ideal(c):
    if final_period(c) and -16 <= c["lead"] < 0 and c["clock"] < 150:
        return "ONSIDE"
    if final_period(c) and c["lead"] > 0 and c["clock"] < 90:
        return "SQUIB"
    return "DEEP"


def conv_ideal(c):
    """c['lead'] already includes the touchdown (before the try)."""
    if final_period(c) and c["lead"] in (-2, -5, -10, -13, 5):
        return "TWO"
    return "XP"


def ai_conv_choice(c):
    ideal = conv_ideal(c)
    if ideal == "XP" and random.random() < 0.03:
        return "TWO"
    return ideal


def ai_wants_timeout(c):
    if c["to_own"] <= 0 or not c["running"] or not half_end(c) or c["clock"] > 120:
        return False
    return c["lead"] <= (0 if final_period(c) else 7)


def ai_hurry(c):
    return half_end(c) and c["clock"] <= 150 and (c["lead"] <= 0 if final_period(c) else c["lead"] <= 7)


SPECIAL_SCORE = {("FG", "FG"): 92, ("FG", "PUNT"): 35, ("GO", "FG"): 62, ("GO", "PUNT"): 50,
                 ("PUNT", "PUNT"): 90, ("PUNT", "FG"): 25}


def _special(sit, result, analysis, w_sit=0.6):
    overall = clamp((w_sit * sit + (1 - w_sit) * result) * GRADE_CURVE[0] + GRADE_CURVE[1], 0, 100)
    return {"overall": overall, "sit": sit, "match": None, "result": result, "analysis": analysis}


def grade_special(kind, c, info):
    """Grade a user decision that is not a regular snap (punt, kick, kneel, spike, kickoff, try)."""
    yard, dist = c["yard"], c["dist"]
    if kind in ("PUNT", "FG"):
        if c["down"] == 4:
            ideal = fourth_down_ideal(c)
            sit = SPECIAL_SCORE.get((ideal, kind), 50)
        else:
            ideal = "FG" if (half_end(c) and c["clock"] <= 8 and 117 - yard <= 56) else "GO"
            sit = 90 if ideal == kind else 22
        pretty = {"FG": "kick a field goal", "PUNT": "punt", "GO": "run a normal play"}
        if kind == "FG":
            result = 100 if info["made"] else 20
            res_txt = f"The {info['dist']}-yard kick was {'good' if info['made'] else 'missed'}."
        else:
            result = clamp(40 + (info["net"] - 30) * 2.5, 20, 95)
            res_txt = f"The punt netted {info['net']} yards."
        a = [["DECISION", f"{ordinal(c['down'])} & {dist} at {spot_text(yard)}: the percentage play is to "
                          f"{pretty[ideal]}. You chose to {pretty[kind]} (decision score {sit}/100)."],
             ["RESULT", f"{res_txt} Result score {result:.0f}/100."]]
        return _special(sit, result, a)
    if kind == "KNEEL":
        win = kneel_wins(c)
        sit = 95 if win else 55 if (final_period(c) and c["lead"] > 0) else 12
        txt = ("With a lead, this little time and few downs left, the kneel ends the game." if win else
               "You are ahead late, but the opponent still has enough time or timeouts to get the ball back; "
               "a kneel is premature." if sit == 55 else
               "A kneel only makes sense when you lead late. Otherwise it just burns a down.")
        return _special(sit, 90 if win else 55, [["DECISION", txt]], 0.7)
    if kind == "SPIKE":
        good = spike_useful(c)
        sit = 92 if good else 50 if (c["running"] and half_end(c) and c["clock"] <= 90) else 12
        txt = ("Spiking stops the clock while you are trying to score before time expires." if good else
               "Spiking costs a down; with timeouts left or time to spare, a real play was better." if sit == 50 else
               "There was no clock reason to spike here; it just threw away a down.")
        return _special(sit, 70, [["DECISION", txt]], 0.7)
    if kind in ("DEEP", "SQUIB", "ONSIDE"):
        ideal = kickoff_ideal(c)
        sit = 92 if kind == ideal else {("ONSIDE", "DEEP"): 40, ("ONSIDE", "SQUIB"): 45, ("DEEP", "SQUIB"): 62,
                                         ("DEEP", "ONSIDE"): 30, ("SQUIB", "DEEP"): 66, ("SQUIB", "ONSIDE"): 28
                                         }.get((ideal, kind), 55)
        if info.get("td"):
            result = 0
        elif kind == "ONSIDE":
            result = 100 if info.get("recovered") else 15
        else:
            result = clamp(100 - (info["recv_yard"] - 20) * 2.5, 20, 100)
        a = [["DECISION", f"The best kickoff here was {ideal.lower()} (you chose {kind.lower()}); decision score {sit}/100."],
             ["RESULT", f"{info['text']} Result score {result:.0f}/100."]]
        return _special(sit, result, a)
    if kind in ("XP", "TWO"):
        ideal = conv_ideal(c)
        sit = 92 if kind == ideal else 55
        result = 100 if info.get("made") else 10
        want = "go for two" if ideal == "TWO" else "kick the extra point"
        a = [["DECISION", f"By the standard conversion chart the right call was to {want}. "
                          f"You chose to {'go for two' if kind == 'TWO' else 'kick it'} (score {sit}/100)."],
             ["RESULT", f"The try was {'good' if info.get('made') else 'no good'}. Result score {result:.0f}/100."]]
        return _special(sit, result, a, 0.5)
    return None


DIFFICULTY = {  # rating bonus for the AI, how sharply it favors good calls, how much it adapts to you
    "ROOKIE": (-4, 1.3, 0.0), "VARSITY": (0, 3.0, 0.5), "ALL-AMERICAN": (3, 4.0, 1.0), "HEISMAN": (6, 5.0, 1.5)}


def adapt_bias(s, ai_side):
    """Counter-tendencies: the AI notices what you keep calling."""
    strength = DIFFICULTY.get(getattr(s, "difficulty", "VARSITY"), DIFFICULTY["VARSITY"])[2]
    h = getattr(s, "hist", {"off": [], "def": []})
    if strength <= 0:
        return {}
    if ai_side == "DEFENSE" and len(h["off"]) >= 4:
        rate = sum(h["off"][-12:]) / len(h["off"][-12:])
        return {"run_stop": (rate - 0.5) * 2 * strength}
    if ai_side == "OFFENSE" and len(h["def"]) >= 4:
        rate = sum(h["def"][-12:]) / len(h["def"][-12:])
        return {"vs_blitz": (rate - 0.3) * 2 * strength}
    return {}


def ai_pick_play(side, catalog, down, dist, yard, pre=None, bias=None, sharp=3.0):
    names = list(catalog)
    bias = bias or {}
    scorer = offense_situation if side == "OFFENSE" else defense_situation
    weights = []
    for n in names:
        meta = catalog[n]
        w = (scorer(meta, down, dist, yard, pre)[0] / 100.0) ** sharp + 0.02
        if side == "OFFENSE":
            rb = bias.get("run_bias", 0.0)
            w *= (1 + rb) if meta["is_run"] else max(0.15, 1 - rb * 0.6)
            vb = bias.get("vs_blitz", 0.0)
            if vb:
                st = play_style(meta)
                if st in ("SCREEN", "DRAW") or (not meta["is_run"] and meta["depth"] == "SHORT"):
                    w *= max(0.2, 1 + vb)
                elif not meta["is_run"] and meta["depth"] == "DEEP":
                    w *= max(0.2, 1 - 0.5 * vb)
        else:
            rs = bias.get("run_stop", 0.0)
            box = meta.get("box", "NORMAL")
            if rs and box == "HEAVY":
                w *= max(0.2, 1 + rs)
            elif rs and box == "LIGHT":
                w *= max(0.2, 1 - rs)
            if meta["blitz"]:
                w *= max(0.15, 1 + bias.get("blitz", 0.0) - 0.3 * min(0.0, rs))
            if meta["coverage"] == "MAN":
                w *= max(0.15, 1 + bias.get("man", 0.0))
        weights.append(max(w, 0.001))
    return random.choices(names, weights)[0]


# =============================================================================
# Penalties
# =============================================================================
PRESNAP = [("False Start", "OFF", 5, 0.40), ("Illegal Formation", "OFF", 5, 0.08), ("Illegal Motion", "OFF", 5, 0.06),
           ("Too Many Men on the Field (Offense)", "OFF", 5, 0.04), ("Offside", "DEF", 5, 0.24),
           ("Neutral Zone Infraction", "DEF", 5, 0.10), ("Encroachment", "DEF", 5, 0.05),
           ("Too Many Men on the Field (Defense)", "DEF", 5, 0.03)]
# name, team, yards (None = spot of foul, max 15), auto first down, loss of down, applies to, weight
LIVE = [("Offensive Holding", "OFF", 10, False, False, "BOTH", 3.0),
        ("Illegal Block in the Back", "OFF", 10, False, False, "BOTH", 0.7),
        ("Offensive Pass Interference", "OFF", 15, False, False, "PASS", 0.6),
        ("Ineligible Man Downfield", "OFF", 5, False, False, "PASS", 0.4),
        ("Intentional Grounding", "OFF", 10, False, True, "INC", 0.4),
        ("Defensive Holding", "DEF", 5, True, False, "BOTH", 0.8),
        ("Defensive Pass Interference", "DEF", None, True, False, "PASS", 1.2),
        ("Illegal Contact", "DEF", 5, True, False, "PASS", 0.4),
        ("Roughing the Passer", "DEF", 15, True, False, "PASS", 0.7),
        ("Face Mask", "DEF", 15, True, False, "BOTH", 0.5),
        ("Unnecessary Roughness", "DEF", 15, True, False, "BOTH", 0.5),
        ("Targeting", "DEF", 15, True, False, "BOTH", 0.15)]


PEN_MULT = {"NONE": 0.0, "BLIND": 0.15, "BAD": 0.45, "STICKLERS": 0.75}


def pen_mult(s):
    return PEN_MULT.get(getattr(s, "penalty_level", "STICKLERS"), 0.75)


def roll_presnap(s):
    crowd = 1.25 if getattr(s, "home", None) == other(s.possession) else 1.0
    if s.conv or random.random() > 0.042 * pen_mult(s) * crowd:
        return None
    name, team, yds, _ = random.choices(PRESNAP, weights=[p[3] for p in PRESNAP])[0]
    return {"name": name, "team": team, "yards": yds, "auto_first": False, "loss_down": False, "presnap": True}


def roll_live(s, off, dfn, res):
    if s.conv or random.random() > (0.055 + (0.015 if dfn["blitz"] else 0)) * pen_mult(s):
        return None
    is_pass = not off["is_run"]
    out = res["outcome"]
    cands, weights = [], []
    for name, team, yds, auto, loss, applies, w in LIVE:
        if applies == "PASS" and not is_pass:
            continue
        if applies == "INC" and out != "INCOMPLETE":
            continue
        if name == "Roughing the Passer" and out == "INT":
            continue
        if dfn["coverage"] == "MAN" and name in ("Defensive Pass Interference", "Illegal Contact"):
            w *= 1.5
        if dfn["blitz"] and name in ("Roughing the Passer", "Offensive Holding"):
            w *= 1.8
        cands.append((name, team, yds, auto, loss))
        weights.append(w)
    name, team, yds, auto, loss = random.choices(cands, weights=weights)[0]
    if yds is None:
        yds = {"SHORT": 6, "MEDIUM": 13, "DEEP": 15}.get(off.get("depth", "SHORT"), 8)
    return {"name": name, "team": team, "yards": yds, "auto_first": auto, "loss_down": loss, "presnap": False}


# =============================================================================
# Game session (everything that must be saved lives here)
# =============================================================================
TRACKED = ("RB", "WR", "OL", "DL")   # position groups that tire and can lose a starter


class Session:
    def __init__(self, user_team, ai_team, role, qtr_mins, structure, pc_speed=1.0, user_book=None, ai_book=None,
                 penalty_level="STICKLERS", difficulty="VARSITY", weather="CLEAR", home=None):
        self.penalty_level = penalty_level   # NONE | BLIND | BAD | STICKLERS
        self.difficulty = difficulty         # ROOKIE | VARSITY | ALL-AMERICAN | HEISMAN
        self.weather = weather               # CLEAR | WIND | RAIN | SNOW
        self.home = home                     # "USER", "AI" or None (neutral site)
        self.stamina = {w: {g: 100.0 for g in TRACKED} for w in ("USER", "AI")}
        self.injured = {"USER": [], "AI": []}
        self.subs_left = {"USER": 4, "AI": 4}
        self.hist = {"off": [], "def": []}   # what the user keeps calling (the AI adapts to it)
        self.ot = None                       # overtime state
        self.ot_msg = ""
        self.user_team = user_team
        self.ai_team = ai_team
        self.role = role
        self.qtr_mins = qtr_mins
        self.structure = structure
        self.pc_speed = pc_speed            # play-clock speed: 1.0 real time, 2.0 fast, 0 = off
        self.user_book = user_book or {"OFFENSE": None, "DEFENSE": None}
        self.ai_book = ai_book or {"OFFENSE": None, "DEFENSE": None}
        self.user_score = 0
        self.ai_score = 0
        self.quarter = 1
        self.clock = float(qtr_mins * 60)
        self.clock_running = False
        self.pc_next = 25                   # play clock for the next snap (40 normal, 25 after a stoppage)
        self.timeouts = {"USER": 3, "AI": 3}
        self.yard_line = 25
        self.down = 1
        self.distance = 10
        self.possession = "USER"
        self.opening_receiver = random.choice(["USER", "AI"])
        self.pending = {"type": "KICKOFF", "kicker": other(self.opening_receiver), "from": 35, "reason": "OPENING"}
        self.conv = False
        self.game_over = False
        self.ended_early = False
        self.stats = {"plays": 0, "yards": 0, "third_att": 0, "third_conv": 0, "tds": 0, "giveaways": 0,
                      "takeaways": 0, "pen": 0, "pen_yds": 0, "opp_pen": 0, "opp_pen_yds": 0}
        self.log = []

    @classmethod
    def from_dict(cls, d):
        s = cls(d["user_team"], d["ai_team"], d["role"], d["qtr_mins"], d["structure"])
        s.__dict__.update(d)
        for k, v in cls("a", "b", "HC", 1, "FULL").stats.items():
            s.stats.setdefault(k, v)
        return s

    # ---------------------------------------------------------------- basics
    @property
    def max_quarters(self):
        return 1 if self.structure == "1_QTR" else 2 if self.structure == "1ST_HALF" else 4

    def team(self, who):
        return self.user_team if who == "USER" else self.ai_team

    def score_of(self, who):
        return self.user_score if who == "USER" else self.ai_score

    def add_score(self, who, pts):
        if who == "USER":
            self.user_score += pts
        else:
            self.ai_score += pts

    def flip(self, new_yard):
        self.possession = other(self.possession)
        self.yard_line = int(clamp(new_yard, 1, 99))
        self.down = 1
        self.distance = min(10, 100 - self.yard_line)

    def in_last_two(self):
        return self.quarter in (2, self.max_quarters) and self.clock <= 120

    def score_td(self, who):
        self.add_score(who, 6)
        self.possession = who
        self.pending = {"type": "CONV", "team": who}
        if who == "USER":
            self.stats["tds"] += 1

    def sim_copy(self):
        c = copy.copy(self)
        c.log = []
        c.stats = dict(self.stats)
        c.timeouts = dict(self.timeouts)
        c.pending = copy.deepcopy(self.pending)
        c.ot = copy.deepcopy(self.ot)
        c.stamina = copy.deepcopy(self.stamina)
        return c

    def value_for(self, who):
        v = self.score_of(who) - self.score_of(other(who))
        p = self.pending
        if p and p.get("type") == "CONV":
            return v + (XP_PROB if p["team"] == who else -XP_PROB)
        if p and p.get("type") == "KICKOFF":
            return v + (-0.7 if p["kicker"] == who else 0.7)
        pv = posval(self.yard_line, self.down, self.distance)
        return v + (pv if self.possession == who else -pv)

    # ------------------------------------------------------------- period end
    def period_label(self):
        return f"OT{self.ot['n']}" if self.ot else f"Q{self.quarter}"

    def clock_text(self):
        return "OT" if self.ot else fmt_clock(self.clock)

    def env(self):
        return WEATHER.get(self.weather, WEATHER["CLEAR"])

    def fg_chance(self, dist):
        return clamp(fg_prob(dist) + self.env()["fg"], 0.02, 0.98)

    # ----------------------------------------------------- fatigue / injuries / subs
    def fatigue_adj(self, who, group):
        """Rating change (<= 0) for a position group from fatigue and injury."""
        adj = -(100.0 - self.stamina[who].get(group, 100.0)) * 0.12
        if group in self.injured[who]:
            adj -= 5.0
        return adj

    def wear(self, off_meta, dfn):
        o = self.possession
        so, sd = self.stamina[o], self.stamina[other(o)]
        run = off_meta["is_run"]
        so["RB"] -= 3.5 if run else 0.8
        so["WR"] -= 0.8 if run else 2.6
        so["OL"] -= 1.6
        sd["DL"] -= 2.0 + (1.5 if dfn["blitz"] else 0.0)
        for g in ("RB", "WR", "OL"):        # the side that is not on offense catches a breather
            sd[g] += 2.0
        so["DL"] += 2.0
        for tbl in (so, sd):
            for g in tbl:
                tbl[g] = clamp(tbl[g], 0.0, 100.0)

    def rest(self, amount, who=None):
        for w in ([who] if who else ["USER", "AI"]):
            for g in TRACKED:
                self.stamina[w][g] = clamp(self.stamina[w][g] + amount, 0.0, 100.0)

    def sub(self, who, group):
        if self.subs_left[who] <= 0:
            return ""
        self.subs_left[who] -= 1
        self.stamina[who][group] = clamp(max(self.stamina[who][group] + 45.0, 80.0), 0.0, 100.0)
        return f"{self.team(who)} rotates fresh legs into the {group} group ({self.subs_left[who]} rotations left)."

    def roll_injury(self):
        if random.random() > 0.006:
            return ""
        who = random.choice(["USER", "AI"])
        group = random.choice(TRACKED)
        if group in self.injured[who]:
            return ""
        self.injured[who].append(group)
        return f"INJURY: {self.team(who)} loses a starter in the {group} group for the rest of the game."

    # ---------------------------------------------------------------- overtime
    def start_ot(self):
        first = random.choice(["USER", "AI"])
        self.ot = {"n": 1, "order": [first, other(first)], "idx": 0,
                   "start": {"USER": self.user_score, "AI": self.ai_score}}
        self.clock, self.clock_running = 3600.0, False
        self.pending = {"type": "OT_START", "team": first}
        return (f"REGULATION ENDS TIED! OVERTIME: {self.team(first)} gets the ball first at the opponent's 25. "
                "Each team gets one possession per period.")

    def start_ot_series(self, p):
        self.possession = p["team"]
        self.yard_line, self.down, self.distance = 75, 1, 10
        self.conv, self.pending = False, None
        self.clock_running, self.pc_next = False, 25

    def _ot_end_series(self):
        ot = self.ot
        ot["idx"] += 1
        self.pending = None
        if ot["idx"] == 1:
            nxt = ot["order"][1]
            self.pending = {"type": "OT_START", "team": nxt}
            self.ot_msg = f"{self.team(ot['order'][0])}'s possession is over. {self.team(nxt)} gets the ball at the 25."
            return
        du = self.user_score - ot["start"]["USER"]
        da = self.ai_score - ot["start"]["AI"]
        if du != da:
            self.game_over = True
            self.ot_msg = "END OF GAME."
        else:
            ot["n"] += 1
            ot["order"].reverse()
            ot["idx"] = 0
            ot["start"] = {"USER": self.user_score, "AI": self.ai_score}
            self.pending = {"type": "OT_START", "team": ot["order"][0]}
            extra = " From here every score must be a two-point try." if ot["n"] >= 3 else ""
            self.ot_msg = f"Still tied! Overtime {ot['n']}.{extra}"

    def check_period_end(self):
        if self.ot_msg:
            msg, self.ot_msg = self.ot_msg, ""
            return msg
        if self.game_over or self.ot or self.clock > 0:
            return ""
        saved = self.pending if (self.pending and self.pending["type"] == "KICKOFF") else None
        self.pending = None
        if self.quarter >= self.max_quarters:
            if self.user_score == self.ai_score:
                return self.start_ot()
            self.game_over = True
            return "END OF GAME."
        self.quarter += 1
        self.clock = float(self.qtr_mins * 60)
        self.clock_running = False
        if self.quarter == 3 and self.max_quarters == 4:
            self.timeouts = {"USER": 3, "AI": 3}
            self.subs_left = {"USER": 4, "AI": 4}
            self.rest(40.0)
            self.pending = {"type": "KICKOFF", "kicker": self.opening_receiver, "from": 35, "reason": "HALF"}
            return "HALFTIME. Timeouts reset and everyone is rested; the second-half kickoff is next."
        self.rest(10.0)
        self.pending = saved
        return f"End of quarter {self.quarter - 1}."

    # ------------------------------------------------------------ scrimmage plays
    def apply_offense(self, res):
        out, gain = res["outcome"], res["gain"]
        off_who = self.possession
        def_who = other(off_who)
        off_team, def_team = self.team(off_who), self.team(def_who)
        start, down, dist = self.yard_line, self.down, self.distance
        info = {"td": False, "turnover": False, "first_down": False, "safety": False, "downs": False, "gain": gain}
        dur = {"INCOMPLETE": (4, 6), "RUN": (5, 8), "COMPLETE": (6, 9), "SACK": (5, 8)}.get(out, (5, 9))
        self.clock = max(0.0, self.clock - random.randint(*dur))
        running = out != "INCOMPLETE" and not (res.get("oob") and self.in_last_two())
        pc = 40
        if out == "INT":
            spot = start + res.get("air", 10)
            info.update(turnover=True, gain=0)
            if spot >= 100:
                new_yard = 20
                text = f"INTERCEPTED in the end zone! Touchback - {def_team} ball at OWN 20."
            else:
                new_yard = 100 - spot
                text = f"INTERCEPTED! {def_team} takes over at {spot_text(new_yard)}."
            self.flip(new_yard)
            running, pc = False, 25
        elif out == "FUMBLE":
            spot = int(clamp(start + gain, 1, 99))
            info.update(turnover=True, gain=gain)
            text = f"FUMBLE! {def_team} recovers and takes over at {spot_text(100 - spot)}."
            self.flip(100 - spot)
            running, pc = False, 25
        else:
            if out == "RUN":
                base = (f"{off_team} runs for {gain} yards." if gain > 0 else
                        "No gain on the run." if gain == 0 else f"Run stuffed for a loss of {-gain}.")
            elif out == "COMPLETE":
                base = f"Pass complete for {gain} yards."
            elif out == "SACK":
                base = f"SACKED! Loss of {-gain} yards."
            else:
                base = "Incomplete pass."
            new_yard = start + gain
            if new_yard >= 100:
                info.update(td=True, gain=100 - start)
                text = f"TOUCHDOWN {off_team}!! (+6 points)"
                self.score_td(off_who)
                running, pc = False, 25
            elif new_yard <= 0:
                info.update(safety=True, gain=-start)
                text = f"{base}\nSAFETY! {def_team} gets 2 points and the ball after the free kick."
                self.add_score(def_who, 2)
                self.pending = {"type": "KICKOFF", "kicker": off_who, "from": 20, "reason": "SAFETY"}
                running, pc = False, 25
            elif gain >= dist:
                info["first_down"] = True
                self.yard_line = new_yard
                self.down = 1
                self.distance = min(10, 100 - new_yard)
                text = f"{base}\nFIRST DOWN!"
            else:
                self.yard_line = new_yard
                self.distance = dist - gain
                self.down += 1
                if self.down > 4:
                    info["downs"] = True
                    text = f"{base}\nTURNOVER ON DOWNS! {def_team} takes over."
                    self.flip(100 - new_yard)
                    running, pc = False, 25
                else:
                    text = f"{base}\n{dd_text(self.down, self.distance, self.yard_line)} at {spot_text(self.yard_line)}."
        self.clock_running, self.pc_next = running, pc
        if self.ot and (info["turnover"] or info["safety"] or info["downs"]):
            self._ot_end_series()
        if off_who == "USER":
            st = self.stats
            st["plays"] += 1
            st["yards"] += info["gain"]
            if down == 3:
                st["third_att"] += 1
                if info["first_down"] or info["td"]:
                    st["third_conv"] += 1
            if out in ("INT", "FUMBLE"):
                st["giveaways"] += 1
        elif out in ("INT", "FUMBLE"):
            self.stats["takeaways"] += 1
        return text, info

    def apply_penalty(self, pen):
        off_who = self.possession
        committer = off_who if pen["team"] == "OFF" else other(off_who)
        yds = pen["yards"]
        if pen["team"] == "OFF":
            yds = min(yds, max(1, self.yard_line // 2))
            self.yard_line -= yds
            self.distance += yds
            if pen.get("loss_down"):
                self.down += 1
            tail = f"{ordinal(min(self.down, 4))} & {self.distance}"
        else:
            yds = min(yds, (100 - self.yard_line) // 2)
            self.yard_line += yds
            self.distance -= yds
            if pen.get("auto_first") or self.distance <= 0:
                self.down = 1
                self.distance = min(10, 100 - self.yard_line)
                tail = "automatic first down"
            else:
                tail = f"{ordinal(self.down)} & {self.distance}"
        text = f"FLAG! {pen['name']} on {self.team(committer)}, {yds} yards. "
        info = {"td": False, "turnover": False, "first_down": False, "safety": False, "downs": False,
                "gain": -yds if pen["team"] == "OFF" else yds, "pen": dict(pen, yards=yds), "pen_accepted": True}
        if self.down > 4:
            info["downs"] = True
            text += f"Turnover on downs, {self.team(other(off_who))} ball."
            self.flip(100 - self.yard_line)
            if self.ot:
                self._ot_end_series()
        else:
            text += f"Now {tail} at {spot_text(self.yard_line)}."
        self.clock_running, self.pc_next = False, 25
        key = ("pen", "pen_yds") if committer == "USER" else ("opp_pen", "opp_pen_yds")
        self.stats[key[0]] += 1
        self.stats[key[1]] += yds
        return text, info

    def decide_penalty(self, pen, res):
        """True when the team that was fouled should accept (the better of the two outcomes for them)."""
        off_who = self.possession
        a = self.sim_copy()
        a.apply_offense(res)
        b = self.sim_copy()
        b.apply_penalty(pen)
        va, vb = a.value_for(off_who), b.value_for(off_who)
        return (vb < va) if pen["team"] == "OFF" else (vb > va)

    # --------------------------------------------------------------- two-point try
    def start_two_point(self):
        self.possession = self.pending["team"]
        self.yard_line, self.down, self.distance = 97, 1, 3
        self.conv = True
        self.pending = None

    def apply_two_point(self, res):
        who = self.possession
        ok = res["outcome"] in ("RUN", "COMPLETE") and res["gain"] >= 3
        if ok:
            self.add_score(who, 2)
        self.conv = False
        self.pending = {"type": "KICKOFF", "kicker": who, "from": 35, "reason": "AFTER_SCORE"}
        if self.ot:
            self._ot_end_series()
        text = "TWO-POINT CONVERSION IS GOOD! (+2)" if ok else "The two-point try is NO GOOD."
        info = {"td": ok, "turnover": False, "first_down": False, "safety": False, "downs": not ok,
                "gain": clamp(res["gain"], -9, 3), "conv": True, "made": ok}
        return text, info

    def extra_point(self):
        who = self.pending["team"]
        made = random.random() < XP_PROB
        if made:
            self.add_score(who, 1)
        self.possession = who
        self.pending = {"type": "KICKOFF", "kicker": who, "from": 35, "reason": "AFTER_SCORE"}
        if self.ot:
            self._ot_end_series()
        text = f"{self.team(who)}'s extra point is {'GOOD (+1)' if made else 'NO GOOD'}."
        return text, {"kind": "XP", "made": made, "gain": 0}

    # ---------------------------------------------------------------- kicking game
    def start_kickoff(self, p):
        self.possession = p["kicker"]
        self.yard_line = p.get("from", 35)
        self.down, self.distance, self.conv = 1, 10, False

    def kickoff(self, kind):
        p = self.pending or {}
        kicker = self.possession
        recv = other(kicker)
        kteam, rteam = self.team(kicker), self.team(recv)
        free = p.get("from", 35) < 30
        self.pending = None
        self.clock_running, self.pc_next = False, 25
        info = {"kind": "KICKOFF", "sub": kind, "gain": 0, "td": False, "recovered": False, "recv_yard": 25}
        if kind == "ONSIDE":
            if random.random() < 0.12:
                self.yard_line = 47
                self.down, self.distance = 1, 10
                info.update(recovered=True, recv_yard=53)
                text = f"ONSIDE KICK RECOVERED! {kteam} keeps the ball at {spot_text(47)}."
            else:
                info["recv_yard"] = 53
                text = f"The onside kick fails. {rteam} takes over at {spot_text(53)}."
                self.flip(53)
        elif free:
            dist = clamp(random.gauss(48, 6), 35, 62)
            ry = int(clamp(round(80 - dist + max(0, random.gauss(7, 5))), 20, 60))
            text = f"{kteam}'s free kick is returned to {spot_text(ry)} by {rteam}."
            info["recv_yard"] = ry
            self.flip(ry)
        elif kind == "SQUIB":
            ry = int(clamp(round(random.gauss(35, 5)), 22, 50))
            text = f"Squib kick! {rteam} fields it and starts at {spot_text(ry)}."
            info["recv_yard"] = ry
            self.flip(ry)
        else:
            r = random.random()
            if r < 0.58:
                text = f"Kickoff into the end zone - touchback. {rteam} starts at OWN 30."
                info["recv_yard"] = 30
                self.flip(30)
            elif random.random() < 0.012:
                text = f"KICKOFF RETURN TOUCHDOWN {rteam}!! (+6 points)"
                info.update(td=True, recv_yard=99)
                self.possession = recv
                self.score_td(recv)
            elif random.random() < 0.30:
                text = f"Fair catch inside the 25 - {rteam} starts at OWN 25."
                info["recv_yard"] = 25
                self.flip(25)
            else:
                ry = int(clamp(round(random.gauss(25, 6)), 8, 48))
                text = f"{rteam} returns the kick to {spot_text(ry)}."
                info["recv_yard"] = ry
                self.flip(ry)
        info["text"] = text
        return text, info

    def punt(self):
        who = self.possession
        team, rteam = self.team(who), self.team(other(who))
        start = self.yard_line
        net = int(clamp(random.gauss(42, 6) + self.env()["punt"], 20, 60))
        self.clock = max(0.0, self.clock - random.randint(6, 10))
        self.clock_running, self.pc_next = False, 25
        info = {"kind": "PUNT", "gain": 0, "td": False}
        if random.random() < 0.008:
            self.possession = other(who)
            text = f"{team} punts and {rteam} takes it back for a TOUCHDOWN!! (+6 points)"
            info.update(td=True, net=0)
            self.score_td(other(who))
        elif start + net >= 100:
            info["net"] = 80 - start
            text = f"{team} punts into the end zone - touchback. {rteam} ball at OWN 20."
            self.flip(20)
        else:
            info["net"] = net
            new_yard = 100 - (start + net)
            text = f"{team} punts {net} yards. {rteam} takes over at {spot_text(new_yard)}."
            self.flip(new_yard)
        if self.ot:
            self._ot_end_series()
        return text, info

    def field_goal(self):
        who = self.possession
        team, rteam = self.team(who), self.team(other(who))
        start = self.yard_line
        dist = 117 - start
        made = random.random() < self.fg_chance(dist)
        self.clock = max(0.0, self.clock - random.randint(3, 6))
        self.clock_running, self.pc_next = False, 25
        if made:
            self.add_score(who, 3)
            text = f"{team} kicks a {dist}-yard FIELD GOAL - it's GOOD! (+3 points)"
            self.pending = {"type": "KICKOFF", "kicker": who, "from": 35, "reason": "AFTER_SCORE"}
        else:
            new_yard = max(20, 107 - start)
            text = f"{team}'s {dist}-yard field goal is NO GOOD. {rteam} takes over at {spot_text(new_yard)}."
            self.flip(new_yard)
        if self.ot:
            self._ot_end_series()
        return text, {"kind": "FG", "made": made, "dist": dist, "gain": 0}

    # --------------------------------------------------------------- clock plays
    def kneel(self):
        lost = random.randint(1, 2)
        if self.yard_line - lost < 1:
            lost = 0
        self.yard_line -= lost
        self.distance += lost
        self.down += 1
        self.clock = max(0.0, self.clock - random.randint(1, 2))
        self.clock_running, self.pc_next = True, 40
        return (f"{self.team(self.possession)} takes a knee."
                + (f" Loss of {lost}." if lost else ""), {"kind": "KNEEL", "gain": -lost})

    def spike(self):
        self.down += 1
        self.clock = max(0.0, self.clock - random.randint(1, 2))
        self.clock_running, self.pc_next = False, 40
        return f"{self.team(self.possession)} spikes the ball to stop the clock.", {"kind": "SPIKE", "gain": 0}

    def call_timeout(self, who):
        self.timeouts[who] -= 1
        self.rest(8.0, who)
        self.clock_running, self.pc_next = False, 25
        return (f"{self.team(who)} calls a timeout ({self.timeouts[who]} left).",
                {"kind": "TIMEOUT", "gain": 0})
