#!/usr/bin/env python3
"""
CFB Coordinator Suite -- BROWSER / TABLET EDITION (pygbag build of v3)

Files (keep them in the same folder):
  cfb_coordinator.py   the game / UI (run this one)
  cfb_engine.py        rules, simulation, penalties, special teams, grading
  cfb_playbooks.py     formations, plays, playbook philosophies

Controls
  Game      : SPACE = snap (skip animation / skip the result pause), P punt, F field goal,
              K kneel, S spike, T timeout, 1/2/3 kickoff or try choices, ESC = pause menu
  Menus     : ESC = back
  Studio    : drag players (formation editor), click a player then click the field to draw a
              route (play editor), right-click = undo last point

Saved next to the scripts: plays.json (playbook), savegame.json (one save slot)
"""
import array
import asyncio
import copy
import html
import math
import os
import random
import sys
import time
from functools import lru_cache

import pygame

from cfb_engine import (DIFFICULTY, TRACKED, WEATHER, Session, adapt_bias, ai_conv_choice, apply_audible, ai_hurry, ai_pick_play, ai_special_choice, ai_wants_timeout, clamp,
                        dd_text, fmt_clock, grade_snap, grade_special, kickoff_ideal, letter_grade,
                        other, play_tag, roll_live, roll_presnap, short_tag, simulate_snap, special_ctx,
                        spot_text)
import gfxcfg
import storage
from cfb_playbooks import (BOXES, DEFAULT_ALIGN, DEPTHS, FULL_LIBRARY, LABELS, PASS_STYLES, PHILOSOPHIES, RUN_STYLES,
                           SIDES, book_names, default_books, load_playbook as _load_playbook, read_json, short_name,
                           visible_formations, write_json_atomic)

pygame.init()

# =============================================================================
# Constants
# =============================================================================
WIDTH, HEIGHT = 1280, 720
IS_WEB = storage.IS_WEB
TOUCH_KB = IS_WEB or bool(os.environ.get("CFB_TOUCH"))   # on-screen keyboard for names/search
FPS = 30 if IS_WEB else 60
FS = FPS / 60.0                                            # animation frames per 60 fps frame
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PLAYBOOK_FILE = os.path.join(BASE_DIR, "plays.json")
SAVE_FILE = os.path.join(BASE_DIR, "savegame.json")
SEASON_FILE = os.path.join(BASE_DIR, "season.json")

ROLE_NAMES = {"HC": "Head Coach", "OC": "Offensive Coordinator", "DC": "Defensive Coordinator"}

COLOR_BG_DARK = (20, 24, 32)
COLOR_PANEL = (30, 36, 46)
COLOR_PANEL_LIGHT = (44, 52, 66)
COLOR_PANEL_BORDER = (50, 60, 76)
COLOR_FIELD = (42, 110, 56)
COLOR_ENDZONE = (24, 84, 36)
COLOR_OOB = (18, 32, 24)
COLOR_FIELD_LINES = (220, 230, 220)
COLOR_TEXT_WHITE = (245, 247, 250)
COLOR_TEXT_MUTED = (140, 150, 165)
COLOR_ACCENT = (0, 168, 150)
COLOR_OFFENSE = (41, 128, 185)
COLOR_DEFENSE = (192, 57, 43)
COLOR_BALL = (230, 160, 30)
COLOR_LOS_BLUE = (0, 120, 255)
COLOR_FIRST_DOWN_YELLOW = (255, 215, 0)
COLOR_FAVORITE_GOLD = (255, 200, 0)
COLOR_BAD = (225, 75, 65)

S = gfxcfg.SCALE            # internal render scale (the game logic still uses 1280x720 coordinates)


class Canvas:
    """The screen when S != 1: callers use logical coordinates, drawing happens at S times the size."""

    def __init__(self, surf):
        self.surf = surf

    def fill(self, color):
        self.surf.fill(color)

    def blit(self, src, dest):          # callers pass already-scaled destinations (draw_text, dim overlay)
        self.surf.blit(src, dest)

    def set_clip(self, rect):
        self.surf.set_clip(None if rect is None else _srect(rect))


def _srect(r):
    r = pygame.Rect(r)
    left, top = round(r.x * S), round(r.y * S)
    return pygame.Rect(left, top, round((r.x + r.w) * S) - left, round((r.y + r.h) * S) - top)


def _spt(p):
    return (p[0] * S, p[1] * S)


def _sw(w):
    return max(1, round(w * S)) if w else 0


def _install_draw_wrappers():
    orig = {n: getattr(pygame.draw, n) for n in ("rect", "circle", "line", "lines", "polygon", "ellipse")}

    def un(surface):
        return surface.surf if isinstance(surface, Canvas) else surface

    def rect(surface, color, r, width=0, border_radius=0, **kw):
        if isinstance(surface, Canvas):
            return orig["rect"](un(surface), color, _srect(r), _sw(width), border_radius=round(border_radius * S))
        return orig["rect"](surface, color, r, width, border_radius=border_radius, **kw)

    def circle(surface, color, center, radius, width=0, **kw):
        if isinstance(surface, Canvas):
            return orig["circle"](un(surface), color, _spt(center), radius * S, _sw(width))
        return orig["circle"](surface, color, center, radius, width, **kw)

    def line(surface, color, a, b, width=1):
        if isinstance(surface, Canvas):
            return orig["line"](un(surface), color, _spt(a), _spt(b), _sw(width))
        return orig["line"](surface, color, a, b, width)

    def lines(surface, color, closed, pts, width=1):
        if isinstance(surface, Canvas):
            return orig["lines"](un(surface), color, closed, [_spt(p) for p in pts], _sw(width))
        return orig["lines"](surface, color, closed, pts, width)

    def polygon(surface, color, pts, width=0):
        if isinstance(surface, Canvas):
            return orig["polygon"](un(surface), color, [_spt(p) for p in pts], _sw(width))
        return orig["polygon"](surface, color, pts, width)

    def ellipse(surface, color, r, width=0):
        if isinstance(surface, Canvas):
            return orig["ellipse"](un(surface), color, _srect(r), _sw(width))
        return orig["ellipse"](surface, color, r, width)

    pygame.draw.rect, pygame.draw.circle, pygame.draw.line = rect, circle, line
    pygame.draw.lines, pygame.draw.polygon, pygame.draw.ellipse = lines, polygon, ellipse


_flags = pygame.SCALED | pygame.RESIZABLE
_surf = pygame.display.get_surface() or pygame.display.set_mode((int(WIDTH * S), int(HEIGHT * S)), _flags)
if S != 1:
    _install_draw_wrappers()
    win = Canvas(_surf)
else:
    win = _surf
pygame.display.set_caption("CFB Coordinator Suite -- Complete Production Edition")


class HiFont:
    """A font drawn at S times the size but measured in logical units, so layout code stays unchanged."""

    def __init__(self, base):
        self.base = base

    def size(self, text):
        w, h = self.base.size(text)
        return (w / S, h / S)

    def render(self, text, aa, color):
        return self.base.render(text, aa, color)

    def get_linesize(self):
        return self.base.get_linesize() / S


def make_font(size):
    px = size * S
    if IS_WEB:  # system fonts do not exist in the browser: use pygame's bundled font
        base = pygame.font.Font(None, int(round(px * 1.25)))
    else:
        base = pygame.font.SysFont("Arial", int(round(px)), bold=True)
    return HiFont(base) if S != 1 else base


font_xs = make_font(10)
font_sm = make_font(12)
font_md = make_font(14)
font_lg = make_font(18)
font_xl = make_font(28)
font_xxl = make_font(54)

# Field geometry: the camera follows the line of scrimmage, which always sits at LOS_X
LOS_X = 510
PX_PER_YD = 5.0
STUDIO_FIELD = pygame.Rect(355, 80, 570, 615)

# =============================================================================
# Small helpers (cached text rendering, wrapping, formatting)
# =============================================================================
_text_cache = {}


def render_text(text, font, color):
    key = (text, font, color)
    surf = _text_cache.get(key)
    if surf is None:
        if len(_text_cache) > 1500:
            _text_cache.clear()
        surf = font.render(text, True, color)
        _text_cache[key] = surf
    return surf


def draw_text(surface, text, font, color, pos, anchor="topleft"):
    surf = render_text(text, font, color)
    if S != 1:
        rect = surf.get_rect(**{anchor: (pos[0] * S, pos[1] * S)})
        surface.blit(surf, rect)
        return pygame.Rect(rect.x / S, rect.y / S, rect.w / S, rect.h / S)
    rect = surf.get_rect(**{anchor: pos})
    surface.blit(surf, rect)
    return rect


@lru_cache(maxsize=2048)
def _wrap(text, font, width):
    lines = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            test = f"{cur} {word}" if cur else word
            if font.size(test)[0] <= width:
                cur = test
            else:
                if cur:
                    lines.append(cur)
                cur = word
        lines.append(cur)
    return tuple(lines)


def draw_wrapped(surface, text, font, color, x, y, width, line_h=None, max_lines=None):
    line_h = line_h or font.get_linesize() + 2
    lines = _wrap(text, font, width)
    if max_lines:
        lines = lines[:max_lines]
    for line in lines:
        if line:
            draw_text(surface, line, font, color, (x, y))
        y += line_h
    return y


def fit_text(text, font, max_w):
    if font.size(text)[0] <= max_w:
        return text
    while text and font.size(text + "...")[0] > max_w:
        text = text[:-1]
    return text + "..."


def draw_star(surface, cx, cy, r, color, filled=True):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.45
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    pygame.draw.polygon(surface, color, pts, 0 if filled else 1)


def draw_route(surface, pts, color):
    if len(pts) < 2:
        return
    pygame.draw.lines(surface, color, False, [(int(x), int(y)) for x, y in pts], 2)
    (x1, y1), (x2, y2) = pts[-2], pts[-1]
    ang = math.atan2(y2 - y1, x2 - x1)
    for da in (2.6, -2.6):
        pygame.draw.line(surface, color, (int(x2), int(y2)),
                         (int(x2 + 9 * math.cos(ang + da)), int(y2 + 9 * math.sin(ang + da))), 2)


def route_color(col):
    return tuple(min(255, c + 110) for c in col)


def grade_color(score):
    if score is None:
        return COLOR_TEXT_MUTED
    if score >= 90:
        return (0, 200, 120)
    if score >= 80:
        return (130, 200, 70)
    if score >= 70:
        return (230, 200, 40)
    if score >= 60:
        return (240, 140, 40)
    return COLOR_BAD


# =============================================================================
# Teams (OVR OFF DEF TAK BTK)
# =============================================================================
_TEAM_DATA = """
[SEC]
Alabama 92 91 93 90 88
Arkansas 81 80 82 81 80
Auburn 84 83 85 84 83
Florida 84 84 84 83 84
Georgia 93 91 95 93 89
Kentucky 82 80 84 83 81
LSU 88 89 87 86 88
Mississippi State 80 79 81 80 79
Missouri 86 87 85 84 86
Oklahoma 88 87 89 88 86
Ole Miss 89 91 87 85 89
South Carolina 82 81 83 82 81
Tennessee 88 89 87 86 88
Texas 91 92 90 89 90
Texas A&M 86 85 87 86 85
Vanderbilt 75 74 76 75 74
[Big Ten]
Illinois 81 80 82 81 80
Indiana 82 83 81 80 81
Iowa 83 72 92 91 75
Maryland 80 81 79 78 80
Michigan 89 86 92 91 86
Michigan State 79 78 80 79 78
Minnesota 80 79 81 80 79
Nebraska 82 81 83 82 80
Northwestern 77 75 79 78 76
Ohio State 93 92 94 92 91
Oregon 91 93 89 88 91
Penn State 89 87 91 90 87
Purdue 76 76 76 75 76
Rutgers 78 77 79 78 77
UCLA 80 79 81 80 79
USC 86 89 83 81 87
Washington 83 82 84 83 82
Wisconsin 82 81 83 82 81
[ACC]
Boston College 78 77 79 78 77
Cal 77 76 78 77 76
Clemson 88 86 90 89 86
Duke 79 78 80 79 78
Florida State 85 84 86 85 84
Georgia Tech 78 79 77 76 78
Louisville 84 85 83 82 84
Miami (FL) 88 90 86 85 88
NC State 82 81 83 82 81
North Carolina 81 83 79 78 82
Pittsburgh 79 78 80 79 78
SMU 83 85 81 80 83
Stanford 75 74 76 75 74
Syracuse 78 79 77 76 78
Virginia 75 75 75 74 75
Virginia Tech 82 81 83 82 81
Wake Forest 76 77 75 74 76
[Big 12]
Arizona 83 85 81 80 83
Arizona State 79 80 78 77 79
Baylor 80 79 81 80 79
BYU 82 81 83 82 81
Cincinnati 78 77 79 78 77
Colorado 83 86 80 79 84
Houston 76 76 76 75 76
Iowa State 84 83 85 84 82
Kansas 83 85 81 80 84
Kansas State 85 86 84 83 85
Oklahoma State 84 85 83 82 84
TCU 82 83 81 80 82
Texas Tech 81 82 80 79 81
UCF 81 82 80 79 81
Utah 87 85 89 88 85
West Virginia 80 80 80 79 80
[American]
Army 82 81 83 82 81
East Carolina 76 75 77 76 75
FAU 75 75 75 74 75
Memphis 82 84 80 79 83
Navy 78 77 79 78 77
North Texas 77 79 75 74 78
Rice 76 75 77 76 75
South Florida 76 77 75 74 76
Temple 72 71 73 72 71
Tulane 81 82 80 79 81
Tulsa 74 74 74 73 74
UAB 75 76 74 73 75
UTSA 80 81 79 78 80
[Mountain West]
Air Force 78 77 79 78 77
Boise State 84 85 83 82 84
Colorado State 75 75 75 74 75
Fresno State 79 80 78 77 79
Hawaii 73 74 72 71 73
Nevada 71 70 72 71 70
New Mexico 72 73 71 70 72
San Diego State 76 74 78 77 74
San Jose State 75 75 75 74 75
UNLV 80 82 78 77 81
Utah State 75 76 74 73 75
Wyoming 76 74 78 77 74
[Sun Belt]
Appalachian State 79 80 78 77 79
Arkansas State 74 75 73 72 74
Coastal Carolina 78 79 77 76 78
Georgia Southern 76 77 75 74 76
Georgia State 75 75 75 74 75
James Madison 81 82 80 79 81
Louisiana 77 77 77 76 77
Marshall 77 76 78 77 76
Old Dominion 74 74 74 73 74
South Alabama 76 77 75 74 76
Southern Miss 73 72 74 73 72
Texas State 78 80 76 75 79
Troy 77 76 78 77 76
UL Monroe 71 70 72 71 70
[MAC]
Akron 70 69 71 70 69
Ball State 72 71 73 72 71
Bowling Green 75 74 76 75 74
Buffalo 73 72 74 73 72
Central Michigan 73 73 73 72 73
Eastern Michigan 73 72 74 73 72
Kent State 69 68 70 69 68
Miami (OH) 77 76 78 77 76
Northern Illinois 75 74 76 75 74
Ohio 77 76 78 77 76
Toledo 79 80 78 77 79
Western Michigan 73 73 73 72 73
[CUSA]
Delaware 74 74 74 73 74
FIU 72 72 72 71 72
Jacksonville State 77 79 75 74 78
Liberty 82 84 80 79 83
Louisiana Tech 73 74 72 71 73
Middle Tennessee 72 72 72 71 72
New Mexico State 75 75 75 74 75
Sam Houston 73 73 73 72 73
UTEP 72 72 72 71 72
Western Kentucky 79 82 76 75 81
[Independents]
Notre Dame 90 89 91 90 88
UConn 74 73 75 74 73
UMass 71 70 72 71 70
"""

STAT_KEYS = ("OVR", "OFF", "DEF", "TAK", "BTK")
FBS_CONFERENCES = {}
TEAM_LOOKUP = {}
for _line in _TEAM_DATA.strip().splitlines():
    _line = _line.strip()
    if _line.startswith("["):
        _conf = _line[1:-1]
        FBS_CONFERENCES[_conf] = {}
    elif _line:
        _parts = _line.rsplit(None, 5)
        _attrs = dict(zip(STAT_KEYS, map(int, _parts[1:])))
        FBS_CONFERENCES[_conf][_parts[0]] = _attrs
        TEAM_LOOKUP[_parts[0]] = _attrs

DEFAULT_ATTRS = {"OVR": 75, "OFF": 75, "DEF": 75, "TAK": 75, "BTK": 75}


def get_team_attrs(team_name):
    return TEAM_LOOKUP.get(team_name, DEFAULT_ATTRS)


_GROUPS = {}


def derive_groups(name):
    """Position-group ratings (QB/RB/WR/OL, DL/LB/DB) built from a team's OFF/DEF with a stable per-team spread."""
    if name not in _GROUPS:
        attrs = get_team_attrs(name)
        rng = random.Random(name)

        def spread(n):
            vals = [clamp(rng.gauss(0, 3.2), -6, 6) for _ in range(n)]
            mean = sum(vals) / n
            return [v - mean for v in vals]

        out = dict(attrs)
        for g, v in zip(("QB", "RB", "WR", "OL"), spread(4)):
            out[g] = attrs["OFF"] + v
        for g, v in zip(("DL", "LB", "DB"), spread(3)):
            out[g] = attrs["DEF"] + v
        _GROUPS[name] = out
    return _GROUPS[name]


# =============================================================================
# Player tokens
# =============================================================================
class PlayerToken:
    __slots__ = ("label", "disp", "is_offense", "path", "idx", "x", "y")

    def __init__(self, x, y, label, is_offense, route, disp=None):
        self.label = label
        self.disp = disp or label
        self.is_offense = is_offense
        self.path = [(x, y)] + [tuple(p) for p in route]
        self.reset()

    def reset(self):
        self.x, self.y = self.path[0]
        self.idx = 1

    def drift(self, px, py, speed):
        dx, dy = px - self.x, py - self.y
        dist = math.hypot(dx, dy)
        if dist > 14:
            self.x += dx / dist * speed
            self.y += dy / dist * speed

    def step(self, speed):
        if self.idx >= len(self.path):
            return
        tx, ty = self.path[self.idx]
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)
        if dist <= speed:
            self.x, self.y = tx, ty
            self.idx += 1
        else:
            self.x += dx / dist * speed
            self.y += dy / dist * speed


class Sfx:
    """Tiny procedurally generated sound effects (no audio files needed). Silently disabled without an audio device."""

    def __init__(self):
        self.ok = False
        self.sounds = {}
        if IS_WEB:      # skipped in the browser build (slow to generate, audio needs a user gesture)
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(22050, -16, 1, 512)
            freq, fmt, ch = pygame.mixer.get_init()
            if fmt != -16:
                return
            self.rate, self.ch = freq, ch
            self.sounds = {
                "snap": self._build(self._mix(self._noise(0.12, 0.5, 25), self._tone(90, 0.12, 0.5, 18))),
                "whistle": self._build(self._tone(2700, 0.45, 0.30, 1.5, vib=3.0)),
                "tick": self._build(self._tone(1400, 0.05, 0.30, 40)),
                "kick": self._build(self._mix(self._tone(70, 0.2, 0.6, 12), self._noise(0.04, 0.3, 60))),
                "flag": self._build(self._tone(880, 0.12, 0.35, 4) + self._tone(660, 0.16, 0.35, 4)),
                "cheer": self._build(self._noise(0.9, 0.35, 0, swell=True)),
                "horn": self._build(self._mix(self._tone(220, 0.7, 0.35, 1.2), self._tone(330, 0.7, 0.2, 1.2))),
            }
            self.ok = True
        except (pygame.error, OSError, ValueError, TypeError):
            self.ok = False

    def _tone(self, f, dur, vol=0.4, decay=3.0, vib=0.0):
        out = []
        for i in range(int(self.rate * dur)):
            tm = i / self.rate
            ph = 2 * math.pi * f * tm + (vib * math.sin(2 * math.pi * 28 * tm) if vib else 0.0)
            out.append(vol * math.sin(ph) * math.exp(-decay * tm))
        return out

    def _noise(self, dur, vol=0.4, decay=10.0, swell=False):
        n = int(self.rate * dur)
        return [vol * random.uniform(-1, 1) * (math.sin(math.pi * i / n) if swell else math.exp(-decay * i / self.rate))
                for i in range(n)]

    @staticmethod
    def _mix(*parts):
        n = max(len(p) for p in parts)
        return [sum(p[i] for p in parts if i < len(p)) for i in range(n)]

    def _build(self, samples):
        data = array.array("h")
        for v in samples:
            iv = int(clamp(v, -1.0, 1.0) * 30000)
            for _ in range(self.ch):
                data.append(iv)
        return pygame.mixer.Sound(buffer=data.tobytes())

    def play(self, name):
        snd = self.sounds.get(name)
        if snd:
            snd.play()


PLAY_FILTERS = {"OFFENSE": ["ALL", "RUN", "PASS", "SHORT", "MEDIUM", "DEEP", "SCREEN", "PLAY_ACTION", "RPO", "TRICK"],
                "DEFENSE": ["ALL", "ZONE", "MAN", "BLITZ", "NO BLITZ", "HEAVY BOX", "LIGHT BOX"]}


def play_matches(side, meta, flt):
    if flt == "ALL":
        return True
    if side == "OFFENSE":
        if flt == "RUN":
            return meta["is_run"]
        if flt == "PASS":
            return not meta["is_run"]
        if flt in ("SHORT", "MEDIUM", "DEEP"):
            return (not meta["is_run"]) and meta["depth"] == flt
        return meta.get("style") == flt
    return {"ZONE": meta["coverage"] == "ZONE", "MAN": meta["coverage"] == "MAN", "BLITZ": meta["blitz"],
            "NO BLITZ": not meta["blitz"], "HEAVY BOX": meta.get("box") == "HEAVY",
            "LIGHT BOX": meta.get("box") == "LIGHT"}.get(flt, True)


def slot_path(i):
    return SAVE_FILE if i == 0 else SAVE_FILE.replace(".json", f"_{i + 1}.json")


ANIM_SPEED = 3.0 / FS
MAX_ANIM_FRAMES = int(150 * FS)
BACK_MAP = {
    "MATCH_SETTINGS": "MAIN_MENU", "ROLE_SELECT": "MATCH_SETTINGS",
    "SELECT_USER_CONF": "ROLE_SELECT", "SELECT_USER_TEAM": "SELECT_USER_CONF",
    "SELECT_AI_CONF": "SELECT_USER_TEAM", "SELECT_AI_TEAM": "SELECT_AI_CONF",
    "PLAYBOOK_VIEW": "MAIN_MENU", "PLAYMAKER_STUDIO": "MAIN_MENU", "SELECT_PLAYBOOK": "SELECT_AI_TEAM", "LOAD_GAME": "MAIN_MENU", "SEASON_HUB": "MAIN_MENU",
}


# =============================================================================
# Application
# =============================================================================
class App:
    def __init__(self):
        self.clock = pygame.time.Clock()
        self.running = True
        self.s = None                # current Session (None outside a game)
        self.dim = pygame.Surface((int(WIDTH * S), int(HEIGHT * S)), pygame.SRCALPHA)
        self.dim.fill((0, 0, 0, 175))

        self.playbook = _load_playbook(PLAYBOOK_FILE)
        self.scene = "MAIN_MENU"
        self.overlay = None          # None | "PAUSE" | "CONFIRM_END"
        self.modal = None            # text-input dialog
        self.press = None            # touch/mouse press in progress (tap vs drag-scroll)
        self.gfx_pending = None
        self.targets = []            # clickable rects registered during draw
        self.regions = []            # scrollable regions registered during draw
        self.scroll = {}
        self.mouse = (0, 0)
        self.confirm_key = None
        self.confirm_until = 0.0

        # setup choices
        self.qtr_mins = 5
        self.structure = "FULL"
        self.pc_speed = 1.0
        self.penalty_level = "STICKLERS"
        self.difficulty = "VARSITY"
        self.weather_choice = "RANDOM"
        self.home_choice = "RANDOM"
        self.role = "HC"
        self.user_team, self.ai_team = "Alabama", "Georgia"
        self.conf_user, self.conf_ai = "SEC", "SEC"

        # playbook selection
        self.sel = {s: self.first_play_name(s) for s in SIDES}
        self.pb_sel = dict(self.sel)
        self.pb_side = "OFFENSE"
        self.pb_book = {s: FULL_LIBRARY for s in SIDES}
        self.pb_flt = {s: "ALL" for s in SIDES}
        self.pb_search = {s: "" for s in SIDES}
        self.mode = "GAME"
        self.season = self.load_season()
        self.season_game = None
        self.season_note = ""
        self.export_msg = ""
        self.sound_on = True
        self.sfx = Sfx()
        if IS_WEB:
            self.sfx.ok = False      # procedural sound is skipped in the browser build
        self._tick_last = 99
        self.book_sel = default_books(self.user_team, get_team_attrs(self.user_team))
        self.expanded = {s: set() for s in SIDES}
        self.ensure_selection()

        # game state
        self.s = None
        self.game_state = "PLAY_CALL"
        self.anim = 0
        self.dt = 1.0 / FPS
        self.hold = 0.0              # seconds the result stays on screen before the next play starts
        self.after_hold = None
        self.pc = self.pc_max = 40.0
        self.ai_snap_at = 3.0
        self.ai_wait = 12.0
        self.ai_to_pending = False
        self.aud_meta = {"OFFENSE": None, "DEFENSE": None}
        self.aud_used = False
        self.aud_note = ""
        self.fx = None
        self.result_text = ""
        self.call_auto = False
        self.calls = dict(self.sel)
        self.tok_off, self.tok_def = [], []
        self.ball = [0, 0]
        self.qb_token = self.target_token = None
        self.pause_msg = ""
        self.menu_msg = ""
        self.save_info = None
        self.log_sel = 0
        self.log_back = "PAUSE"
        self.log_analysis = True

        self.studio_reset()
        self.refresh_save_info()

        self.draw_fns = {
            "MAIN_MENU": self.draw_main_menu, "MATCH_SETTINGS": self.draw_match_settings,
            "ROLE_SELECT": self.draw_role_select,
            "SELECT_USER_CONF": lambda: self.draw_conf_select(True),
            "SELECT_AI_CONF": lambda: self.draw_conf_select(False),
            "SELECT_USER_TEAM": lambda: self.draw_team_select(True),
            "SELECT_AI_TEAM": lambda: self.draw_team_select(False),
            "SELECT_PLAYBOOK": self.draw_select_playbook, "LOAD_GAME": self.draw_load_game, "SEASON_HUB": self.draw_season_hub,
            "PLAYBOOK_VIEW": self.draw_playbook_view, "PLAYMAKER_STUDIO": self.draw_playmaker_studio,
            "PLAY_GAME": self.draw_play_game, "PLAY_LOG": self.draw_play_log,
            "REPORT_CARD": self.draw_report_card,
        }

    # ------------------------------------------------------------------ data
    def catalog(self, side):
        return {pn: p for f in self.playbook[side].values() for pn, p in f["plays"].items()}

    def plays_for(self, side, book):
        """Plays available in a playbook (philosophy). Falls back to the whole library if that is empty."""
        names = visible_formations(self.playbook, side, book)
        out = {pn: p for fn in names for pn, p in self.playbook[side][fn]["plays"].items()}
        return out or self.catalog(side)

    def user_plays(self, side):
        return self.plays_for(side, self.s.user_book[side] if self.s else None)

    def ai_plays(self, side):
        return self.plays_for(side, self.s.ai_book[side])

    def find_play(self, side, name):
        for fn, f in self.playbook[side].items():
            if name in f["plays"]:
                return fn, f["plays"][name]
        return None, None

    def first_play_name(self, side, book=None):
        for pn in self.plays_for(side, book):
            return pn
        return None

    def ensure_selection(self):
        for side in SIDES:
            ubook = self.s.user_book[side] if self.s else None
            for d, avail in ((self.sel, self.plays_for(side, ubook)),
                             (self.pb_sel, self.plays_for(side, self.pb_book[side]))):
                if d.get(side) not in avail:
                    d[side] = next(iter(avail))
            fn, _ = self.find_play(side, self.sel[side])
            if fn:
                self.expanded[side].add(fn)
        self.playbook["FAVORITES"] = [n for n in self.playbook["FAVORITES"]
                                      if any(self.find_play(s, n)[1] for s in SIDES)]

    def save_playbook(self):
        self.ensure_selection()
        try:
            write_json_atomic(PLAYBOOK_FILE, self.playbook, compact=True)
        except OSError as exc:
            print(f"[playbook] save failed: {exc}")

    def toggle_favorite(self, name):
        favs = self.playbook["FAVORITES"]
        if name in favs:
            favs.remove(name)
        else:
            favs.append(name)
        self.save_playbook()

    def make_tokens(self, side, form_name, play_name):
        form = self.playbook[side][form_name]
        play = form["plays"][play_name]
        names = form.get("names", {})
        toks = []
        for lbl in LABELS[side]:
            x, y = form["alignment"][lbl]
            toks.append(PlayerToken(x, y, lbl, side == "OFFENSE", play["route"].get(lbl, []), names.get(lbl)))
        return toks

    def default_tokens(self, side):
        return [PlayerToken(*DEFAULT_ALIGN[side][l], l, side == "OFFENSE", []) for l in LABELS[side]]

    # ------------------------------------------------------------ navigation
    def goto(self, scene):
        self.scene = scene
        self.overlay = None
        self.modal = None
        self.scroll = {}
        if scene == "MAIN_MENU":
            self.mode = "GAME"
            self.season_game = None
            self.refresh_save_info()
        elif scene == "LOAD_GAME":
            self.refresh_save_info()

    def back(self):
        self.goto(BACK_MAP[self.scene])

    def refresh_save_info(self):
        self.slot_info = [self.read_slot(i) for i in range(3)]
        self.save_info = next((x for x in self.slot_info if x), None)

    def read_slot(self, i):
        try:
            p = read_json(slot_path(i))
            d = p["session"]
            return (f"{d['user_team']} {d['user_score']} - {d['ai_score']} {d['ai_team']}  |  "
                              f"{('OT%d' % d['ot']['n']) if d.get('ot') else 'Q%d %s' % (d['quarter'], fmt_clock(d['clock']))}  |  saved {p.get('saved_at', '?')}")
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def confirm(self, key):
        now = time.time()
        if self.confirm_key == key and now < self.confirm_until:
            self.confirm_key = None
            return True
        self.confirm_key, self.confirm_until = key, now + 3.0
        return False

    def confirm_pending(self, key):
        return self.confirm_key == key and time.time() < self.confirm_until

    # -------------------------------------------------------------- UI kit
    def add_target(self, rect, action, clip=None):
        r = pygame.Rect(rect)
        if clip is not None:
            r = r.clip(clip)
        if r.width > 0 and r.height > 0:
            self.targets.append((r, action))

    def button(self, rect, label, action, kind="normal", font=None, enabled=True):
        rect = pygame.Rect(rect)
        hover = enabled and rect.collidepoint(self.mouse)
        if not enabled:
            bg, fg, border = (36, 40, 48), (95, 102, 114), COLOR_PANEL_BORDER
        elif kind == "accent":
            bg, fg, border = ((20, 195, 175) if hover else COLOR_ACCENT), COLOR_BG_DARK, COLOR_ACCENT
        elif kind == "danger":
            bg, fg, border = ((215, 75, 62) if hover else COLOR_DEFENSE), COLOR_TEXT_WHITE, COLOR_DEFENSE
        elif kind == "selected":
            bg, fg, border = (50, 70, 88), COLOR_ACCENT, COLOR_ACCENT
        else:
            bg, fg, border = (COLOR_PANEL_LIGHT if hover else COLOR_PANEL), COLOR_TEXT_WHITE, COLOR_PANEL_BORDER
        pygame.draw.rect(win, bg, rect, border_radius=6)
        pygame.draw.rect(win, border, rect, 1, border_radius=6)
        draw_text(win, label, font or font_md, fg, rect.center, "center")
        if enabled and action:
            self.add_target(rect, action)

    def back_button(self, action=None, label="< BACK"):
        self.button((20, 20, 120, 40), label, action or self.back)

    def scroll_area(self, key, rect, content_h):
        mx = max(0, content_h - rect.height)
        self.scroll[key] = clamp(self.scroll.get(key, 0), 0, mx)
        self.regions.append((pygame.Rect(rect), key, mx))
        return self.scroll[key]

    def draw_scrollbar(self, rect, off, content_h):
        if content_h <= rect.height:
            return
        pygame.draw.rect(win, COLOR_PANEL_BORDER, (rect.right - 5, rect.y, 4, rect.height), border_radius=2)
        th = max(24, int(rect.height * rect.height / content_h))
        ty = rect.y + int((rect.height - th) * off / (content_h - rect.height))
        pygame.draw.rect(win, COLOR_ACCENT, (rect.right - 5, ty, 4, th), border_radius=2)

    def draw_pick_list(self, key, view, items, selected, on_click, row_h=26):
        content_h = len(items) * (row_h + 2)
        off = self.scroll_area(key, view, content_h)
        pygame.draw.rect(win, COLOR_BG_DARK, view, border_radius=4)
        win.set_clip(view)
        y = view.y - off
        for label, value in items:
            r = pygame.Rect(view.x + 2, y, view.w - 10, row_h)
            if r.bottom >= view.y and r.y <= view.bottom:
                sel = value == selected
                hover = r.collidepoint(self.mouse) and view.collidepoint(self.mouse)
                pygame.draw.rect(win, (55, 75, 95) if sel else COLOR_PANEL_LIGHT if hover else COLOR_PANEL, r,
                                 border_radius=4)
                if sel:
                    pygame.draw.rect(win, COLOR_ACCENT, r, 1, border_radius=4)
                draw_text(win, fit_text(label, font_sm, r.w - 14), font_sm,
                          COLOR_ACCENT if sel else COLOR_TEXT_WHITE, (r.x + 8, r.centery), "midleft")
                self.add_target(r, lambda v=value: on_click(v), clip=view)
            y += row_h + 2
        win.set_clip(None)
        self.draw_scrollbar(view, off, content_h)
        if not items:
            draw_text(win, "(none yet)", font_sm, COLOR_TEXT_MUTED, view.center, "center")

    def open_modal(self, title, value, on_ok, validate=None, max_len=28):
        self.modal = {"title": title, "value": value, "on_ok": on_ok, "validate": validate,
                      "max_len": max_len, "error": ""}

    def modal_ok(self):
        m = self.modal
        if not m:
            return
        value = m["value"].strip()
        if not value:
            m["error"] = "Enter a name."
            return
        err = m["validate"](value) if m["validate"] else None
        if err:
            m["error"] = err
            return
        self.modal = None
        m["on_ok"](value)

    def modal_cancel(self):
        self.modal = None

    def modal_type(self, ch):
        m = self.modal
        if not m or len(m["value"]) >= m["max_len"]:
            return
        if ch.isalpha():
            ch = ch.upper() if (not m["value"] or m["value"].endswith(" ")) else ch.lower()
        m["value"] += ch
        m["error"] = ""

    def modal_backspace(self):
        if self.modal:
            self.modal["value"] = self.modal["value"][:-1]
            self.modal["error"] = ""

    def draw_modal(self):
        m = self.modal
        win.blit(self.dim, (0, 0))
        kb = TOUCH_KB
        box = pygame.Rect(WIDTH // 2 - 380, 30, 760, 460) if kb else pygame.Rect(WIDTH // 2 - 260, 250, 520, 200)
        pygame.draw.rect(win, COLOR_PANEL, box, border_radius=10)
        pygame.draw.rect(win, COLOR_ACCENT, box, 2, border_radius=10)
        draw_text(win, m["title"], font_lg, COLOR_ACCENT, (box.centerx, box.y + 16), "midtop")
        field = pygame.Rect(box.x + 30, box.y + 52, box.w - 60, 40)
        pygame.draw.rect(win, COLOR_BG_DARK, field, border_radius=6)
        pygame.draw.rect(win, COLOR_PANEL_BORDER, field, 1, border_radius=6)
        cursor = "|" if int(time.time() * 2) % 2 == 0 else ""
        draw_text(win, m["value"] + cursor, font_lg, COLOR_TEXT_WHITE, (field.x + 10, field.centery), "midleft")
        if m["error"]:
            draw_text(win, m["error"], font_sm, COLOR_BAD, (box.x + 30, box.y + 98))
        if kb:
            for r, row in enumerate(("1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")):
                x0 = box.x + (box.w - len(row) * 70 + 6) // 2
                for i, ch in enumerate(row):
                    self.button((x0 + i * 70, box.y + 120 + r * 54, 64, 48), ch, lambda c=ch: self.modal_type(c),
                                font=font_md)
            by = box.y + 120 + 4 * 54
            self.button((box.x + 90, by, 120, 48), "-  '  /", lambda: self.modal_type("-"), font=font_sm)
            self.button((box.x + 220, by, 320, 48), "SPACE", lambda: self.modal_type(" "), font=font_md)
            self.button((box.x + 550, by, 120, 48), "DELETE", self.modal_backspace, font=font_sm)
            self.button((box.x + 30, box.bottom - 62, 300, 46), "OK", self.modal_ok, "accent", font_lg)
            self.button((box.right - 330, box.bottom - 62, 300, 46), "CANCEL", self.modal_cancel, font=font_lg)
        else:
            self.button((box.x + 30, box.bottom - 60, 220, 40), "OK  [ENTER]", self.modal_ok, "accent")
            self.button((box.right - 250, box.bottom - 60, 220, 40), "CANCEL  [ESC]", self.modal_cancel)

    # --------------------------------------------------------------- field
    def draw_field(self, rect, los_yard, to_go=None):
        win.set_clip(rect)
        pygame.draw.rect(win, COLOR_FIELD, rect)
        x0 = LOS_X + (0 - los_yard) * PX_PER_YD
        x100 = LOS_X + (100 - los_yard) * PX_PER_YD
        ez = 10 * PX_PER_YD
        pygame.draw.rect(win, COLOR_ENDZONE, (int(x0 - ez), rect.top, int(ez), rect.height))
        pygame.draw.rect(win, COLOR_ENDZONE, (int(x100), rect.top, int(ez), rect.height))
        pygame.draw.rect(win, COLOR_OOB, (int(x0 - ez) - 3000, rect.top, 3000, rect.height))
        pygame.draw.rect(win, COLOR_OOB, (int(x100 + ez), rect.top, 3000, rect.height))
        for yd in range(0, 101, 5):
            x = int(LOS_X + (yd - los_yard) * PX_PER_YD)
            if x < rect.left - 2 or x > rect.right + 2:
                continue
            major = yd % 10 == 0
            pygame.draw.line(win, COLOR_FIELD_LINES, (x, rect.top), (x, rect.bottom),
                             3 if yd in (0, 100) else 2 if major else 1)
            if major and 0 < yd < 100:
                label = str(min(yd, 100 - yd))
                draw_text(win, label, font_md, (200, 215, 200), (x, rect.top + 22), "center")
                draw_text(win, label, font_md, (200, 215, 200), (x, rect.bottom - 22), "center")
        pygame.draw.line(win, COLOR_LOS_BLUE, (LOS_X, rect.top), (LOS_X, rect.bottom), 3)
        if to_go is not None:
            fx = int(LOS_X + to_go * PX_PER_YD)
            pygame.draw.line(win, COLOR_FIRST_DOWN_YELLOW, (fx, rect.top), (fx, rect.bottom), 3)
        win.set_clip(None)
        pygame.draw.rect(win, COLOR_FIELD_LINES, rect, 3)

    def draw_token(self, x, y, label, color, ring=None, text_color=COLOR_TEXT_WHITE):
        px, py = int(x), int(y)
        pygame.draw.circle(win, color, (px, py), 13)
        pygame.draw.circle(win, text_color if not ring else ring, (px, py), 13 if not ring else 16,
                           2 if not ring else 3)
        if label:
            draw_text(win, label, font_xs, text_color, (px, py), "center")

    def draw_tokens(self, off_tokens, def_tokens, off_color, def_color, route_sides=()):
        for side, toks, col in (("OFFENSE", off_tokens, off_color), ("DEFENSE", def_tokens, def_color)):
            if side in route_sides:
                rc = route_color(col)
                for t in toks:
                    draw_route(win, t.path, rc)
        for toks, col in ((off_tokens, off_color), (def_tokens, def_color)):
            for t in toks:
                self.draw_token(t.x, t.y, t.disp, col)
        pygame.draw.ellipse(win, COLOR_BALL, (int(self.ball[0]) - 7, int(self.ball[1]) - 5, 14, 10))

    # ----------------------------------------------------- playbook tree UI
    def cycle_filter(self, side):
        opts = PLAY_FILTERS[side]
        self.pb_flt[side] = opts[(opts.index(self.pb_flt[side]) + 1) % len(opts)]
        self.scroll.pop(f"tree_{side}", None)

    def search_action(self, side):
        if self.pb_search[side]:
            self.pb_search[side] = ""
            self.scroll.pop(f"tree_{side}", None)
        else:
            self.open_modal("SEARCH PLAYS (name contains)", "", lambda v: self.pb_search.__setitem__(side, v), max_len=24)

    def draw_playbook_panel(self, side, rect, selectable, selected, on_select, book=None):
        pygame.draw.rect(win, COLOR_PANEL, rect, border_radius=6)
        x, w = rect.x + 10, rect.w - 20
        title = f"{side} PLAYBOOK" + (f" - {book}" if book else "")
        draw_text(win, fit_text(title, font_md, w - 4), font_md, COLOR_ACCENT, (x + 2, rect.y + 10))
        avail = self.plays_for(side, book)

        fav_rect = pygame.Rect(x, rect.y + 34, w, 84)
        pygame.draw.rect(win, (25, 32, 42), fav_rect, border_radius=6)
        draw_star(win, fav_rect.x + 14, fav_rect.y + 13, 7, COLOR_FAVORITE_GOLD)
        draw_text(win, "FAVORITES & CUSTOM PLAYS", font_sm, COLOR_FAVORITE_GOLD, (fav_rect.x + 26, fav_rect.y + 6))
        favs = [n for n in self.playbook["FAVORITES"] if n in avail][:3]
        if not favs:
            draw_text(win, "Click a play's star to pin it here.", font_sm, COLOR_TEXT_MUTED,
                      (fav_rect.x + 8, fav_rect.y + 28))
        for i, n in enumerate(favs):
            r = pygame.Rect(fav_rect.x + 4, fav_rect.y + 26 + i * 19, fav_rect.w - 8, 18)
            sel = n == selected
            if sel or r.collidepoint(self.mouse):
                pygame.draw.rect(win, (55, 75, 95) if sel else COLOR_PANEL_LIGHT, r, border_radius=3)
            draw_text(win, fit_text(f"- {n}", font_sm, r.w - 8), font_sm,
                      COLOR_ACCENT if sel else COLOR_TEXT_WHITE, (r.x + 4, r.y + 3))
            if selectable:
                self.add_target(r, lambda n=n: on_select(n))

        flt, q = self.pb_flt[side], self.pb_search[side]
        fw = int(w * 0.58)
        self.button((x, rect.y + 123, fw, 24), f"FILTER: {flt.replace('_', ' ')}", lambda: self.cycle_filter(side),
                    "selected" if flt != "ALL" else "normal", font_sm)
        self.button((x + fw + 6, rect.y + 123, w - fw - 6, 24),
                    fit_text(f"X {q}" if q else "SEARCH", font_sm, w - fw - 20), lambda: self.search_action(side),
                    "selected" if q else "normal", font_sm)

        view = pygame.Rect(x, rect.y + 154, w, rect.bottom - 10 - (rect.y + 154))
        filtering = flt != "ALL" or bool(q)
        forms = {}
        for fn in visible_formations(self.playbook, side, book):
            plays = {pn: p for pn, p in self.playbook[side][fn]["plays"].items()
                     if play_matches(side, p, flt) and (not q or q.lower() in pn.lower())}
            if plays or not filtering:
                forms[fn] = plays
        exp = self.expanded[side]
        content_h = sum(30 + (len(pl) * 25 if (filtering or fn in exp) else 0) for fn, pl in forms.items())
        off = self.scroll_area(f"tree_{side}", view, content_h)
        win.set_clip(view)
        y = view.y - off
        for fname, plays in forms.items():
            open_ = filtering or fname in exp
            hdr = pygame.Rect(view.x, y, view.w - 10, 26)
            pygame.draw.rect(win, (45, 55, 70) if open_ else (35, 42, 54), hdr, border_radius=4)
            draw_text(win, fit_text(f"{'[-]' if open_ else '[+]'} {fname}  ({len(plays)})", font_sm, hdr.w - 12),
                      font_sm, COLOR_TEXT_WHITE, (hdr.x + 8, hdr.centery), "midleft")
            self.add_target(hdr, lambda f=fname: self.toggle_expand(side, f), clip=view)
            y += 30
            if open_:
                for pname, play in plays.items():
                    r = pygame.Rect(view.x + 12, y, view.w - 22, 22)
                    is_sel = pname == selected
                    pygame.draw.rect(win, (55, 75, 95) if is_sel else (28, 34, 44), r, border_radius=3)
                    if is_sel:
                        pygame.draw.rect(win, COLOR_ACCENT, r, 1, border_radius=3)
                    disp = fit_text(f"({short_tag(play)}) {short_name(pname)}", font_sm, r.w - 36)
                    draw_text(win, disp, font_sm, COLOR_ACCENT if is_sel else COLOR_TEXT_MUTED,
                              (r.x + 6, r.centery), "midleft")
                    fav = pname in self.playbook["FAVORITES"]
                    draw_star(win, r.right - 12, r.centery, 7, COLOR_FAVORITE_GOLD if fav else COLOR_TEXT_MUTED,
                              filled=fav)
                    if selectable:
                        self.add_target(pygame.Rect(r.x, r.y, r.w - 26, r.h), lambda n=pname: on_select(n), clip=view)
                    self.add_target(pygame.Rect(r.right - 24, r.y, 24, r.h),
                                    lambda n=pname: self.toggle_favorite(n), clip=view)
                    y += 25
        win.set_clip(None)
        self.draw_scrollbar(view, off, content_h)
        if not forms:
            draw_text(win, "No plays match.", font_sm, COLOR_TEXT_MUTED, view.center, "center")

    def toggle_expand(self, side, fname):
        if fname in self.expanded[side]:
            self.expanded[side].discard(fname)
        else:
            self.expanded[side].add(fname)

    # ================================================================ MENUS
    def draw_main_menu(self):
        draw_text(win, "CFB COORDINATOR SUITE", font_xl, COLOR_ACCENT, (WIDTH // 2, 100), "midtop")
        draw_text(win, "Call plays. Beat the clock. Get graded.", font_md, COLOR_TEXT_MUTED, (WIDTH // 2, 140), "midtop")
        x = WIDTH // 2 - 170
        self.button((x, 190, 340, 50), "PLAY NEW GAME", self.new_game_flow, "accent", font_lg)
        self.button((x, 255, 340, 50), "LOAD SAVED GAME", lambda: self.goto("LOAD_GAME"), font=font_lg,
                    enabled=self.save_info is not None)
        self.button((x, 320, 340, 50), "SEASON MODE", self.open_season, font=font_lg)
        self.button((x, 385, 340, 50), "VIEW PLAYBOOK", lambda: self.goto("PLAYBOOK_VIEW"), font=font_lg)
        self.button((x, 450, 340, 50), "PLAYMAKER STUDIO", self.open_studio, font=font_lg)
        if not IS_WEB:
            self.button((x, 515, 340, 50), "QUIT", self.quit, font=font_lg)
            self.button((x, 580, 340, 36), f"SOUND: {'ON' if self.sound_on else 'OFF'}", self.toggle_sound, font=font_sm)
        else:
            draw_text(win, "Browser edition: progress is saved in this browser.", font_sm, COLOR_TEXT_MUTED,
                      (WIDTH // 2, 530), "midtop")
            self.button((x, 556, 340, 40), f"GRAPHICS: {gfxcfg.NAMES[S if self.gfx_pending is None else self.gfx_pending]}",
                        self.cycle_graphics, font=font_sm)
            draw_text(win, "Reload the page after changing this." if self.gfx_pending is not None
                      else "Sharper looks better but runs slower.", font_sm, COLOR_TEXT_MUTED,
                      (WIDTH // 2, 600), "midtop")
        if self.menu_msg:
            draw_text(win, self.menu_msg, font_md, COLOR_BAD, (WIDTH // 2, 636), "midtop")

    def new_game_flow(self):
        self.mode = "GAME"
        self.goto("MATCH_SETTINGS")
        self.mode = "GAME"

    def draw_load_game(self):
        self.back_button()
        draw_text(win, "LOAD SAVED GAME", font_xl, COLOR_ACCENT, (WIDTH // 2, 50), "midtop")
        for i in range(3):
            box = pygame.Rect(WIDTH // 2 - 320, 150 + i * 110, 640, 90)
            pygame.draw.rect(win, COLOR_PANEL, box, border_radius=8)
            info = self.slot_info[i]
            draw_text(win, f"SLOT {i + 1}", font_lg, COLOR_ACCENT, (box.x + 18, box.y + 14))
            draw_text(win, fit_text(info or "(empty)", font_md, 440), font_md,
                      COLOR_TEXT_WHITE if info else COLOR_TEXT_MUTED, (box.x + 18, box.y + 50))
            self.button((box.right - 150, box.y + 22, 130, 46), "LOAD", lambda i=i: self.load_game(i), "accent",
                        enabled=info is not None)

    @staticmethod
    def logical_mouse():
        x, y = pygame.mouse.get_pos()
        return (x / S, y / S)

    def cycle_graphics(self):
        self.gfx_pending = gfxcfg.next_scale(S if self.gfx_pending is None else self.gfx_pending)
        gfxcfg.save(self.gfx_pending)

    def sound(self, name):
        if self.sound_on and self.sfx.ok:
            self.sfx.play(name)

    def toggle_sound(self):
        self.sound_on = not self.sound_on

    # ---------------------------------------------------------------- season mode
    def load_season(self):
        try:
            d = read_json(SEASON_FILE)
            return d if isinstance(d, dict) and d.get("opponents") else None
        except (OSError, ValueError):
            return None

    def save_season(self):
        try:
            write_json_atomic(SEASON_FILE, self.season)
        except OSError:
            pass

    def open_season(self):
        if self.season:
            self.goto("SEASON_HUB")
        else:
            self.goto("MATCH_SETTINGS")
        self.mode = "SEASON"

    def new_season(self):
        pool = [n for n in TEAM_LOOKUP if n != self.user_team]
        self.season = {"team": self.user_team, "role": self.role, "qtr_mins": self.qtr_mins,
                       "structure": self.structure, "pc_speed": self.pc_speed, "penalty_level": self.penalty_level,
                       "difficulty": self.difficulty, "books": dict(self.book_sel),
                       "opponents": random.sample(pool, 10), "results": []}
        self.save_season()
        self.goto("SEASON_HUB")
        self.mode = "SEASON"

    def play_season_game(self):
        S = self.season
        idx = len(S["results"])
        if idx >= len(S["opponents"]):
            return
        self.user_team, self.role = S["team"], S["role"]
        self.qtr_mins, self.structure, self.pc_speed = S["qtr_mins"], S["structure"], S["pc_speed"]
        self.penalty_level, self.difficulty = S["penalty_level"], S["difficulty"]
        self.book_sel = dict(S["books"])
        self.ai_team = S["opponents"][idx]
        self.season_game = idx
        self.start_game()

    def draw_season_hub(self):
        if not self.season:
            self.goto("MAIN_MENU")
            return
        self.back_button()
        S = self.season
        res = S["results"]
        w_ = sum(1 for r in res if r["us"] > r["them"])
        l_ = sum(1 for r in res if r["us"] < r["them"])
        t_ = len(res) - w_ - l_
        pf, pa = sum(r["us"] for r in res), sum(r["them"] for r in res)
        draw_text(win, f"{S['team'].upper()} SEASON", font_xl, COLOR_ACCENT, (WIDTH // 2, 28), "midtop")
        draw_text(win, f"Record {w_}-{l_}" + (f"-{t_}" if t_ else "") + f"     Points {pf}-{pa}", font_lg,
                  COLOR_TEXT_WHITE, (WIDTH // 2, 72), "midtop")
        for i, opp in enumerate(S["opponents"]):
            row = pygame.Rect(WIDTH // 2 - 330, 112 + i * 42, 660, 36)
            nxt = i == len(res)
            pygame.draw.rect(win, (50, 70, 88) if nxt else COLOR_PANEL, row, border_radius=6)
            if nxt:
                pygame.draw.rect(win, COLOR_ACCENT, row, 1, border_radius=6)
            ovr = get_team_attrs(opp)["OVR"]
            if i < len(res):
                r = res[i]
                tag, col = ("W", (0, 200, 120)) if r["us"] > r["them"] else ("L", COLOR_BAD) if r["us"] < r["them"] \
                    else ("T", COLOR_FAVORITE_GOLD)
                draw_text(win, f"{i + 1}.  {tag}  {r['us']}-{r['them']}   vs {opp} ({ovr})", font_md, col,
                          (row.x + 16, row.centery), "midleft")
            else:
                draw_text(win, ("NEXT >>  " if nxt else f"{i + 1}.  ") + f"vs {opp} ({ovr})", font_md,
                          COLOR_ACCENT if nxt else COLOR_TEXT_MUTED, (row.x + 16, row.centery), "midleft")
        done = len(res) >= len(S["opponents"])
        bx = WIDTH // 2 - 330
        if done:
            draw_text(win, f"SEASON COMPLETE: {w_}-{l_}" + (f"-{t_}" if t_ else ""), font_lg, COLOR_FAVORITE_GOLD,
                      (bx, 578))
        else:
            self.button((bx, 568, 320, 50), "PLAY NEXT GAME", self.play_season_game, "accent", font_lg)
        pending = self.confirm_pending("new_season")
        self.button((bx + 340, 568, 320, 50), "CONFIRM NEW SEASON?" if pending else "NEW SEASON",
                    lambda: self.confirm("new_season") and self.start_new_season(),
                    "danger" if pending else "normal", font_lg)

    def start_new_season(self):
        self.goto("MATCH_SETTINGS")
        self.mode = "SEASON"

    def record_season_result(self):
        self.season_note = ""
        S = self.season
        if self.season_game is None or not S or len(S["results"]) != self.season_game:
            return
        s = self.s
        S["results"].append({"opp": s.ai_team, "us": s.user_score, "them": s.ai_score})
        self.save_season()
        res = S["results"]
        w_ = sum(1 for r in res if r["us"] > r["them"])
        l_ = sum(1 for r in res if r["us"] < r["them"])
        self.season_note = f"Season record: {w_}-{l_}" + (f"-{len(res) - w_ - l_}" if len(res) - w_ - l_ else "") + \
            f"  ({len(res)}/{len(S['opponents'])} games)"

    # ---------------------------------------------------------------- game summary export
    def export_summary(self):
        if IS_WEB:
            self.export_msg = "Export is only available in the desktop edition."
            return
        s = self.s
        esc = html.escape
        prev, periods, scoring = [0, 0], {}, []
        for e in s.log:
            sc = e.get("score", prev)
            d = (sc[0] - prev[0], sc[1] - prev[1])
            label = e.get("ql") or f"Q{e['q']}"
            row = periods.setdefault(label, [0, 0])
            row[0] += d[0]
            row[1] += d[1]
            if d[0] or d[1]:
                scoring.append((label, e["clock"], e["result"], sc))
            prev = sc
        graded = [e for e in s.log if e["grade"] is not None and not e["auto"]]
        avg = sum(e["grade"] for e in graded) / len(graded) if graded else None
        st = s.stats
        parts = [f"<h1>{esc(s.user_team)} {s.user_score} - {s.ai_score} {esc(s.ai_team)}</h1>",
                 f"<p>{esc(WEATHER[s.weather]['desc'])} | difficulty {esc(s.difficulty)} | officiating "
                 f"{esc(s.penalty_level.title())}{' | ended early' if s.ended_early else ''}</p>",
                 "<h2>Scoring by period</h2><table><tr><th>Period</th><th>" + esc(s.user_team) + "</th><th>" +
                 esc(s.ai_team) + "</th></tr>" +
                 "".join(f"<tr><td>{esc(k)}</td><td>{v[0]}</td><td>{v[1]}</td></tr>" for k, v in periods.items()) +
                 "</table>",
                 "<h2>Your offense</h2><p>" +
                 f"{st['plays']} plays, {st['yards']} yards, {st['third_conv']}/{st['third_att']} on 3rd down, "
                 f"{st['tds']} touchdowns, {st['giveaways']} turnovers, {st['takeaways']} takeaways by your defense; "
                 f"{st['pen']} penalties for {st['pen_yds']} yards (opponent {st['opp_pen']} for {st['opp_pen_yds']}).</p>",
                 "<h2>Coaching grade</h2><p>" + (f"{letter_grade(avg)} ({avg:.1f} average over {len(graded)} graded "
                                                 "calls)" if graded else "No graded calls.") + "</p>",
                 "<h2>Scoring plays</h2><ul>" + "".join(
                     f"<li>{esc(a)} {esc(b)}: {esc(c)} <b>({d[0]}-{d[1]})</b></li>" for a, b, c, d in scoring) +
                 "</ul>",
                 "<h2>Play by play</h2><table><tr><th>#</th><th>Period</th><th>Situation</th><th>Ball</th>"
                 "<th>Play</th><th>Result</th><th>Grade</th></tr>" + "".join(
                     f"<tr><td>{e['n']}</td><td>{esc(e.get('ql') or 'Q' + str(e['q']))} {esc(e['clock'])}</td>"
                     f"<td>{esc(e['dd'])} @ {esc(e['spot'])}</td><td>{esc(e['off_team'])}</td>"
                     f"<td>{esc(e['title2'])}</td><td>{esc(e['short'])}</td><td>{esc(e['letter'] or '-')}</td></tr>"
                     for e in s.log) + "</table>"]
        page = ("<!doctype html><meta charset='utf-8'><title>Game summary</title><style>body{font-family:Arial,"
                "sans-serif;background:#141820;color:#eee;max-width:980px;margin:24px auto;padding:0 16px}"
                "table{border-collapse:collapse;width:100%}td,th{border:1px solid #334;padding:4px 8px;text-align:left;"
                "font-size:13px}th{background:#1e2430}h1,h2{color:#00a896}</style>" + "".join(parts))
        path = os.path.join(BASE_DIR, f"game_summary_{time.strftime('%Y%m%d_%H%M%S')}.html")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(page)
            self.export_msg = f"Saved {os.path.basename(path)} next to the game files."
        except OSError as exc:
            self.export_msg = f"Export failed: {exc}"

    def quit(self):
        self.running = False

    def draw_match_settings(self):
        self.back_button()
        draw_text(win, "MATCH SETUP", font_xl, COLOR_ACCENT, (WIDTH // 2, 22), "midtop")
        rows = [
            ("Quarter Length", "qtr_mins", [("3 Min", 3), ("5 Min", 5), ("10 Min", 10), ("15 Min", 15)], None),
            ("Match Length", "structure", [("1 Qtr", "1_QTR"), ("1st Half", "1ST_HALF"), ("Full Game", "FULL")], None),
            ("Play Clock", "pc_speed",
             [("REAL TIME", 1.0), ("FAST (2x)", 2.0), ("OFF", 0.0)],
             {1.0: "NCAA 40s (25s after a stoppage); the game clock runs with it.",
              2.0: "Same rules, but play-clock seconds pass twice as fast.",
              0.0: "No play clock or delay of game; the clock burns a fixed amount per snap."}),
            ("Officiating", "penalty_level", [("NONE", "NONE"), ("BLIND REFS", "BLIND"), ("BAD REFS", "BAD"),
                                              ("STICKLERS", "STICKLERS")],
             {"NONE": "No penalties at all.", "BLIND": "Flags are rare (about 1 in 60 snaps).",
              "BAD": "Some calls (about 1 in 21).", "STICKLERS": "Real-life rate (about 1 in 14)."}),
            ("Difficulty", "difficulty", [("ROOKIE", "ROOKIE"), ("VARSITY", "VARSITY"),
                                          ("ALL-AMERICAN", "ALL-AMERICAN"), ("HEISMAN", "HEISMAN")],
             {"ROOKIE": "Weaker, less sharp AI that never adapts to you.",
              "VARSITY": "Even ratings; the AI adapts to your tendencies a little.",
              "ALL-AMERICAN": "AI is a bit better and counters what you keep calling.",
              "HEISMAN": "Best AI: sharper calls, a ratings edge and strong counters."}),
            ("Weather", "weather_choice", [("RANDOM", "RANDOM"), ("CLEAR", "CLEAR"), ("WIND", "WIND"),
                                           ("RAIN", "RAIN"), ("SNOW", "SNOW")],
             {"RANDOM": "Rolled when the game starts.", "CLEAR": "No effect.",
              "WIND": "Hurts kicking and deep passes.", "RAIN": "Fumbles up, passing and punting down.",
              "SNOW": "Harshest on passing, fumbles and kicking."}),
            ("Home Field", "home_choice", [("YOU", "USER"), ("OPPONENT", "AI"), ("NEUTRAL", "NONE"),
                                           ("RANDOM", "RANDOM")],
             {"USER": "Small ratings edge for you; the opponent's offense draws more false starts.",
              "AI": "Small ratings edge for the opponent and more false starts for your offense.",
              "NONE": "No home team.", "RANDOM": "Decided when the game starts."}),
        ]
        x0, total_w = WIDTH // 2 - 300, 600
        for i, (label, attr, opts, notes) in enumerate(rows):
            y = 72 + i * 80
            note = notes.get(getattr(self, attr)) if notes else None
            draw_text(win, label, font_md, COLOR_TEXT_WHITE, (x0, y))
            if note:
                draw_text(win, note, font_sm, COLOR_TEXT_MUTED, (x0 + total_w, y + 2), "topright")
            n = len(opts)
            bw = (total_w - (n - 1) * 8) // n
            for j, (lbl, val) in enumerate(opts):
                self.button((x0 + j * (bw + 8), y + 22, bw, 36), lbl, lambda a=attr, v=val: setattr(self, a, v),
                            "selected" if getattr(self, attr) == val else "normal", font_sm)
        self.button((WIDTH // 2 - 150, 646, 300, 50), "CONTINUE TO ROLES", lambda: self.goto("ROLE_SELECT"),
                    "accent", font_lg)

    def draw_role_select(self):
        self.back_button()
        draw_text(win, "SELECT COACHING ROLE", font_xl, COLOR_ACCENT, (WIDTH // 2, 100), "midtop")
        opts = [("HC", "1. Head Coach (Offense & Defense)", "You call every play."),
                ("OC", "2. Offensive Coordinator (Offense Only)", "Your DC calls the defense for you."),
                ("DC", "3. Defensive Coordinator (Defense Only)", "Your OC calls the offense for you.")]
        for i, (role, label, sub) in enumerate(opts):
            y = 190 + i * 95
            self.button((WIDTH // 2 - 200, y, 400, 60), label, lambda r=role: self.pick_role(r),
                        "accent" if role == "HC" else "normal", font_lg)
            draw_text(win, sub, font_sm, COLOR_TEXT_MUTED, (WIDTH // 2, y + 64), "midtop")

    def pick_role(self, role):
        self.role = role
        self.goto("SELECT_USER_CONF")

    def draw_conf_select(self, user):
        self.back_button()
        title = "SELECT YOUR CONFERENCE" if user else f"SELECT OPPONENT CONFERENCE FOR {self.user_team}"
        draw_text(win, title, font_xl, COLOR_ACCENT, (WIDTH // 2, 55), "midtop")
        for idx, conf in enumerate(FBS_CONFERENCES):
            col, row = idx % 3, idx // 3
            n = len(FBS_CONFERENCES[conf])
            self.button((120 + col * 360, 130 + row * 62, 340, 50), f"{conf}  ({n} teams)",
                        lambda c=conf: self.pick_conf(user, c), font=font_lg)

    def pick_conf(self, user, conf):
        if user:
            self.conf_user = conf
            self.goto("SELECT_USER_TEAM")
        else:
            self.conf_ai = conf
            self.goto("SELECT_AI_TEAM")

    def draw_team_select(self, user):
        self.back_button()
        conf = self.conf_user if user else self.conf_ai
        title = f"SELECT YOUR PROGRAM ({conf})" if user else f"SELECT OPPONENT ({conf})"
        draw_text(win, title, font_xl, COLOR_ACCENT, (WIDTH // 2, 55), "midtop")
        for idx, (team, attrs) in enumerate(FBS_CONFERENCES[conf].items()):
            col, row = idx % 3, idx // 3
            ok = user or team != self.user_team
            self.button((120 + col * 360, 130 + row * 46, 340, 40), f"{team}  ({attrs['OVR']} OVR)",
                        lambda t=team: self.pick_team(user, t), enabled=ok)

    def pick_team(self, user, team):
        if user:
            self.user_team = team
            self.book_sel = default_books(team, get_team_attrs(team))
            if self.mode == "SEASON":
                self.new_season()
                return
            self.goto("SELECT_AI_CONF")
        else:
            self.ai_team = team
            self.goto("SELECT_PLAYBOOK")

    def draw_select_playbook(self):
        self.back_button()
        draw_text(win, "CHOOSE YOUR PLAYBOOKS", font_xl, COLOR_ACCENT, (WIDTH // 2, 28), "midtop")
        ai = default_books(self.ai_team, get_team_attrs(self.ai_team))
        draw_text(win, f"{self.ai_team} will run {ai['OFFENSE']} on offense and {ai['DEFENSE']} on defense.",
                  font_md, COLOR_TEXT_MUTED, (WIDTH // 2, 68), "midtop")
        default = default_books(self.user_team, get_team_attrs(self.user_team))
        for col, side in enumerate(SIDES):
            x0 = 80 + col * 600
            draw_text(win, f"{side} PLAYBOOK", font_lg, COLOR_ACCENT, (x0, 100))
            for i, name in enumerate(book_names(side)):
                label = name + ("   (suggested for your team)" if name == default[side] else "")
                self.button((x0, 130 + i * 34, 520, 30), label,
                            lambda s=side, n=name: self.book_sel.__setitem__(s, n),
                            "selected" if self.book_sel[side] == name else "normal")
            sel = self.book_sel[side]
            if sel in PHILOSOPHIES[side]:
                ph = PHILOSOPHIES[side][sel]
                nforms = len([f for f in ph["formations"] if f in self.playbook[side]])
                desc = f"{ph['desc']}  ({nforms} formations + your custom ones)"
            else:
                desc = (f"Every formation in the library: {len(self.playbook[side])} formations, "
                        f"{len(self.catalog(side))} plays.")
            draw_wrapped(win, desc, font_md, COLOR_TEXT_WHITE, x0, 130 + len(book_names(side)) * 34 + 10, 520)
        self.button((WIDTH // 2 - 150, 650, 300, 52), "KICK OFF", self.start_game, "accent", font_lg)

    # ============================================================ PLAYBOOK VIEW
    def draw_playbook_view(self):
        self.back_button()
        draw_text(win, "MASTER PLAYBOOK LIBRARY", font_lg, COLOR_ACCENT, (WIDTH // 2, 8), "midtop")
        for i, sd in enumerate(SIDES):
            self.button((WIDTH // 2 - 160 + i * 164, 34, 156, 32), sd,
                        lambda sd=sd: setattr(self, "pb_side", sd), "selected" if self.pb_side == sd else "normal")
        side = self.pb_side
        name = self.pb_sel[side]
        self.button((WIDTH // 2 + 176, 34, 300, 32), f"BOOK: {self.pb_book[side]}  (click to change)",
                    lambda: self.cycle_pb_book(side), font=font_sm)
        self.draw_playbook_panel(side, pygame.Rect(20, 75, 320, 620), True, name,
                                 lambda n: self.pb_sel.__setitem__(side, n), self.pb_book[side])
        field_rect = pygame.Rect(355, 75, 570, 620)
        self.draw_field(field_rect, 25, 10)
        fname, play = self.find_play(side, name)
        if play:
            toks = self.make_tokens(side, fname, name)
            other = self.default_tokens("DEFENSE" if side == "OFFENSE" else "OFFENSE")
            o, d = (toks, other) if side == "OFFENSE" else (other, toks)
            self.ball = [450, 360]
            self.draw_tokens(o, d, COLOR_OFFENSE, COLOR_DEFENSE, route_sides=(side,))
        panel = pygame.Rect(940, 75, 320, 620)
        pygame.draw.rect(win, COLOR_PANEL, panel, border_radius=6)
        if not play:
            return
        x, y = panel.x + 16, panel.y + 14
        draw_text(win, "PLAY DETAILS", font_md, COLOR_ACCENT, (x, y))
        y += 28
        y = draw_wrapped(win, name, font_lg, COLOR_TEXT_WHITE, x, y, panel.w - 32)
        draw_text(win, f"Formation: {fname}", font_sm, COLOR_TEXT_MUTED, (x, y + 4))
        draw_text(win, play_tag(play), font_md, COLOR_ACCENT, (x, y + 26))
        y += 56
        if side == "OFFENSE":
            draw_text(win, f"Ball target: {play['target_receiver']}", font_sm, COLOR_TEXT_WHITE, (x, y))
            y += 20
        n_routes = sum(1 for r in play["route"].values() if r)
        draw_text(win, f"Players with routes: {n_routes}", font_sm, COLOR_TEXT_WHITE, (x, y))
        y += 40
        fav = name in self.playbook["FAVORITES"]
        self.button((x, y, panel.w - 32, 38), "REMOVE FROM FAVORITES" if fav else "ADD TO FAVORITES",
                    lambda: self.toggle_favorite(name))
        self.button((x, y + 48, panel.w - 32, 38), "EDIT IN PLAYMAKER STUDIO",
                    lambda: self.studio_open_play(side, name), "accent")

    def cycle_pb_book(self, side):
        names = book_names(side)
        self.pb_book[side] = names[(names.index(self.pb_book[side]) + 1) % len(names)]
        self.ensure_selection()
        fn, _ = self.find_play(side, self.pb_sel[side])
        if fn:
            self.expanded[side].add(fn)

    # ============================================================ GAME FLOW
    def start_game(self):
        weather = (self.weather_choice if self.weather_choice != "RANDOM"
                   else random.choices(["CLEAR", "WIND", "RAIN", "SNOW"], [55, 17, 18, 10])[0])
        home = ({"USER": "USER", "AI": "AI", "NONE": None}[self.home_choice] if self.home_choice != "RANDOM"
                else random.choice(["USER", "AI"]))
        self.s = Session(self.user_team, self.ai_team, self.role, self.qtr_mins, self.structure, self.pc_speed,
                         user_book=dict(self.book_sel),
                         ai_book=default_books(self.ai_team, get_team_attrs(self.ai_team)),
                         penalty_level=self.penalty_level, difficulty=self.difficulty, weather=weather, home=home)
        self.pause_msg = ""
        self.hold = 0.0
        self.after_hold = None
        self.fx = None
        self.ensure_selection()
        where = f"{self.s.team(home)} is the home team" if home else "Neutral site"
        self.result_text = (f"{WEATHER[weather]['desc']}. {where}. Coin toss: "
                            f"{self.s.team(self.s.opening_receiver)} will receive the opening kickoff.")
        self.goto("PLAY_GAME")
        self.next_step()

    def user_side(self):
        return "OFFENSE" if self.s.possession == "USER" else "DEFENSE"

    def user_controls(self):
        on_off = self.s.possession == "USER"
        return self.s.role == "HC" or (self.s.role == "OC") == on_off

    def coordinator_role(self):
        return "DC" if self.s.role == "OC" else "OC"

    def bias_for(self, side, who):
        book = (self.s.user_book if who == "USER" else self.s.ai_book)[side]
        bias = dict(PHILOSOPHIES[side].get(book, {}))
        if who == "AI":
            bias.update(adapt_bias(self.s, side))
        return bias

    def ratings(self, who):
        """Position-group ratings for a team right now: home field, difficulty, fatigue and injuries included."""
        s = self.s
        r = dict(derive_groups(s.team(who)))
        bonus = (2.0 if s.home == who else 0.0) + (DIFFICULTY[s.difficulty][0] if who == "AI" else 0.0)
        for k in ("OFF", "DEF", "QB", "RB", "WR", "OL", "DL", "LB", "DB"):
            r[k] += bonus
        for g in TRACKED:
            r[g] += s.fatigue_adj(who, g)
        return r

    def make_pre(self):
        s = self.s
        c = special_ctx(s, s.possession)
        return {"down": s.down, "dist": s.distance, "yard": s.yard_line, "quarter": s.quarter, "clock": s.clock,
                "poss": s.possession, "maxq": s.max_quarters, "lead": c["lead"], "ql": s.period_label()}

    def base_entry(self, pre):
        s = self.s
        return {"q": pre["quarter"], "ql": pre["ql"],
                "clock": "--" if pre["ql"].startswith("OT") else fmt_clock(pre["clock"]),
                "dd": dd_text(pre["down"], pre["dist"], pre["yard"]), "spot": spot_text(pre["yard"]),
                "poss": pre["poss"], "off_team": s.team(pre["poss"]), "def_team": s.team(other(pre["poss"])),
                "auto": self.call_auto, "grade": None, "letter": None, "sit": None, "match": None, "res": None,
                "analysis": [], "off_play": "", "def_play": "", "off_tag": "", "def_tag": "", "title2": "",
                "short": "", "result": ""}

    def log_entry(self, entry):
        entry["score"] = [self.s.user_score, self.s.ai_score]
        entry["n"] = len(self.s.log) + 1
        self.s.log.append(entry)

    def conclude(self, text, entry, hold=2.6):
        """Record a finished play and show its result; the next step starts automatically after `hold` seconds."""
        self.log_entry(entry)
        t2 = entry.get("title2", "")
        if "TOUCHDOWN" in text:
            self.sound("cheer")
        elif "FLAG" in text:
            self.sound("flag")
        elif t2 in ("PUNT", "FIELD GOAL", "DEEP KICKOFF", "SQUIB KICK", "ONSIDE KICK", "EXTRA POINT"):
            self.sound("kick")
        else:
            self.sound("whistle")
        self.result_text = text
        self.game_state = "PLAY_ENDED"
        self.hold = hold + (1.0 if ("TOUCHDOWN" in text or "GOOD" in text) else 0.0)
        self.after_hold = self.next_step

    def skip_hold(self):
        if self.game_state == "PLAY_ENDED" and self.after_hold:
            fn, self.after_hold, self.hold = self.after_hold, None, 0.0
            fn()

    def next_step(self):
        """Decide what happens next: conversion try, period change, kickoff, report card or the next snap."""
        s = self.s
        self.after_hold = None
        if s.pending and s.pending["type"] == "CONV":
            self.begin_conversion()
            return
        msg = s.check_period_end()
        if msg:
            self.sound("horn")
            self.result_text = msg
            self.game_state = "PLAY_ENDED"
            self.tok_off, self.tok_def = [], []
            self.hold = 4.0 if s.game_over else 3.0
            self.after_hold = self.next_step
            return
        if s.game_over:
            self.finish_game()
            return
        if s.pending and s.pending["type"] == "OT_START":
            s.start_ot_series(s.pending)
            self.begin_play_call()
            return
        if s.pending and s.pending["type"] == "KICKOFF":
            self.begin_kickoff()
            return
        self.begin_play_call()

    def finish_game(self):
        self.record_season_result()
        self.export_msg = ""
        self.goto("REPORT_CARD")

    # --------------------------------------------------------------- play calling
    def begin_play_call(self):
        s = self.s
        self.ensure_selection()
        uside = self.user_side()
        aside = "DEFENSE" if uside == "OFFENSE" else "OFFENSE"
        pre = self.make_pre()
        controls = self.user_controls()
        self.calls[aside] = ai_pick_play(aside, self.ai_plays(aside), s.down, s.distance, s.yard_line, pre,
                                         self.bias_for(aside, "AI"), DIFFICULTY[s.difficulty][1])
        if controls and self.sel[uside] in self.user_plays(uside):
            self.calls[uside] = self.sel[uside]
        else:
            self.calls[uside] = ai_pick_play(uside, self.user_plays(uside), s.down, s.distance, s.yard_line, pre,
                                             self.bias_for(uside, "USER"))
        self.call_auto = not controls
        self.game_state = "PLAY_CALL"
        self.aud_meta = {"OFFENSE": None, "DEFENSE": None}
        self.aud_used, self.aud_note, self.fx = False, "", None
        tired = min(TRACKED, key=lambda g: s.stamina["AI"][g])
        if s.stamina["AI"][tired] < 50 and s.subs_left["AI"] > 0:
            s.sub("AI", tired)
        self.pc_max = self.pc = float(s.pc_next)
        self._tick_last = 99
        hurry = ai_hurry(special_ctx(s, s.possession))
        self.ai_snap_at = max(0.0, self.pc_max - random.uniform(5, 12)) if hurry else random.uniform(2, 8)
        self.ai_wait = random.uniform(10, 16)
        ai_c = special_ctx(s, "AI")
        self.ai_to_pending = ai_wants_timeout(ai_c)
        self.build_tokens()

    def select_play(self, side, name):
        self.sel[side] = name
        if self.game_state == "PLAY_CALL" and side == self.user_side() and self.user_controls():
            self.calls[side] = name
            self.build_tokens()

    def build_tokens(self):
        fo, _ = self.find_play("OFFENSE", self.calls["OFFENSE"])
        fd, _ = self.find_play("DEFENSE", self.calls["DEFENSE"])
        self.tok_off = self.make_tokens("OFFENSE", fo, self.calls["OFFENSE"])
        self.tok_def = self.make_tokens("DEFENSE", fd, self.calls["DEFENSE"])
        self.qb_token = next(t for t in self.tok_off if t.label == "QB")
        tgt = self.playbook["OFFENSE"][fo]["plays"][self.calls["OFFENSE"]]["target_receiver"]
        self.target_token = next((t for t in self.tok_off if t.label == tgt), self.qb_token)
        self.ball = [self.qb_token.x, self.qb_token.y]

    def user_on_offense_controls(self):
        s = self.s
        return (self.game_state == "PLAY_CALL" and s.possession == "USER" and self.user_controls() and not s.conv)

    def can_user_kick(self):
        return self.user_on_offense_controls() and self.s.down == 4

    def can_clock_play(self):
        return self.user_on_offense_controls() and self.s.down < 4

    def snap(self):
        if self.game_state != "PLAY_CALL":
            return
        s = self.s
        if not s.conv and (s.possession == "AI" or not self.user_controls()):
            choice = ai_special_choice(special_ctx(s, s.possession))
            if choice:
                self.do_special(choice)
                return
        pen = roll_presnap(s)
        if pen:
            self.dead_ball_penalty(pen)
            return
        if s.pc_speed <= 0 and s.clock_running:
            s.clock = max(0.0, s.clock - random.randint(10, 22))
        self.build_tokens()
        self.game_state = "LIVE_PLAY"
        self.anim = 0
        self.sound("snap")
        self.result_text = "Play in progress..."

    # ------------------------------------------------------- clock / timeouts / specials
    def tick_play_clock(self, dt):
        s = self.s
        ai_off = s.possession == "AI" or not self.user_controls()
        if s.pc_speed <= 0:
            self.ai_wait -= dt
            if ai_off and self.ai_wait <= 0:
                self.snap()
            return
        sim = dt * s.pc_speed
        self.pc -= sim
        v = math.ceil(self.pc)
        if 0 < v <= 5 and v != self._tick_last:
            self._tick_last = v
            self.sound("tick")
        if s.clock_running:
            s.clock = max(0.0, s.clock - sim)
            if s.clock <= 0:
                self.next_step()
                return
        if self.ai_to_pending and self.pc <= self.pc_max - 1.5:
            self.ai_to_pending = False
            self.do_timeout("AI")
            return
        if ai_off and self.pc <= self.ai_snap_at:
            self.snap()
        elif self.pc <= 0:
            self.play_clock_expired()

    def play_clock_expired(self):
        s = self.s
        if s.possession == "USER" and self.user_controls() and not s.conv and s.penalty_level != "NONE":
            self.dead_ball_penalty({"name": "Delay of Game", "team": "OFF", "yards": 5, "auto_first": False,
                                    "loss_down": False, "presnap": True})
        else:
            self.snap()

    def do_timeout(self, who):
        s = self.s
        if s.timeouts[who] <= 0 or self.game_state != "PLAY_CALL":
            return
        pre = self.make_pre()
        text, _ = s.call_timeout(who)
        e = self.base_entry(pre)
        e.update(title2="TIMEOUT", short=s.team(who), result=text, analysis=[["TIMEOUT", text]], auto=False)
        self.log_entry(e)
        self.result_text = text
        self.pc_max = self.pc = 25.0
        hurry = ai_hurry(special_ctx(s, s.possession))
        self.ai_snap_at = max(0.0, 25.0 - random.uniform(5, 12)) if hurry else random.uniform(2, 8)
        self.ai_to_pending = False

    def do_special(self, kind):
        """PUNT, FG, KNEEL or SPIKE (called by the user's buttons or by an AI coach at the snap)."""
        s = self.s
        if self.game_state != "PLAY_CALL" or (kind == "PUNT" and s.ot):
            return
        who = s.possession
        pre = self.make_pre()
        c = special_ctx(s, who)
        text, info = {"PUNT": s.punt, "FG": s.field_goal, "KNEEL": s.kneel, "SPIKE": s.spike}[kind]()
        e = self.base_entry(pre)
        e["title2"] = {"PUNT": "PUNT", "FG": "FIELD GOAL", "KNEEL": "QB KNEEL", "SPIKE": "SPIKE"}[kind]
        e["short"] = {"PUNT": f"{info.get('net', 0)} yd net", "FG": "GOOD" if info.get("made") else "NO GOOD",
                      "KNEEL": "Kneel", "SPIKE": "Clock stopped"}[kind]
        if kind == "PUNT" and info.get("td"):
            e["short"] = "RETURNED FOR TD"
        e["result"] = text
        if who == "USER":
            g = grade_special(kind, c, info)
            e.update(grade=g["overall"], letter=letter_grade(g["overall"]), sit=g["sit"], match=g["match"],
                     res=g["result"], analysis=g["analysis"])
        else:
            e["analysis"] = [["SPECIAL TEAMS", text + " Your defense is not graded on special-teams or clock plays."]]
        self.conclude(text, e)

    def dead_ball_penalty(self, pen):
        s = self.s
        pre = self.make_pre()
        committer = pre["poss"] if pen["team"] == "OFF" else other(pre["poss"])
        text, info = s.apply_penalty(pen)
        e = self.base_entry(pre)
        e.update(title2="PENALTY", short=f"{pen['name']} ({info['pen']['yards']})", result=text,
                 analysis=[["PENALTY", text + (" (Called on your team.)" if committer == "USER" else
                                               " (Called on the opponent.)")]])
        self.conclude(text, e, hold=2.4)

    # ------------------------------------------------------------------- kickoffs / tries
    def begin_kickoff(self):
        s = self.s
        s.start_kickoff(s.pending)
        self.tok_off, self.tok_def = [], []
        self.ball = [LOS_X - 20, 360]
        self.pc = self.pc_max = 0.0
        if s.possession == "USER":
            self.game_state = "KICKOFF_CHOICE"
        else:
            self.do_kickoff(kickoff_ideal(special_ctx(s, "AI")))

    def do_kickoff(self, kind):
        s = self.s
        who = s.possession
        c = special_ctx(s, who)
        pre = self.make_pre()
        text, info = s.kickoff(kind)
        e = self.base_entry(pre)
        e.update(dd="Kickoff", title2={"DEEP": "DEEP KICKOFF", "SQUIB": "SQUIB KICK", "ONSIDE": "ONSIDE KICK"}[kind],
                 short=("Return TD" if info["td"] else "Recovered" if info["recovered"] else
                        "Onside failed" if kind == "ONSIDE" else f"to {spot_text(info['recv_yard'])}"),
                 result=text, off_team=s.team(who), def_team=s.team(other(who)), auto=False)
        if who == "USER":
            g = grade_special(kind, c, info)
            e.update(grade=g["overall"], letter=letter_grade(g["overall"]), sit=g["sit"], match=g["match"],
                     res=g["result"], analysis=g["analysis"])
        else:
            e["analysis"] = [["KICKOFF", text]]
        self.conclude(text, e, hold=3.0)

    def begin_conversion(self):
        s = self.s
        who = s.pending["team"]
        self.tok_off, self.tok_def = [], []
        self.ball = [LOS_X - 20, 360]
        self.pc = self.pc_max = 0.0
        if s.ot and s.ot["n"] >= 3:      # NCAA: from the 3rd overtime on, every try is a two-point play
            self.do_conversion("TWO")
        elif who == "USER":
            self.game_state = "CONV_CHOICE"
        else:
            self.do_conversion(ai_conv_choice(special_ctx(s, "AI")))

    def do_conversion(self, choice):
        s = self.s
        who = s.pending["team"]
        c = special_ctx(s, who)
        if choice == "XP":
            pre = self.make_pre()
            text, info = s.extra_point()
            e = self.base_entry(pre)
            e.update(dd="Try", spot="OPP 15", title2="EXTRA POINT", short="GOOD" if info["made"] else "NO GOOD",
                     result=text, off_team=s.team(who), def_team=s.team(other(who)), auto=False)
            if who == "USER":
                g = grade_special("XP", c, info)
                e.update(grade=g["overall"], letter=letter_grade(g["overall"]), sit=g["sit"], match=g["match"],
                         res=g["result"], analysis=g["analysis"])
            else:
                e["analysis"] = [["EXTRA POINT", text]]
            self.conclude(text, e, hold=2.4)
        else:
            s.start_two_point()
            self.begin_play_call()
            self.result_text = f"{s.team(s.possession)} goes for two from the 3-yard line!"

    # ------------------------------------------------------------------ the snap itself
    def eff_meta(self, side):
        return self.aud_meta[side] or self.find_play(side, self.calls[side])[1]

    def geo_bonus(self, off):
        """Where the players actually ended up matters: a covered target or a crowded carrier hurts the play."""
        tgt, defs = self.target_token, self.tok_def
        if not tgt or not defs:
            return 0.0
        if off["is_run"]:
            crowd = sum(1 for d in defs if math.hypot(d.x - tgt.x, d.y - tgt.y) <= 6 * PX_PER_YD)
            return clamp((3 - crowd) * 0.10, -0.4, 0.4)
        sep = min(math.hypot(d.x - tgt.x, d.y - tgt.y) for d in defs) / PX_PER_YD
        return clamp((sep - 3.5) * 0.12, -0.5, 0.6)

    def make_fx(self, res, info):
        out = res["outcome"]
        if info.get("pen_accepted"):
            self.fx = {"label": "FLAG", "pt": tuple(self.ball), "t": 0.0, "tackle": False}
            return
        src = self.qb_token if out == "SACK" else self.target_token
        label = {"RUN": "TACKLE", "COMPLETE": "CATCH", "SACK": "SACK", "FUMBLE": "FUMBLE", "INT": "INTERCEPTED",
                 "INCOMPLETE": "INCOMPLETE"}[out]
        if info["td"]:
            label = "TOUCHDOWN"
        self.fx = {"label": label, "pt": (src.x, src.y), "t": 0.0,
                   "tackle": out in ("RUN", "COMPLETE", "SACK", "FUMBLE") and not info["td"]}

    def skip_play(self):
        if self.game_state == "LIVE_PLAY" and self.anim > int(20 * FS):
            self.fast_forward()

    def fast_forward(self):
        while self.anim < MAX_ANIM_FRAMES:
            self.anim += 1
            for tk in self.tok_off + self.tok_def:
                tk.step(ANIM_SPEED)
        self.ball = [self.target_token.x, self.target_token.y]
        self.finish_play()

    def finish_play(self):
        s = self.s
        off_name, def_name = self.calls["OFFENSE"], self.calls["DEFENSE"]
        off, dfn = self.eff_meta("OFFENSE"), self.eff_meta("DEFENSE")
        pre = self.make_pre()
        off_who = s.possession
        user_off = off_who == "USER"
        off_team = s.team(off_who)
        def_team = s.team(other(off_who))
        conv = s.conv
        res = simulate_snap(off, dfn, self.ratings(off_who), self.ratings(other(off_who)), s.env(),
                            self.geo_bonus(off))
        if not conv:
            s.wear(off, dfn)
        pen = roll_live(s, off, dfn, res)
        if conv:
            text, info = s.apply_two_point(res)
            pen = None
        elif pen and s.decide_penalty(pen, res):
            text, info = s.apply_penalty(pen)
        else:
            text, info = s.apply_offense(res)
            if pen:
                info["pen"], info["pen_accepted"] = pen, False
                committer = off_team if pen["team"] == "OFF" else def_team
                text = f"Flag on the play: {pen['name']} on {committer}, DECLINED.\n" + text
        self.make_fx(res, info)
        if not conv:
            inj = s.roll_injury()
            if inj:
                text += "\n" + inj
        (s.hist["off"] if user_off else s.hist["def"]).append(
            1 if (user_off and off["is_run"]) or (not user_off and dfn["blitz"]) else 0)
        del s.hist["off"][:-20], s.hist["def"][:-20]
        g = grade_snap("OFFENSE" if user_off else "DEFENSE", pre, off_name, off, def_name, dfn, res, info,
                       self.user_plays("OFFENSE"), self.user_plays("DEFENSE"))
        if self.aud_used:
            g["analysis"].insert(0, ["AUDIBLE", self.aud_note])
        out = res["outcome"]
        e = self.base_entry(pre)
        e.update(off_play=off_name, def_play=def_name, off_tag=play_tag(off), def_tag=play_tag(dfn),
                 title2=("2-PT TRY: " if conv else "") + f"{off_name} vs {def_name}",
                 result=text.replace("\n", " "), grade=g["overall"], letter=letter_grade(g["overall"]),
                 sit=g["sit"], match=g["match"], res=g["result"], analysis=g["analysis"], gain=info["gain"])
        if conv:
            e["short"] = "2-PT GOOD" if info["td"] else "2-PT FAILED"
            e.update(dd="2-pt try", spot="OPP 3")
        elif info.get("pen_accepted"):
            e["short"] = f"{info['pen']['name']} ({info['pen']['yards']})"
        elif info["td"]:
            e["short"] = "TD"
        elif info["safety"]:
            e["short"] = "SAFETY"
        elif out in ("INT", "FUMBLE"):
            e["short"] = "INT" if out == "INT" else "FUMBLE"
        elif out == "SACK":
            e["short"] = f"Sack {info['gain']}"
        elif out == "INCOMPLETE":
            e["short"] = "Incomplete"
        else:
            e["short"] = f"{info['gain']:+d} yds" + (" 1st" if info["first_down"] else "")
        self.conclude(text, e)

    # ------------------------------------------------------------- audibles / rotations
    def audible_options(self):
        """Which audibles are available right now: {'HOT'|'FLIP'|'BLITZ': bool} for the user's side."""
        if self.game_state != "PLAY_CALL" or self.aud_used or not self.user_controls():
            return {}
        side = self.user_side()
        base = self.find_play(side, self.calls[side])[1]
        if side == "OFFENSE":
            name = self.calls[side]
            alt = self.flip_name(name)
            return {"HOT": apply_audible(base, "HOT") is not None, "FLIP": bool(alt)}
        return {"BLITZ": apply_audible(base, "BLITZ") is not None, "FLIP": apply_audible(base, "SHELL") is not None}

    def flip_name(self, name):
        for a, b in ((" Left", " Right"), (" Right", " Left")):
            if name.endswith(a):
                alt = name[:-len(a)] + b
                return alt if alt in self.catalog("OFFENSE") else None
        return None

    def do_audible(self, kind):
        if not self.audible_options().get(kind):
            return
        side = self.user_side()
        base = self.find_play(side, self.calls[side])[1]
        if side == "OFFENSE" and kind == "FLIP":
            self.calls[side] = self.flip_name(self.calls[side])
            self.build_tokens()
            self.aud_note = "You flipped the play to the other side after seeing the defense's alignment."
        elif side == "OFFENSE":
            self.aud_meta[side] = apply_audible(base, "HOT")
            self.aud_note = "You checked to a hot route: a quick throw that beats pressure but gives up yardage."
        elif kind == "BLITZ":
            self.aud_meta[side] = apply_audible(base, "BLITZ")
            self.aud_note = "You checked into a blitz after seeing the offense's formation."
        else:
            self.aud_meta[side] = apply_audible(base, "SHELL")
            self.aud_note = "You flipped the coverage between zone and man at the line."
        self.aud_used = True

    def do_rotate(self, group):
        s = self.s
        if self.game_state != "PLAY_CALL":
            return
        text = s.sub("USER", group)
        if text:
            self.result_text = text

    def update(self):
        if self.scene != "PLAY_GAME" or self.overlay or self.modal:
            return
        gs = self.game_state
        if gs == "LIVE_PLAY":
            self.anim += 1
            for t in self.tok_off:
                t.step(ANIM_SPEED)
            for t in self.tok_def:
                t.step(ANIM_SPEED)
            if self.anim < int(40 * FS):
                self.ball = [self.qb_token.x, self.qb_token.y]
            else:
                k = 1 - 0.9 ** (1 / FS)
                self.ball[0] += (self.target_token.x - self.ball[0]) * k
                self.ball[1] += (self.target_token.y - self.ball[1]) * k
            if self.anim >= MAX_ANIM_FRAMES:
                self.finish_play()
        elif gs == "PLAY_CALL":
            self.tick_play_clock(self.dt)
        elif gs == "PLAY_ENDED":
            if self.fx:
                self.fx["t"] += self.dt
                if self.fx["tackle"] and self.fx["t"] < 1.4:
                    px, py = self.fx["pt"]
                    for d in self.tok_def:
                        if math.hypot(d.x - px, d.y - py) <= 90:
                            d.drift(px, py, 2.2 / FS)
            if self.after_hold:
                self.hold -= self.dt
                if self.hold <= 0:
                    self.skip_hold()

    # ----------------------------------------------------- pause / save / end
    def open_pause(self):
        self.overlay = "PAUSE"
        self.pause_msg = ""

    def open_log(self, back):
        self.log_back = back
        n = len(self.s.log)
        self.goto("PLAY_LOG")
        self.log_sel = max(0, n - 1)
        self.scroll["log"] = max(0, n * 54 - 500)

    def log_back_action(self):
        if self.log_back == "PAUSE":
            self.goto("PLAY_GAME")
            self.overlay = "PAUSE"
        else:
            self.goto(self.log_back)

    def save_game(self, slot=0):
        if self.s.game_over:
            self.pause_msg = "This game is finished - nothing to save."
            return
        stamp = time.strftime("%Y-%m-%d %H:%M")
        payload = {"version": 3, "saved_at": stamp, "session": self.s.__dict__, "sel": self.sel,
                   "season_game": self.season_game}
        try:
            write_json_atomic(slot_path(slot), payload)
            self.overlay = "PAUSE"
            self.refresh_save_info()
            self.pause_msg = f"Saved to slot {slot + 1} at {stamp}. Use LOAD SAVED GAME on the main menu to resume."
        except OSError as exc:
            self.pause_msg = f"Save failed: {exc}"

    def load_game(self, slot=0):
        try:
            payload = read_json(slot_path(slot))
            s = Session.from_dict(payload["session"])
        except (OSError, ValueError, KeyError, TypeError) as exc:
            self.menu_msg = f"Could not load save: {exc}"
            return
        self.menu_msg = ""
        self.s = s
        self.season_game = payload.get("season_game")
        saved_sel = payload.get("sel")
        if isinstance(saved_sel, dict):
            for side in SIDES:
                if side in saved_sel:
                    self.sel[side] = saved_sel[side]
        self.ensure_selection()
        self.pause_msg = ""
        self.result_text = "Game loaded."
        self.goto("PLAY_GAME")
        self.next_step()

    def end_game_now(self):
        self.s.game_over = True
        self.s.ended_early = True
        self.finish_game()

    def draw_overlay(self):
        win.blit(self.dim, (0, 0))
        s = self.s
        box = pygame.Rect(WIDTH // 2 - 230, 140, 460, 440)
        pygame.draw.rect(win, COLOR_PANEL, box, border_radius=10)
        pygame.draw.rect(win, COLOR_ACCENT, box, 2, border_radius=10)
        if self.overlay == "PAUSE":
            draw_text(win, "GAME PAUSED", font_xl, COLOR_ACCENT, (box.centerx, box.y + 20), "midtop")
            draw_text(win, f"{s.user_team} {s.user_score}  -  {s.ai_score} {s.ai_team}   |   {s.period_label()} {s.clock_text()}",
                      font_md, COLOR_TEXT_WHITE, (box.centerx, box.y + 64), "midtop")
            x, w = box.x + 40, box.w - 80
            self.button((x, box.y + 100, w, 50), "RESUME", lambda: setattr(self, "overlay", None), "accent", font_lg)
            self.button((x, box.y + 165, w, 50), "PLAY LOG", lambda: self.open_log("PAUSE"), font=font_lg)
            self.button((x, box.y + 230, w, 50), "SAVE GAME", lambda: setattr(self, "overlay", "SAVE_SLOTS"),
                        font=font_lg)
            self.button((x, box.y + 295, w, 50), "END GAME", lambda: setattr(self, "overlay", "CONFIRM_END"),
                        "danger", font_lg)
            if not IS_WEB:
                self.button((x, box.y + 360, w, 34), f"SOUND: {'ON' if self.sound_on else 'OFF'}",
                            self.toggle_sound, font=font_sm)
            if self.pause_msg:
                draw_wrapped(win, self.pause_msg, font_sm, COLOR_TEXT_MUTED, x, box.y + 402, w)
        elif self.overlay == "SAVE_SLOTS":
            draw_text(win, "SAVE TO WHICH SLOT?", font_xl, COLOR_ACCENT, (box.centerx, box.y + 22), "midtop")
            for i in range(3):
                r = pygame.Rect(box.x + 30, box.y + 80 + i * 84, box.w - 60, 70)
                self.button(r, "", lambda i=i: self.save_game(i))
                draw_text(win, f"SLOT {i + 1}", font_md, COLOR_TEXT_WHITE, (r.x + 14, r.y + 10))
                draw_text(win, fit_text(self.slot_info[i] or "(empty)", font_sm, r.w - 28), font_sm,
                          COLOR_TEXT_MUTED, (r.x + 14, r.y + 38))
            self.button((box.x + 30, box.y + 340, box.w - 60, 44), "BACK", lambda: setattr(self, "overlay", "PAUSE"))
        else:
            draw_text(win, "END THIS GAME?", font_xl, COLOR_BAD, (box.centerx, box.y + 30), "midtop")
            draw_wrapped(win, "The current score becomes final and you'll see your report card. "
                              "Unsaved progress is lost. Use SAVE GAME first if you want to finish later.",
                         font_md, COLOR_TEXT_WHITE, box.x + 40, box.y + 100, box.w - 80)
            x, w = box.x + 40, box.w - 80
            self.button((x, box.y + 250, w, 50), "YES, END GAME", self.end_game_now, "danger", font_lg)
            self.button((x, box.y + 315, w, 50), "NO, GO BACK", lambda: setattr(self, "overlay", "PAUSE"), "accent",
                        font_lg)

    # ================================================================ GAME UI
    def draw_play_game(self):
        s = self.s
        gs = self.game_state
        hud = pygame.Rect(20, 15, WIDTH - 40, 45)
        pygame.draw.rect(win, COLOR_PANEL, hud, border_radius=6)
        ua, aa = get_team_attrs(s.user_team), get_team_attrs(s.ai_team)
        if gs == "KICKOFF_CHOICE":
            situ = f"Kickoff from {spot_text(s.yard_line)}"
        elif gs == "CONV_CHOICE":
            situ = "Try after touchdown"
        elif s.conv:
            situ = "2-point try from the 3"
        else:
            situ = f"{dd_text(s.down, s.distance, s.yard_line)}   |   Ball: {spot_text(s.yard_line)}"
        line = (f"{s.user_team} ({ua['OVR']}) {s.user_score}  -  {s.ai_team} ({aa['OVR']}) {s.ai_score}"
                f"   |   {s.period_label()} {s.clock_text()}   |   {situ}")
        draw_text(win, line, font_md, COLOR_TEXT_WHITE, (hud.x + 15, hud.centery), "midleft")
        home = f"Home: {s.team(s.home)}" if s.home else "Neutral site"
        draw_text(win, f"{WEATHER[s.weather]['desc']}  |  {home}", font_sm, COLOR_TEXT_MUTED,
                  (hud.right - 160, hud.centery), "midright")
        self.button((hud.right - 150, hud.y + 5, 140, 35), "PAUSE [ESC]", self.open_pause)

        uside = self.user_side()
        selectable = self.user_controls() and gs == "PLAY_CALL"
        self.draw_playbook_panel(uside, pygame.Rect(20, 75, 320, 620), selectable, self.sel[uside],
                                 lambda n: self.select_play(uside, n), s.user_book[uside])
        in_play = gs in ("PLAY_CALL", "LIVE_PLAY")
        los = 97 if gs == "CONV_CHOICE" else s.yard_line
        self.draw_field(pygame.Rect(355, 75, 570, 620), los, s.distance if in_play else None)
        off_col, def_col = ((COLOR_OFFENSE, COLOR_DEFENSE) if s.possession == "USER"
                            else (COLOR_DEFENSE, COLOR_OFFENSE))
        routes = (uside,) if gs == "PLAY_CALL" else ()
        self.draw_tokens(self.tok_off, self.tok_def, off_col, def_col, routes)
        self.draw_fx()
        self.draw_game_panel(pygame.Rect(940, 75, 320, 620))

    def draw_clock_widget(self, r):
        s = self.s
        live = self.game_state == "PLAY_CALL" and s.pc_speed > 0
        if s.pc_speed <= 0:
            txt, col = "OFF", COLOR_TEXT_MUTED
        elif live:
            v = max(0, math.ceil(self.pc))
            txt, col = str(v), (COLOR_BAD if v <= 5 else COLOR_TEXT_WHITE)
        else:
            txt, col = "--", COLOR_TEXT_MUTED
        draw_text(win, "PLAY CLOCK", font_sm, COLOR_TEXT_MUTED, (r.x, r.y))
        draw_text(win, txt, font_xl, col, (r.x, r.y + 12))
        bx = r.x + 82
        draw_text(win, f"Game clock {'RUNNING' if s.clock_running else 'STOPPED'}", font_sm,
                  COLOR_ACCENT if s.clock_running else COLOR_TEXT_MUTED, (bx, r.y))
        bar = pygame.Rect(bx, r.y + 20, r.w - 82, 10)
        pygame.draw.rect(win, COLOR_BG_DARK, bar, border_radius=5)
        if live and self.pc_max > 0:
            frac = clamp(self.pc / self.pc_max, 0, 1)
            pygame.draw.rect(win, COLOR_BAD if self.pc <= 5 else COLOR_ACCENT,
                             (bar.x, bar.y, int(bar.w * frac), bar.h), border_radius=5)
        draw_text(win, f"Timeouts: you {s.timeouts['USER']}  |  opponent {s.timeouts['AI']}", font_sm,
                  COLOR_TEXT_MUTED, (bx, r.y + 34))

    def draw_audible_row(self, x, y, w):
        opts = self.audible_options()
        half = (w - 6) // 2
        labels = ([("HOT", "HOT ROUTE [A]"), ("FLIP", "FLIP PLAY [D]")] if self.user_side() == "OFFENSE"
                  else [("BLITZ", "BLITZ CHECK [A]"), ("FLIP", "FLIP COVERAGE [D]")])
        for i, (k, label) in enumerate(labels):
            self.button((x + i * (half + 6), y, half, 28), label, lambda k=k: self.do_audible(k), font=font_sm,
                        enabled=bool(opts.get(k)))

    def draw_stamina(self, x, y, w):
        s = self.s
        draw_text(win, f"STAMINA  (click a bar to rotate; {s.subs_left['USER']} left)", font_sm, COLOR_TEXT_MUTED, (x, y))
        for i, g in enumerate(TRACKED):
            ry = y + 14 + i * 12
            v = s.stamina["USER"][g]
            out = g in s.injured["USER"]
            draw_text(win, g, font_xs, COLOR_BAD if out else COLOR_TEXT_WHITE, (x, ry))
            bar = pygame.Rect(x + 28, ry + 2, w - 60, 8)
            pygame.draw.rect(win, COLOR_BG_DARK, bar, border_radius=4)
            col = (0, 200, 120) if v > 65 else (230, 200, 40) if v > 40 else COLOR_BAD
            pygame.draw.rect(win, col, (bar.x, bar.y, int(bar.w * v / 100), bar.h), border_radius=4)
            draw_text(win, "INJ" if out else f"{int(v)}", font_xs, COLOR_BAD if out else COLOR_TEXT_MUTED,
                      (bar.right + 6, ry))
            self.add_target(pygame.Rect(x, ry, w, 12), lambda g=g: self.do_rotate(g))

    def draw_fx(self):
        fx = self.fx
        if not fx or self.game_state != "PLAY_ENDED":
            return
        px, py = int(fx["pt"][0]), int(fx["pt"][1])
        pygame.draw.circle(win, COLOR_FIRST_DOWN_YELLOW, (px, py), 16 + int(6 * math.sin(fx["t"] * 9)), 3)
        draw_text(win, fx["label"], font_lg, COLOR_FIRST_DOWN_YELLOW, (px, py - 30), "center")

    def draw_game_panel(self, rect):
        s = self.s
        gs = self.game_state
        pygame.draw.rect(win, COLOR_PANEL, rect, border_radius=6)
        x, w = rect.x + 14, rect.w - 28
        uside = self.user_side()
        controls = self.user_controls()
        if gs == "KICKOFF_CHOICE":
            head = "YOU ARE KICKING OFF"
        elif gs == "CONV_CHOICE":
            head = "CHOOSE YOUR TRY"
        else:
            head = f"YOU ARE ON {uside}" + ("  (2-PT TRY)" if s.conv else "")
        draw_text(win, head, font_lg, COLOR_ACCENT, (x, rect.y + 10))
        draw_text(win, fit_text(f"{ROLE_NAMES[s.role]}  |  {s.user_book[uside] or 'Full library'}", font_sm, w),
                  font_sm, COLOR_TEXT_MUTED, (x, rect.y + 34))
        self.draw_clock_widget(pygame.Rect(x, rect.y + 54, w, 50))
        by = rect.y + 214

        if gs == "KICKOFF_CHOICE":
            draw_text(win, f"{s.team(s.possession)} kicks off from {spot_text(s.yard_line)}", font_md,
                      COLOR_TEXT_WHITE, (x, rect.y + 116))
            self.button((x, rect.y + 140, w, 46), "DEEP KICK  [1]", lambda: self.do_kickoff("DEEP"), "accent", font_lg)
            self.button((x, rect.y + 194, w, 46), "SQUIB KICK  [2]", lambda: self.do_kickoff("SQUIB"), font=font_lg)
            self.button((x, rect.y + 248, w, 46), "ONSIDE KICK  [3]", lambda: self.do_kickoff("ONSIDE"), font=font_lg)
            draw_wrapped(win, "Deep: touchback (to the 30) about 6 times in 10. Squib: no touchback, but the return "
                              "starts a bit further out. Onside: roughly a 1-in-8 chance to recover.",
                         font_sm, COLOR_TEXT_MUTED, x, rect.y + 302, w)
        elif gs == "CONV_CHOICE":
            draw_text(win, f"{s.team(s.possession)} just scored. Score is {s.user_score}-{s.ai_score}.", font_md,
                      COLOR_TEXT_WHITE, (x, rect.y + 116))
            self.button((x, rect.y + 140, w, 50), "KICK EXTRA POINT  (94%)  [1]", lambda: self.do_conversion("XP"),
                        "accent", font_md)
            self.button((x, rect.y + 200, w, 50), "GO FOR TWO  [2]", lambda: self.do_conversion("TWO"), font=font_md)
            draw_wrapped(win, "Going for two means you call a real play from the 3-yard line: a gain of 3 yards "
                              "scores 2 points.", font_sm, COLOR_TEXT_MUTED, x, rect.y + 262, w)
        else:
            draw_text(win, f"{s.team(s.possession)} ball  |  {dd_text(s.down, s.distance, s.yard_line)}  |  "
                           f"{spot_text(s.yard_line)}", font_md, COLOR_TEXT_WHITE, (x, rect.y + 112))
            call_name = self.calls[uside]
            fname, call = self.find_play(uside, call_name)
            box = pygame.Rect(x, rect.y + 136, w, 70)
            pygame.draw.rect(win, (25, 32, 42), box, border_radius=6)
            head2 = "YOUR CALL" if controls else f"YOUR {self.coordinator_role()} CALLED"
            draw_text(win, head2, font_sm, COLOR_TEXT_MUTED, (box.x + 10, box.y + 6))
            draw_text(win, fit_text(short_name(call_name), font_md, box.w - 20), font_md, COLOR_TEXT_WHITE,
                      (box.x + 10, box.y + 22))
            draw_text(win, fit_text(str(fname), font_sm, box.w - 20), font_sm, COLOR_TEXT_MUTED, (box.x + 10, box.y + 40))
            if call:
                draw_text(win, fit_text(play_tag(call), font_sm, box.w - 20), font_sm, COLOR_ACCENT,
                          (box.x + 10, box.y + 54))
            if gs == "PLAY_CALL":
                self.button((x, by, w, 44), "SNAP  [SPACE]", self.snap, "accent", font_lg)
                half, third = (w - 6) // 2, (w - 12) // 3
                to_n = s.timeouts["USER"]
                to_ok = to_n > 0 and not s.conv
                if self.user_on_offense_controls():
                    fgp = int(s.fg_chance(117 - s.yard_line) * 100)
                    self.button((x, by + 50, half, 32), "PUNT [P]", lambda: self.do_special("PUNT"), font=font_sm,
                                enabled=s.down == 4 and not s.ot)
                    self.button((x + half + 6, by + 50, half, 32), f"FIELD GOAL {fgp}% [F]",
                                lambda: self.do_special("FG"), font=font_sm, enabled=117 - s.yard_line <= 68)
                    self.button((x, by + 88, third, 32), "KNEEL [K]", lambda: self.do_special("KNEEL"), font=font_sm,
                                enabled=s.down < 4)
                    self.button((x + third + 6, by + 88, third, 32), "SPIKE [S]", lambda: self.do_special("SPIKE"),
                                font=font_sm, enabled=s.down < 4)
                    self.button((x + 2 * (third + 6), by + 88, third, 32), f"TIMEOUT {to_n} [T]",
                                lambda: self.do_timeout("USER"), font=font_sm, enabled=to_ok)
                    self.draw_audible_row(x, by + 124, w)
                else:
                    self.button((x, by + 50, w, 32), f"CALL TIMEOUT ({to_n} left) [T]",
                                lambda: self.do_timeout("USER"), font=font_sm, enabled=to_ok)
                    if controls:
                        self.draw_audible_row(x, by + 88, w)
            elif gs == "LIVE_PLAY":
                draw_text(win, "Play in progress...", font_md, COLOR_TEXT_MUTED, (x, by + 4))
                self.button((x, by + 28, w, 34), "SKIP PLAY", self.skip_play, font=font_sm)
            else:
                nxt = max(0, math.ceil(self.hold))
                draw_text(win, f"Next: starts automatically ({nxt})", font_md, COLOR_TEXT_MUTED, (x, by + 4))
                self.button((x, by + 28, w, 34), "SKIP  [SPACE]", self.skip_hold, font=font_sm)

        ry = rect.y + (372 if gs in ("KICKOFF_CHOICE", "CONV_CHOICE") else 382)
        draw_text(win, "RESULT", font_sm, COLOR_TEXT_MUTED, (x, ry))
        draw_wrapped(win, self.result_text, font_md, COLOR_TEXT_WHITE, x, ry + 18, w, max_lines=4)
        self.draw_stamina(x, rect.y + 470, w)

        if s.log:
            e = s.log[-1]
            gy = rect.bottom - 80
            pygame.draw.line(win, COLOR_PANEL_BORDER, (x, gy - 8), (x + w, gy - 8), 1)
            draw_text(win, "LAST PLAY GRADE", font_sm, COLOR_TEXT_MUTED, (x, gy))
            if e["grade"] is not None:
                draw_text(win, e["letter"], font_xl, grade_color(e["grade"]), (x, gy + 16))
                draw_text(win, fit_text(f"{e['grade']:.0f}/100  {e['title2'][:34]}" + ("  (auto)" if e["auto"] else ""),
                                        font_sm, w - 70), font_sm, COLOR_TEXT_MUTED, (x + 70, gy + 28))
            else:
                draw_text(win, "Not graded", font_md, COLOR_TEXT_MUTED, (x, gy + 20))
            draw_text(win, "Pause > Play Log for the full analysis", font_sm, COLOR_TEXT_MUTED, (x, gy + 62))

    # ============================================================== PLAY LOG
    def select_log(self, i):
        self.log_sel = i

    def draw_play_log(self):
        s = self.s
        self.back_button(self.log_back_action)
        draw_text(win, f"PLAY LOG  -  {s.user_team} {s.user_score} : {s.ai_score} {s.ai_team}", font_lg,
                  COLOR_ACCENT, (WIDTH // 2, 28), "midtop")
        left = pygame.Rect(20, 75, 620, 620)
        det = pygame.Rect(655, 75, 605, 620)
        pygame.draw.rect(win, COLOR_PANEL, left, border_radius=6)
        pygame.draw.rect(win, COLOR_PANEL, det, border_radius=6)
        log = s.log
        if not log:
            draw_text(win, "No plays have been run yet.", font_lg, COLOR_TEXT_MUTED, left.center, "center")
            return
        self.log_sel = clamp(self.log_sel, 0, len(log) - 1)
        view = pygame.Rect(left.x + 8, left.y + 8, left.w - 16, left.h - 16)
        row_h, gap = 50, 4
        content_h = len(log) * (row_h + gap)
        off = self.scroll_area("log", view, content_h)
        win.set_clip(view)
        for i, e in enumerate(log):
            r = pygame.Rect(view.x, view.y + i * (row_h + gap) - off, view.w - 10, row_h)
            if r.bottom < view.y or r.y > view.bottom:
                continue
            sel = i == self.log_sel
            hover = r.collidepoint(self.mouse) and view.collidepoint(self.mouse)
            pygame.draw.rect(win, (55, 75, 95) if sel else COLOR_PANEL_LIGHT if hover else (36, 43, 55), r,
                             border_radius=5)
            if sel:
                pygame.draw.rect(win, COLOR_ACCENT, r, 1, border_radius=5)
            draw_text(win, fit_text(f"#{e['n']}  {e.get('ql') or 'Q' + str(e['q'])} {e['clock']}  |  {e['dd']} @ {e['spot']}  |  "
                                    f"{e['off_team']} ball", font_sm, r.w - 70), font_sm, COLOR_TEXT_MUTED,
                      (r.x + 10, r.y + 7))
            draw_text(win, fit_text(f"{e['title2']}  -  {e['short']}", font_sm, r.w - 70), font_sm,
                      COLOR_TEXT_WHITE, (r.x + 10, r.y + 27))
            draw_text(win, e["letter"] or "--", font_lg, grade_color(e["grade"]), (r.right - 14, r.centery), "midright")
            self.add_target(r, lambda i=i: self.select_log(i), clip=view)
        win.set_clip(None)
        self.draw_scrollbar(view, off, content_h)

        e = log[self.log_sel]
        x, w = det.x + 18, det.w - 36
        y = det.y + 14
        draw_text(win, f"PLAY #{e['n']}  -  {e.get('ql') or 'Q' + str(e['q'])} {e['clock']}", font_lg, COLOR_ACCENT, (x, y))
        draw_text(win, f"{e['dd']} at {e['spot']}  |  {e['off_team']} on offense", font_md, COLOR_TEXT_WHITE,
                  (x, y + 28))
        ty = y + 52
        if e["off_play"]:
            draw_text(win, fit_text(f"Offense: {e['off_play']}  [{e['off_tag']}]", font_sm, w - 130), font_sm,
                      COLOR_TEXT_WHITE, (x, ty))
            draw_text(win, fit_text(f"Defense: {e['def_play']}  [{e['def_tag']}]", font_sm, w - 130), font_sm,
                      COLOR_TEXT_WHITE, (x, ty + 18))
        else:
            draw_text(win, e["title2"], font_sm, COLOR_TEXT_WHITE, (x, ty))
        if e["auto"]:
            draw_text(win, f"(called by your {self.coordinator_role()})", font_sm, COLOR_TEXT_MUTED,
                      (x, ty + 36))
        ry = ty + 56
        ry = draw_wrapped(win, f"Result: {e['result']}", font_sm, COLOR_TEXT_MUTED, x, ry, w - 130, max_lines=3)
        # grade badge
        bx = det.right - 90
        draw_text(win, e["letter"] or "--", font_xxl, grade_color(e["grade"]), (bx, det.y + 40), "center")
        if e["grade"] is not None:
            draw_text(win, f"{e['grade']:.0f}/100", font_sm, COLOR_TEXT_MUTED, (bx, det.y + 80), "center")
            by = max(ry + 6, det.y + 130)
            for lbl, val in (("Situation", e["sit"]), ("Opponent's call", e["match"]), ("Result", e["res"])):
                if val is None:
                    continue
                draw_text(win, lbl, font_sm, COLOR_TEXT_WHITE, (x, by))
                bar = pygame.Rect(x + 120, by + 2, 220, 12)
                pygame.draw.rect(win, COLOR_BG_DARK, bar, border_radius=6)
                pygame.draw.rect(win, grade_color(val), (bar.x, bar.y, int(bar.w * val / 100), bar.h), border_radius=6)
                draw_text(win, f"{val:.0f}", font_sm, COLOR_TEXT_MUTED, (bar.right + 10, by))
                by += 22
        else:
            by = ry + 6
            draw_text(win, "Not graded", font_sm, COLOR_TEXT_MUTED, (bx, det.y + 80), "center")
        by += 8
        self.button((x, by, 200, 32), "HIDE ANALYSIS" if self.log_analysis else "ANALYZE PLAY",
                    lambda: setattr(self, "log_analysis", not self.log_analysis), "accent")
        if self.log_analysis:
            area = pygame.Rect(x, by + 44, w, det.bottom - 12 - (by + 44))
            heights = []
            for head, text in e["analysis"]:
                heights.append(20 + len(_wrap(text, font_md, area.w - 12)) * 18 + 10)
            content_h = sum(heights)
            aoff = self.scroll_area("log_detail", area, content_h)
            win.set_clip(area)
            yy = area.y - aoff
            for (head, text), hh in zip(e["analysis"], heights):
                draw_text(win, head, font_sm, COLOR_ACCENT, (area.x, yy))
                draw_wrapped(win, text, font_md, COLOR_TEXT_WHITE, area.x, yy + 18, area.w - 12, line_h=18)
                yy += hh
            win.set_clip(None)
            self.draw_scrollbar(area, aoff, content_h)

    # ============================================================ REPORT CARD
    def draw_report_card(self):
        s = self.s
        draw_text(win, "COACHING REPORT CARD", font_xl, COLOR_ACCENT, (WIDTH // 2, 40), "midtop")
        if s.user_score > s.ai_score:
            verdict, vcol = "VICTORY", (0, 200, 120)
        elif s.user_score < s.ai_score:
            verdict, vcol = "DEFEAT", COLOR_BAD
        else:
            verdict, vcol = "TIE GAME", COLOR_FAVORITE_GOLD
        draw_text(win, f"{s.user_team} {s.user_score}  -  {s.ai_score} {s.ai_team}", font_xl, COLOR_TEXT_WHITE,
                  (WIDTH // 2, 100), "midtop")
        tail = ("  (game ended early)" if s.ended_early else
                f"  (overtime: {s.ot['n']} period{'s' if s.ot['n'] > 1 else ''})" if s.ot else "")
        draw_text(win, verdict + tail, font_lg, vcol, (WIDTH // 2, 140), "midtop")
        if self.season_note:
            draw_text(win, self.season_note, font_md, COLOR_FAVORITE_GOLD, (WIDTH // 2, 168), "midtop")

        st = s.stats
        third = f"{st['third_conv']}/{st['third_att']}" + (
            f" ({100 * st['third_conv'] // st['third_att']}%)" if st["third_att"] else "")
        left = pygame.Rect(180, 190, 440, 360)
        right = pygame.Rect(660, 190, 440, 360)
        for r in (left, right):
            pygame.draw.rect(win, COLOR_PANEL, r, border_radius=8)
        draw_text(win, "YOUR OFFENSE", font_md, COLOR_ACCENT, (left.x + 20, left.y + 16))
        rows = [("Plays run", st["plays"]), ("Total yards", st["yards"]),
                ("Yards per play", f"{st['yards'] / st['plays']:.1f}" if st["plays"] else "-"),
                ("3rd-down conversions", third), ("Touchdowns", st["tds"]),
                ("Turnovers committed", st["giveaways"]), ("Takeaways by your defense", st["takeaways"]),
                ("Your penalties", f"{st['pen']} for {st['pen_yds']} yds"),
                ("Opponent penalties", f"{st['opp_pen']} for {st['opp_pen_yds']} yds")]
        for i, (k, v) in enumerate(rows):
            draw_text(win, k, font_md, COLOR_TEXT_MUTED, (left.x + 20, left.y + 52 + i * 32))
            draw_text(win, str(v), font_md, COLOR_TEXT_WHITE, (left.right - 20, left.y + 52 + i * 32), "topright")

        graded = [e for e in s.log if e["grade"] is not None and not e["auto"]]
        draw_text(win, "COACHING GRADES", font_md, COLOR_ACCENT, (right.x + 20, right.y + 16))
        if graded:
            avg = sum(e["grade"] for e in graded) / len(graded)
            draw_text(win, letter_grade(avg), font_xxl, grade_color(avg), (right.x + 70, right.y + 85), "center")
            draw_text(win, f"{avg:.1f} avg over {len(graded)} graded calls", font_sm, COLOR_TEXT_MUTED,
                      (right.x + 140, right.y + 66))
            counts = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
            for e in graded:
                counts[e["letter"][0]] += 1
            draw_text(win, "   ".join(f"{k}: {v}" for k, v in counts.items()), font_md, COLOR_TEXT_WHITE,
                      (right.x + 140, right.y + 88))
            best = max(graded, key=lambda e: e["grade"])
            worst = min(graded, key=lambda e: e["grade"])
            draw_text(win, "BEST CALL", font_sm, COLOR_TEXT_MUTED, (right.x + 20, right.y + 140))
            draw_text(win, fit_text(f"#{best['n']} {best['title2']}", font_sm, right.w - 90), font_sm,
                      COLOR_TEXT_WHITE, (right.x + 20, right.y + 158))
            draw_text(win, best["letter"], font_lg, grade_color(best["grade"]), (right.right - 20, right.y + 150),
                      "topright")
            draw_text(win, "WORST CALL", font_sm, COLOR_TEXT_MUTED, (right.x + 20, right.y + 200))
            draw_text(win, fit_text(f"#{worst['n']} {worst['title2']}", font_sm, right.w - 90), font_sm,
                      COLOR_TEXT_WHITE, (right.x + 20, right.y + 218))
            draw_text(win, worst["letter"], font_lg, grade_color(worst["grade"]), (right.right - 20, right.y + 210),
                      "topright")
        else:
            draw_text(win, "No graded calls yet.", font_md, COLOR_TEXT_MUTED, (right.x + 20, right.y + 70))
        if self.export_msg:
            draw_text(win, self.export_msg, font_sm, COLOR_TEXT_MUTED, (WIDTH // 2, 556), "midtop")
        self.button((WIDTH // 2 - 320, 576, 300, 46), "VIEW PLAY LOG", lambda: self.open_log("REPORT_CARD"), font=font_md)
        self.button((WIDTH // 2 + 20, 576, 300, 46), "EXPORT SUMMARY (HTML)", self.export_summary, font=font_md)
        self.button((WIDTH // 2 - 320, 630, 300, 46), "RETURN TO MAIN MENU", lambda: self.goto("MAIN_MENU"),
                    "normal" if self.season_note else "accent", font_md)
        if self.season_note:
            self.button((WIDTH // 2 + 20, 630, 300, 46), "BACK TO SEASON", lambda: (self.goto("SEASON_HUB"),
                                                                                    setattr(self, "mode", "SEASON")),
                        "accent", font_md)

    # =========================================================== PLAYMAKER STUDIO
    def studio_reset(self):
        self.st_side = "OFFENSE"
        self.st_mode = "FORMATION"
        self.st_form = next(iter(self.playbook["OFFENSE"]))
        self.st_align = copy.deepcopy(self.playbook["OFFENSE"][self.st_form]["alignment"])
        self.st_drag = None
        self.st_sel = None
        self.st_msg = ("", 0.0)
        self.studio_new_play()

    def open_studio(self):
        self.studio_reset()
        self.goto("PLAYMAKER_STUDIO")

    def studio_msg(self, text):
        self.st_msg = (text, time.time() + 4.0)

    def studio_default_meta(self):
        if self.st_side == "OFFENSE":
            return {"is_run": False, "depth": "MEDIUM", "target_receiver": "WR1", "style": "DROPBACK"}
        return {"coverage": "ZONE", "blitz": False, "box": "NORMAL"}

    def studio_new_play(self):
        self.st_name = ""
        self.st_orig = None
        self.st_routes = {}
        self.st_meta = self.studio_default_meta()
        self.st_sel = None

    def studio_set_side(self, side):
        if side == self.st_side:
            return
        self.st_side = side
        self.studio_select_form(next(iter(self.playbook[side])))
        self.studio_new_play()

    def studio_saved_align(self):
        return self.playbook[self.st_side][self.st_form]["alignment"]

    def studio_select_form(self, name):
        self.st_form = name
        self.st_align = copy.deepcopy(self.playbook[self.st_side][name]["alignment"])
        self.st_drag = None

    def studio_set_mode(self, mode):
        if mode == self.st_mode:
            return
        if self.st_mode == "FORMATION" and self.st_align != self.studio_saved_align():
            self.studio_msg("Unsaved formation edits were discarded.")
            self.studio_select_form(self.st_form)
        self.st_mode = mode
        self.st_drag = None

    def studio_open_play(self, side, name):
        self.open_studio()
        self.st_side = side
        self.st_mode = "PLAY"
        self.studio_load_play(name)
        self.goto("PLAYMAKER_STUDIO")

    def studio_load_play(self, name):
        fname, play = self.find_play(self.st_side, name)
        if not play:
            return
        self.studio_select_form(fname)
        self.st_routes = {k: [list(p) for p in v] for k, v in play["route"].items()}
        keys = (("is_run", "depth", "target_receiver", "style") if self.st_side == "OFFENSE"
                else ("coverage", "blitz", "box"))
        self.st_meta = {k: play[k] for k in keys}
        self.st_name = name
        self.st_orig = name
        self.st_sel = None

    def studio_new_formation(self):
        side = self.st_side

        def ok(name):
            self.playbook[side][name] = {"alignment": copy.deepcopy(self.st_align), "plays": {},
                                         "names": dict(self.playbook[side][self.st_form].get("names", {}))}
            self.save_playbook()
            self.studio_select_form(name)
            self.studio_msg("Formation created. Drag players, then SAVE FORMATION.")

        self.open_modal("NEW FORMATION NAME", "", ok,
                        lambda n: "That formation already exists." if n in self.playbook[side] else None)

    def studio_rename_formation(self):
        side, old = self.st_side, self.st_form

        def ok(name):
            if name == old:
                return
            self.playbook[side] = {(name if k == old else k): v for k, v in self.playbook[side].items()}
            self.expanded[side].discard(old)
            self.st_form = name
            self.save_playbook()
            self.studio_msg("Formation renamed.")

        self.open_modal("RENAME FORMATION", old, ok,
                        lambda n: "That formation already exists." if n != old and n in self.playbook[side] else None)

    def studio_save_formation(self):
        self.playbook[self.st_side][self.st_form]["alignment"] = copy.deepcopy(self.st_align)
        self.save_playbook()
        self.studio_msg(f"Formation '{self.st_form}' saved.")

    def studio_reset_align(self):
        self.st_align = copy.deepcopy(DEFAULT_ALIGN[self.st_side])

    def studio_delete_formation(self):
        side = self.st_side
        forms = self.playbook[side]
        total = sum(len(f["plays"]) for f in forms.values())
        removing = len(forms[self.st_form]["plays"])
        if len(forms) <= 1 or total - removing < 1:
            self.studio_msg("Keep at least one formation that contains a play.")
            return
        if not self.confirm(("del_form", side, self.st_form)):
            return
        del forms[self.st_form]
        self.expanded[side].discard(self.st_form)
        self.save_playbook()
        self.studio_select_form(next(iter(forms)))
        self.studio_msg("Formation deleted.")

    def studio_save_play(self):
        side = self.st_side
        name = self.st_name.strip()
        if not name:
            self.studio_msg("Name the play first (click the name box).")
            return
        existing_form, _ = self.find_play(side, name)
        if existing_form and name != self.st_orig:
            self.studio_msg(f"'{name}' already exists in {existing_form}. Pick another name.")
            return
        if self.st_meta.get("is_run") is not None:
            key = self.st_meta["target_receiver"]
            if not self.st_routes.get(key):
                what = "ball carrier" if self.st_meta["is_run"] else "target receiver"
                self.studio_msg(f"Draw a route for the {what} ({key}) first.")
                return
        play = dict(self.st_meta)
        play["route"] = {k: [list(p) for p in v] for k, v in self.st_routes.items() if v}
        forms = self.playbook[side]
        if self.st_orig:
            old_form, _ = self.find_play(side, self.st_orig)
            if old_form:
                del forms[old_form]["plays"][self.st_orig]
            if self.st_orig != name and self.st_orig in self.playbook["FAVORITES"]:
                i = self.playbook["FAVORITES"].index(self.st_orig)
                self.playbook["FAVORITES"][i] = name
        forms[self.st_form]["plays"][name] = play
        self.expanded[side].add(self.st_form)
        self.st_orig = name
        self.st_name = name
        self.save_playbook()
        self.studio_msg(f"Play '{name}' saved under {self.st_form}.")

    def studio_delete_play(self):
        side = self.st_side
        if not self.st_orig:
            self.studio_msg("Load a saved play to delete it.")
            return
        if sum(len(f["plays"]) for f in self.playbook[side].values()) <= 1:
            self.studio_msg("The playbook needs at least one play.")
            return
        if not self.confirm(("del_play", side, self.st_orig)):
            return
        form, _ = self.find_play(side, self.st_orig)
        del self.playbook[side][form]["plays"][self.st_orig]
        self.save_playbook()
        self.studio_msg(f"Play '{self.st_orig}' deleted.")
        self.studio_new_play()

    def studio_rename_play(self):
        self.open_modal("PLAY NAME", self.st_name, lambda n: setattr(self, "st_name", n))

    def studio_set_meta(self, key, value):
        self.st_meta[key] = value
        if key == "is_run":
            self.st_meta["style"] = "INSIDE" if value else "DROPBACK"

    def studio_cycle_style(self):
        lst = RUN_STYLES if self.st_meta["is_run"] else PASS_STYLES
        cur = self.st_meta["style"]
        self.st_meta["style"] = lst[(lst.index(cur) + 1) % len(lst)] if cur in lst else lst[0]

    def studio_cycle_box(self):
        cur = self.st_meta["box"]
        self.st_meta["box"] = BOXES[(BOXES.index(cur) + 1) % len(BOXES)]

    def studio_cycle_target(self):
        labels = LABELS["OFFENSE"]
        cur = self.st_meta["target_receiver"]
        self.st_meta["target_receiver"] = labels[(labels.index(cur) + 1) % len(labels)]

    def studio_undo_point(self):
        if self.st_sel and self.st_routes.get(self.st_sel):
            self.st_routes[self.st_sel].pop()

    def studio_clear_route(self):
        if self.st_sel:
            self.st_routes.pop(self.st_sel, None)

    def draw_playmaker_studio(self):
        self.back_button()
        draw_text(win, "PLAYMAKER STUDIO", font_lg, COLOR_ACCENT, (WIDTH // 2, 18), "midtop")
        draw_text(win, "Create formations and plays", font_sm, COLOR_TEXT_MUTED, (WIDTH // 2, 44), "midtop")
        self.draw_studio_left(pygame.Rect(20, 75, 320, 620))
        self.draw_field(STUDIO_FIELD, 25, None)
        self.draw_studio_field()
        self.draw_studio_right(pygame.Rect(940, 75, 320, 620))

    def draw_studio_field(self):
        side, mode = self.st_side, self.st_mode
        own = COLOR_OFFENSE if side == "OFFENSE" else COLOR_DEFENSE
        other = "DEFENSE" if side == "OFFENSE" else "OFFENSE"
        for lbl, (x, y) in DEFAULT_ALIGN[other].items():
            self.draw_token(x, y, "", (62, 72, 86), text_color=(95, 105, 120))
        labels = LABELS[side]
        names = self.playbook[side][self.st_form].get("names", {})
        if mode == "PLAY":
            rc = route_color(own)
            for lbl in labels:
                pts = [tuple(self.st_align[lbl])] + [tuple(p) for p in self.st_routes.get(lbl, [])]
                draw_route(win, pts, rc)
                for p in self.st_routes.get(lbl, []):
                    pygame.draw.circle(win, rc, (int(p[0]), int(p[1])), 3)
            if self.st_sel:
                for p in self.st_routes.get(self.st_sel, []):
                    pygame.draw.circle(win, (255, 230, 0), (int(p[0]), int(p[1])), 6, 2)
        for lbl in labels:
            x, y = self.st_align[lbl]
            ring = (255, 230, 0) if (mode == "PLAY" and lbl == self.st_sel) else None
            self.draw_token(x, y, names.get(lbl, lbl), own, ring=ring)
        if mode == "PLAY" and side == "OFFENSE":
            tx, ty = self.st_align[self.st_meta["target_receiver"]]
            pygame.draw.ellipse(win, COLOR_BALL, (int(tx) - 7, int(ty) - 30, 14, 10))
        hint = ("Drag players to set the alignment" if mode == "FORMATION" else
                "Click a player, then click the field to add route points (right-click = undo)")
        strip = pygame.Rect(STUDIO_FIELD.x + 12, STUDIO_FIELD.bottom - 40, STUDIO_FIELD.w - 24, 28)
        pygame.draw.rect(win, COLOR_BG_DARK, strip, border_radius=6)
        draw_text(win, hint, font_sm, COLOR_TEXT_WHITE, strip.center, "center")

    def draw_studio_left(self, rect):
        pygame.draw.rect(win, COLOR_PANEL, rect, border_radius=6)
        x, w = rect.x + 10, rect.w - 20
        half = (w - 6) // 2
        for i, sd in enumerate(SIDES):
            self.button((x + i * (half + 6), rect.y + 10, half, 34), sd, lambda sd=sd: self.studio_set_side(sd),
                        "selected" if self.st_side == sd else "normal")
        for i, (lbl, md) in enumerate((("FORMATIONS", "FORMATION"), ("PLAYS", "PLAY"))):
            self.button((x + i * (half + 6), rect.y + 52, half, 34), lbl, lambda md=md: self.studio_set_mode(md),
                        "selected" if self.st_mode == md else "normal")
        play_mode = self.st_mode == "PLAY"
        draw_text(win, "FORMATIONS" + ("  (plays go under the selected one)" if play_mode else ""),
                  font_sm, COLOR_TEXT_MUTED, (x + 2, rect.y + 96))
        fh = 150 if play_mode else 230
        forms = self.playbook[self.st_side]
        items = [(f"{fn}  ({len(f['plays'])})", fn) for fn, f in forms.items()]
        self.draw_pick_list("st_forms", pygame.Rect(x, rect.y + 114, w, fh), items, self.st_form,
                            self.studio_select_form)
        y1 = rect.y + 114 + fh + 8
        self.button((x, y1, half, 32), "+ NEW FORMATION", self.studio_new_formation)
        pending = self.confirm_pending(("del_form", self.st_side, self.st_form))
        self.button((x + half + 6, y1, half, 32), "CONFIRM?" if pending else "DELETE", self.studio_delete_formation,
                    "danger" if pending else "normal")
        if play_mode:
            draw_text(win, fit_text(f"PLAYS IN '{self.st_form}'", font_sm, w), font_sm, COLOR_TEXT_MUTED,
                      (x + 2, y1 + 44))
            plays = self.playbook[self.st_side][self.st_form]["plays"]
            pitems = [(f"({short_tag(p)}) {short_name(n)}", n) for n, p in plays.items()]
            ly = y1 + 62
            lh = rect.bottom - 54 - ly
            self.draw_pick_list("st_plays", pygame.Rect(x, ly, w, lh), pitems, self.st_orig, self.studio_load_play)
            self.button((x, rect.bottom - 44, half, 34), "+ NEW PLAY", self.studio_new_play)
            pending = self.confirm_pending(("del_play", self.st_side, self.st_orig))
            self.button((x + half + 6, rect.bottom - 44, half, 34), "CONFIRM?" if pending else "DELETE PLAY",
                        self.studio_delete_play, "danger" if pending else "normal", enabled=self.st_orig is not None)
        else:
            n = len(self.playbook[self.st_side][self.st_form]["plays"])
            y = y1 + 46
            draw_text(win, f"'{self.st_form}' holds {n} play(s).", font_sm, COLOR_TEXT_WHITE, (x + 2, y))
            draw_wrapped(win, "Select a formation to edit its alignment, or create a new one - a new formation starts "
                              "from the alignment currently on the field.", font_sm, COLOR_TEXT_MUTED, x + 2, y + 22, w - 4)

    def draw_studio_right(self, rect):
        pygame.draw.rect(win, COLOR_PANEL, rect, border_radius=6)
        x, w = rect.x + 14, rect.w - 28
        y = rect.y + 14
        side = self.st_side
        if self.st_mode == "FORMATION":
            draw_text(win, "FORMATION EDITOR", font_md, COLOR_ACCENT, (x, y))
            y += 28
            draw_text(win, fit_text(self.st_form, font_lg, w), font_lg, COLOR_TEXT_WHITE, (x, y))
            y += 30
            dirty = self.st_align != self.studio_saved_align()
            draw_text(win, "* unsaved alignment changes" if dirty else "All changes saved", font_sm,
                      COLOR_FAVORITE_GOLD if dirty else COLOR_TEXT_MUTED, (x, y))
            y += 28
            y = draw_wrapped(win, "Drag any player to a new spot. Offensive players stay behind the line of "
                                  "scrimmage; defenders stay in front of it. Plays you build under this formation "
                                  "start from this alignment.", font_sm, COLOR_TEXT_MUTED, x, y, w)
            y += 16
            self.button((x, y, w, 38), "RENAME FORMATION", self.studio_rename_formation)
            self.button((x, y + 48, w, 38), "RESET TO DEFAULT ALIGNMENT", self.studio_reset_align)
            self.button((x, y + 96, w, 44), "SAVE FORMATION", self.studio_save_formation, "accent", font_lg)
        else:
            draw_text(win, "PLAY EDITOR", font_md, COLOR_ACCENT, (x, y))
            y += 26
            label = self.st_name if self.st_name else "(click to name this play)"
            self.button((x, y, w, 36), fit_text(label, font_md, w - 16), self.studio_rename_play,
                        "selected" if self.st_name else "normal")
            y += 42
            note = f"Formation: {self.st_form}"
            if self.st_orig:
                old_form, _ = self.find_play(side, self.st_orig)
                if old_form and old_form != self.st_form:
                    note += f"  (moves from {old_form})"
            draw_text(win, fit_text(note, font_sm, w), font_sm, COLOR_TEXT_MUTED, (x, y))
            y += 24
            half = (w - 6) // 2
            if side == "OFFENSE":
                m = self.st_meta
                self.button((x, y, half, 34), "RUN", lambda: self.studio_set_meta("is_run", True),
                            "selected" if m["is_run"] else "normal")
                self.button((x + half + 6, y, half, 34), "PASS", lambda: self.studio_set_meta("is_run", False),
                            "selected" if not m["is_run"] else "normal")
                y += 42
                third = (w - 12) // 3
                for i, d in enumerate(DEPTHS):
                    self.button((x + i * (third + 6), y, third, 32), d,
                                lambda d=d: self.studio_set_meta("depth", d),
                                "selected" if m["depth"] == d else "normal", font_sm, enabled=not m["is_run"])
                y += 40
                draw_text(win, "Ball carrier" if m["is_run"] else "Target receiver", font_sm, COLOR_TEXT_MUTED, (x, y + 8))
                self.button((x + 130, y, w - 130, 32), f"{m['target_receiver']}  (click to change)",
                            self.studio_cycle_target, font=font_sm)
                y += 40
                self.button((x, y, w, 32), f"STYLE: {m['style'].replace('_', ' ')}  (click to change)",
                            self.studio_cycle_style, font=font_sm)
                y += 40
            else:
                m = self.st_meta
                self.button((x, y, half, 34), "ZONE", lambda: self.studio_set_meta("coverage", "ZONE"),
                            "selected" if m["coverage"] == "ZONE" else "normal")
                self.button((x + half + 6, y, half, 34), "MAN", lambda: self.studio_set_meta("coverage", "MAN"),
                            "selected" if m["coverage"] == "MAN" else "normal")
                y += 42
                self.button((x, y, w, 34), f"BLITZ: {'ON' if m['blitz'] else 'OFF'}",
                            lambda: self.studio_set_meta("blitz", not m["blitz"]),
                            "selected" if m["blitz"] else "normal")
                y += 40
                self.button((x, y, w, 32), f"BOX: {m['box']}  (click to change)", self.studio_cycle_box,
                            font=font_sm)
                y += 40
            sel_txt = f"Selected: {self.st_sel} ({len(self.st_routes.get(self.st_sel, []))} points)" \
                if self.st_sel else "Selected: none - click a player on the field"
            draw_text(win, sel_txt, font_sm, COLOR_TEXT_WHITE, (x, y))
            y += 22
            third = (w - 12) // 3
            self.button((x, y, third, 32), "UNDO", self.studio_undo_point, font=font_sm)
            self.button((x + third + 6, y, third, 32), "CLEAR ROUTE", self.studio_clear_route, font=font_sm)
            self.button((x + 2 * (third + 6), y, third, 32), "CLEAR ALL",
                        lambda: setattr(self, "st_routes", {}), font=font_sm)
            y += 48
            self.button((x, y, w, 44), "SAVE PLAY", self.studio_save_play, "accent", font_lg)
        text, until = self.st_msg
        if text and time.time() < until:
            draw_wrapped(win, text, font_sm, COLOR_FAVORITE_GOLD, x, rect.bottom - 56, w)

    # --- studio mouse interaction (field area)
    def studio_nearest(self, pos, radius=16):
        best, bd = None, radius
        for lbl in LABELS[self.st_side]:
            x, y = self.st_align[lbl]
            d = math.hypot(x - pos[0], y - pos[1])
            if d <= bd:
                best, bd = lbl, d
        return best

    def studio_clamp(self, pos, token=None):
        x = clamp(round(pos[0] / 5) * 5, STUDIO_FIELD.left + 15, STUDIO_FIELD.right - 15)
        y = clamp(round(pos[1] / 5) * 5, STUDIO_FIELD.top + 15, STUDIO_FIELD.bottom - 15)
        if token:
            x = min(x, 506) if self.st_side == "OFFENSE" else max(x, 514)
        return [x, y]

    def mouse_down_studio(self, pos, button):
        if not STUDIO_FIELD.collidepoint(pos):
            return
        if self.st_mode == "FORMATION":
            if button == 1:
                lbl = self.studio_nearest(pos)
                if lbl:
                    self.st_drag = ("tok", lbl)
            return
        if button == 3:
            self.studio_undo_point()
            return
        if button != 1:
            return
        if self.st_sel:
            for i, p in enumerate(self.st_routes.get(self.st_sel, [])):
                if math.hypot(p[0] - pos[0], p[1] - pos[1]) <= 10:
                    self.st_drag = ("wp", self.st_sel, i)
                    return
        lbl = self.studio_nearest(pos)
        if lbl:
            self.st_sel = lbl
        elif self.st_sel:
            self.st_routes.setdefault(self.st_sel, []).append(self.studio_clamp(pos))
        else:
            self.studio_msg("Click a player first, then click the field to draw their route.")

    def mouse_move_studio(self, pos):
        if not self.st_drag:
            return
        if self.st_drag[0] == "tok":
            self.st_align[self.st_drag[1]] = self.studio_clamp(pos, token=True)
        else:
            _, lbl, i = self.st_drag
            if i < len(self.st_routes.get(lbl, [])):
                self.st_routes[lbl][i] = self.studio_clamp(pos)

    # ================================================================ EVENTS
    def handle_event(self, event):
        if S != 1 and hasattr(event, "pos"):
            event = pygame.event.Event(event.type, {**event.dict, "pos": (event.pos[0] / S, event.pos[1] / S)})
        if event.type == pygame.QUIT:
            self.running = False
        elif event.type == pygame.MOUSEWHEEL:
            for rect, key, mx in self.regions:
                if rect.collidepoint(self.mouse):
                    self.scroll[key] = clamp(self.scroll.get(key, 0) - event.y * 30, 0, mx)
                    break
        elif event.type == pygame.MOUSEBUTTONDOWN:
            self.mouse = event.pos
            if event.button == 1:
                action = next((a for r, a in reversed(self.targets) if r.collidepoint(event.pos)), None)
                region = next((rg for rg in self.regions if rg[0].collidepoint(event.pos)), None)
                if action or region:   # a tap fires on release; dragging scrolls the list instead
                    self.press = {"action": action, "region": region, "last": event.pos, "start": event.pos,
                                  "dragged": False}
                    return
            self.press = None
            if self.scene == "PLAYMAKER_STUDIO" and not self.overlay and not self.modal:
                self.mouse_down_studio(event.pos, event.button)
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                self.st_drag = None
                press, self.press = self.press, None
                if press and not press["dragged"] and press["action"]:
                    press["action"]()
        elif event.type == pygame.MOUSEMOTION:
            self.mouse = event.pos
            press = self.press
            if press and press["region"]:
                if not press["dragged"] and abs(event.pos[1] - press["start"][1]) > 12:
                    press["dragged"] = True
                if press["dragged"]:
                    key, mx = press["region"][1], press["region"][2]
                    self.scroll[key] = clamp(self.scroll.get(key, 0) - (event.pos[1] - press["last"][1]), 0, mx)
                    press["last"] = event.pos
            if self.scene == "PLAYMAKER_STUDIO" and not self.modal:
                self.mouse_move_studio(event.pos)
        elif event.type == pygame.KEYDOWN:
            self.handle_key(event)

    def handle_key(self, event):
        key = event.key
        if self.modal:
            m = self.modal
            if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.modal_ok()
            elif key == pygame.K_ESCAPE:
                self.modal_cancel()
            elif key == pygame.K_BACKSPACE:
                m["value"] = m["value"][:-1]
                m["error"] = ""
            elif event.unicode and event.unicode.isprintable() and len(m["value"]) < m["max_len"]:
                m["value"] += event.unicode
                m["error"] = ""
            return
        if self.overlay:
            if key == pygame.K_ESCAPE:
                self.overlay = None if self.overlay == "PAUSE" else "PAUSE"
            return
        scene = self.scene
        if scene == "PLAY_GAME":
            if key == pygame.K_ESCAPE:
                self.open_pause()
            elif key == pygame.K_SPACE:
                if self.game_state == "PLAY_CALL":
                    self.snap()
                elif self.game_state == "LIVE_PLAY" and self.anim > int(20 * FS):
                    self.fast_forward()
                else:
                    self.skip_hold()
            elif key in (pygame.K_r, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.skip_hold()
            elif key == pygame.K_p and self.can_user_kick():
                self.do_special("PUNT")
            elif key == pygame.K_f and self.can_user_kick():
                self.do_special("FG")
            elif key == pygame.K_k and self.can_clock_play():
                self.do_special("KNEEL")
            elif key == pygame.K_s and self.can_clock_play():
                self.do_special("SPIKE")
            elif key == pygame.K_a and self.game_state == "PLAY_CALL":
                self.do_audible("HOT" if self.user_side() == "OFFENSE" else "BLITZ")
            elif key == pygame.K_d and self.game_state == "PLAY_CALL":
                self.do_audible("FLIP")
            elif key == pygame.K_t and self.game_state == "PLAY_CALL" and not self.s.conv:
                self.do_timeout("USER")
            elif key in (pygame.K_1, pygame.K_2, pygame.K_3):
                n = key - pygame.K_1
                if self.game_state == "KICKOFF_CHOICE":
                    self.do_kickoff(("DEEP", "SQUIB", "ONSIDE")[n])
                elif self.game_state == "CONV_CHOICE" and n < 2:
                    self.do_conversion(("XP", "TWO")[n])
        elif scene == "PLAY_LOG":
            if key == pygame.K_ESCAPE:
                self.log_back_action()
            elif key == pygame.K_UP:
                self.log_sel = max(0, self.log_sel - 1)
            elif key == pygame.K_DOWN:
                self.log_sel = min(len(self.s.log) - 1, self.log_sel + 1)
        elif scene == "REPORT_CARD":
            if key == pygame.K_ESCAPE:
                self.goto("MAIN_MENU")
        elif scene in BACK_MAP and key == pygame.K_ESCAPE:
            self.back()

    # ================================================================== LOOP
    def draw(self):
        win.fill(COLOR_BG_DARK)
        self.targets, self.regions = [], []
        self.draw_fns[self.scene]()
        if self.overlay:
            self.targets, self.regions = [], []
            self.draw_overlay()
        if self.modal:
            self.targets, self.regions = [], []
            self.draw_modal()

    async def run_async(self):
        while self.running:
            self.mouse = self.logical_mouse()
            for event in pygame.event.get():
                self.handle_event(event)
            self.update()
            self.draw()
            pygame.display.flip()
            self.dt = min(0.1, self.clock.tick(FPS) / 1000.0)
            await asyncio.sleep(0)      # lets the browser breathe between frames
        pygame.quit()

    def run(self):
        while self.running:
            self.mouse = self.logical_mouse()
            for event in pygame.event.get():
                self.handle_event(event)
            self.update()
            self.draw()
            pygame.display.flip()
            self.dt = min(0.1, self.clock.tick(FPS) / 1000.0)
        pygame.quit()


if __name__ == "__main__":
    App().run()
    sys.exit()
