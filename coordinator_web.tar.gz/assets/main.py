# Entry point for pygbag (browser build). Also runs on the desktop: python main.py
import asyncio

from cfb_coordinator import App


async def main():
    await App().run_async()


asyncio.run(main())
