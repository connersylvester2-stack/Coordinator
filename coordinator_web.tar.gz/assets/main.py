# Entry point for pygbag (browser build). Also runs on the desktop: python3 main.py
# It paints a loading message first and shows any start-up error ON SCREEN (handy in a browser).
import asyncio
import traceback

import pygame


async def main():
    pygame.init()
    screen = pygame.display.set_mode((1280, 720), pygame.SCALED | pygame.RESIZABLE)
    big = pygame.font.Font(None, 44)
    small = pygame.font.Font(None, 24)

    def say(lines, color=(230, 235, 240), font=big, step=40):
        screen.fill((20, 24, 32))
        y = 40
        for ln in lines:
            screen.blit(font.render(ln[:120], True, color), (30, y))
            y += step
        pygame.display.flip()

    say(["CFB Coordinator Suite", "Loading... (the first start can take a while)"])
    await asyncio.sleep(0.2)
    try:
        import cfb_coordinator as C
        say(["CFB Coordinator Suite", "Building the playbook library..."])
        await asyncio.sleep(0.2)
        app = C.App()
        await app.run_async()
    except Exception:
        tb = traceback.format_exc()
        print(tb)
        say(["The game hit an error while starting - please send a screenshot of this screen:", ""]
            + [ln for ln in tb.splitlines()][-22:], color=(255, 140, 120), font=small, step=26)
        while True:
            await asyncio.sleep(0.5)


asyncio.run(main())
