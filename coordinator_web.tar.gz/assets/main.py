# Entry point for pygbag (browser build). Also runs on the desktop: python3 main.py
# It paints a loading message first and shows any start-up error ON SCREEN (handy in a browser).
import asyncio
import sys
import traceback

import pygame

import gfxcfg


# --- Browser only: keep the canvas fitted to the screen, also after rotating the device -------------------
FIT_JS = """
(function () {
  var ASPECT = %(aspect)s;
  var st = document.getElementById('cfbfit');
  if (!st) { st = document.createElement('style'); st.id = 'cfbfit'; document.head.appendChild(st); }
  var mv = document.querySelector('meta[name=viewport]');
  if (!mv) { mv = document.createElement('meta'); mv.name = 'viewport'; document.head.appendChild(mv); }
  mv.content = 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover';
  function fit() {
    var vw = window.innerWidth, vh = window.innerHeight;
    var w = Math.min(vw, vh * ASPECT), h = w / ASPECT;
    st.textContent =
      'html,body{margin:0!important;padding:0!important;width:100%%!important;height:100%%!important;' +
      'overflow:hidden!important;background:#141820!important;touch-action:none!important;' +
      '-webkit-user-select:none!important;user-select:none!important}' +
      'canvas{position:fixed!important;margin:0!important;left:' + Math.round((vw - w) / 2) + 'px!important;top:' +
      Math.round((vh - h) / 2) + 'px!important;width:' + Math.round(w) + 'px!important;height:' +
      Math.round(h) + 'px!important}';
    window.scrollTo(0, 0);
  }
  fit();
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', function () { setTimeout(fit, 100); setTimeout(fit, 500); });
  if (window.visualViewport) { window.visualViewport.addEventListener('resize', fit); }
})();
"""


def fit_page():
    if sys.platform != "emscripten":
        return
    try:
        import platform
        platform.window.eval(FIT_JS % {"aspect": 1280.0 / gfxcfg.HEIGHT})
    except Exception as exc:  # never let a cosmetic helper stop the game
        print("fit_page failed:", exc)


async def main():
    pygame.init()
    k = gfxcfg.SCALE
    screen = pygame.display.set_mode((int(1280 * k), int(gfxcfg.HEIGHT * k)), pygame.SCALED | pygame.RESIZABLE)
    big = pygame.font.Font(None, int(44 * k))
    small = pygame.font.Font(None, int(24 * k))

    def say(lines, color=(230, 235, 240), font=big, step=40):
        screen.fill((20, 24, 32))
        y = 40 * k
        for ln in lines:
            screen.blit(font.render(ln[:120], True, color), (30 * k, y))
            y += step * k
        pygame.display.flip()

    say(["CFB Coordinator Suite", "Loading... (the first start can take a while)"])
    await asyncio.sleep(0.2)
    try:
        import cfb_coordinator as C
        say(["CFB Coordinator Suite", "Building the playbook library..."])
        await asyncio.sleep(0.2)
        app = C.App()
        await app.run_async()
    except Exception:
        tb = traceback.format_exc()
        print(tb)
        say(["The game hit an error while starting - please send a screenshot of this screen:", ""]
            + [ln for ln in tb.splitlines()][-22:], color=(255, 140, 120), font=small, step=26)
        while True:
            await asyncio.sleep(0.5)


asyncio.run(main())
