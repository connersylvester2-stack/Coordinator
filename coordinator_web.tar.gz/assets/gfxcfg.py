"""Render scale for the browser edition.

The game logic always works in a 1280x720 coordinate space. The screen is drawn at SCALE times that size so it
stays sharp on high-resolution tablets (1.0 = fastest, 1.5 = sharp, 2.0 = sharpest but slowest).
The choice is stored in the browser and can be changed from the main menu (reload the page to apply).
Set the environment variable CFB_SCALE to override it when running on a desktop.
"""
import os

import storage

NAMES = {1.0: "FAST (1x)", 1.5: "SHARP (1.5x)", 2.0: "ULTRA (2x)"}


def _load():
    v = os.environ.get("CFB_SCALE")
    if v is None and storage.IS_WEB:
        try:
            v = storage.read_text("gfx.txt")
        except Exception:
            v = None
    try:
        s = float(v) if v else None
    except ValueError:
        s = None
    if s in NAMES:
        return s
    return 1.5 if storage.IS_WEB else 1.0


SCALE = _load()


def next_scale(cur):
    order = sorted(NAMES)
    return order[(order.index(cur) + 1) % len(order)]


def save(scale):
    try:
        storage.write_text("gfx.txt", str(scale))
    except Exception:
        pass


# Screen shape. TABLET (1280x880) suits an iPad held in landscape; WIDE (1280x720) suits a widescreen monitor.
LAYOUTS = {"TABLET": 880, "WIDE": 720}


def _load_layout():
    v = os.environ.get("CFB_LAYOUT")
    if v is None and storage.IS_WEB:
        try:
            v = storage.read_text("layout.txt").strip()
        except Exception:
            v = None
    if v in LAYOUTS:
        return v
    return "TABLET" if storage.IS_WEB else "WIDE"


LAYOUT = _load_layout()
HEIGHT = LAYOUTS[LAYOUT]


def next_layout(cur):
    names = list(LAYOUTS)
    return names[(names.index(cur) + 1) % len(names)]


def save_layout(name):
    try:
        storage.write_text("layout.txt", name)
    except Exception:
        pass
