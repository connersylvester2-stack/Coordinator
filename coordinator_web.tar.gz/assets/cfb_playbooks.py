"""
Playbook library for the CFB Coordinator Suite (no pygame).

* offense formations x concepts and defense formations x calls are *generated* here
* philosophies ("playbooks") choose which formations a team can use
* load/migrate/save helpers keep plays.json up to date (older files are upgraded
  in place; your custom formations and plays are never overwritten)
"""
import copy
import json

import storage

SIDES = ("OFFENSE", "DEFENSE")
DEPTHS = ("SHORT", "MEDIUM", "DEEP")
RUN_STYLES = ("INSIDE", "OUTSIDE", "OPTION", "DRAW", "QB_RUN", "TRICK")
PASS_STYLES = ("DROPBACK", "PLAY_ACTION", "SCREEN", "RPO", "TRICK", "HAIL_MARY")
BOXES = ("LIGHT", "NORMAL", "HEAVY")
BUILD_VERSION = 3
FULL_LIBRARY = "FULL LIBRARY"
YD = 5.0  # pixels per yard on the field view

DEFAULT_ALIGN = {
    "OFFENSE": {"QB": [450, 360], "RB": [410, 360], "LT": [500, 310], "LG": [500, 335], "C": [500, 360],
                "RG": [500, 385], "RT": [500, 410], "TE": [500, 435], "WR1": [500, 180],
                "WR2": [480, 260], "WR3": [500, 540]},
    "DEFENSE": {"LE": [520, 310], "DT1": [520, 345], "DT2": [520, 375], "RE": [520, 410],
                "OLB1": [560, 310], "MLB": [570, 360], "OLB2": [560, 410], "CB1": [530, 180],
                "CB2": [530, 540], "FS": [630, 270], "SS": [630, 450]},
}
LABELS = {side: list(DEFAULT_ALIGN[side]) for side in SIDES}
OL = ("LT", "LG", "C", "RG", "RT")
DEFAULT_ROLES = {"LE": "DL", "DT1": "DL", "DT2": "DL", "RE": "DL", "OLB1": "LB", "MLB": "LB", "OLB2": "LB",
                 "CB1": "CB", "CB2": "CB", "FS": "FS", "SS": "SS"}


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def short_name(name):
    """'Gun Trips Right / Mesh' -> 'Mesh' (the formation is already shown as the group header)."""
    return name.split(" / ", 1)[-1]


def _xy(x, y):
    return [int(round(clamp(x, 380, 905))), int(round(clamp(y, 100, 670)))]


# ----------------------------------------------------------------------------
# Offensive route templates: (yards forward, yards toward the sideline) - cumulative
# ----------------------------------------------------------------------------
ROUTE_T = {
    "GO": [(6, 0), (28, 0)], "SEAM": [(10, -1), (28, -1.5)], "HITCH": [(6, 0), (4.5, 0)],
    "CURL": [(10, 0), (8, -1.5)], "OUT": [(7, 0), (7, 8)], "DIG": [(11, 0), (11, -9)],
    "SLANT": [(2, 0), (7, -6)], "POST": [(9, 0), (22, -8)], "CORNER": [(9, 0), (22, 9)],
    "FLAT": [(1.5, 6)], "WHEEL": [(1.5, 6), (18, 9)], "DRAG": [(2, 0), (3, -14)],
    "CROSS": [(5, 0), (10, -16)], "SWING": [(-1, 6), (3, 11)], "STICK": [(5, 0), (5, -1.5)],
    "SNAG": [(5, 0), (5, -3)], "FADE": [(5, 0), (26, 3)], "ANGLE": [(3, 2), (7, -4)],
    "TEXAS": [(3, 0), (9, -8)], "BLOCK": [(1, 0)], "BUBBLE": [(-1.5, 4)], "TUNNEL": [(-1.5, -3)],
}


def route_for(kind, x, y):
    o = 1 if y >= 360 else -1
    return [_xy(x + fx * YD, y + o * lat * YD) for fx, lat in ROUTE_T[kind]]


def qb_path(kind, x, y, d):
    if kind == "DROP3":
        return [_xy(x - 12, y)]
    if kind == "DROP7":
        return [_xy(x - 32, y)]
    if kind == "FAKE":
        return [_xy(x - 10, y + d * 6)]
    if kind == "BOOT":
        return [_xy(x - 8, y + d * 25), _xy(x - 8, y + d * 55)]
    if kind == "ROLL":
        return [_xy(x - 10, y + d * 45)]
    return [_xy(x - 22, y)]  # DROP5


def back_path(kind, x, y, d):
    if kind == "FAKE":
        return [_xy(x + 3 * YD, y + d * YD)]
    if kind == "FLEA":
        return [_xy(x + 3 * YD, y), _xy(x + YD, y)]
    if kind in ROUTE_T:
        return route_for(kind, x, y)
    return [_xy(x + YD, y)]


def _ctx(align):
    skill = ("RB", "TE", "WR1", "WR2", "WR3")
    backs = [l for l in skill if align[l][0] < 480]
    recv = [l for l in skill if l not in backs]
    top = sorted([l for l in recv if align[l][1] < 360], key=lambda l: align[l][1])
    bot = sorted([l for l in recv if align[l][1] >= 360], key=lambda l: -align[l][1])
    if len(bot) >= len(top):
        strong, weak, d = bot, top, 1
    else:
        strong, weak, d = top, bot, -1
    backs.sort(key=lambda l: (align[l][0], abs(align[l][1] - 360)))
    return {"backs": backs, "strong": strong, "weak": weak, "d": d}


def _target(c, want):
    side, rank = want
    lst = {"strong": c["strong"], "weak": c["weak"], "back": c["backs"]}[side]
    if lst:
        return lst[min(rank, len(lst) - 1)]
    for lst in (c["strong"], c["weak"], c["backs"]):
        if lst:
            return lst[0]
    return "WR1"


def _base_pass_route(align, qb_kind, d):
    route = {}
    for l in OL:
        x, y = align[l]
        route[l] = [_xy(x - 4, y)]
    x, y = align["QB"]
    route["QB"] = qb_path(qb_kind, x, y, d)
    return route


PASS_SPECS = {
    # quick game
    "Hitch": dict(depth="SHORT", strong=["HITCH"] * 4, weak=["HITCH"] * 3, target=("strong", 0), qb="DROP3"),
    "Slants": dict(depth="SHORT", strong=["SLANT"] * 4, weak=["SLANT"] * 3, target=("strong", 1), qb="DROP3"),
    "Stick": dict(depth="SHORT", strong=["GO", "STICK", "FLAT"], weak=["HITCH", "HITCH"], target=("strong", 1),
                  qb="DROP3", need=(2, 0)),
    "Curl Flat": dict(depth="SHORT", strong=["CURL", "FLAT", "FLAT"], weak=["CURL", "CURL"], target=("strong", 0)),
    "Snag": dict(depth="MEDIUM", strong=["CORNER", "SNAG", "FLAT"], weak=["HITCH", "HITCH"], target=("strong", 1),
                 need=(2, 0), qb="DROP3"),
    "Mesh": dict(depth="SHORT", strong=["GO", "DRAG", "DRAG"], weak=["GO", "DRAG"], back="FLAT",
                 target=("strong", 1), need=(2, 1), qb="DROP3"),
    "Smash": dict(depth="MEDIUM", strong=["HITCH", "CORNER", "FLAT"], weak=["GO", "SEAM"], target=("strong", 1),
                  need=(2, 0)),
    "Shallow Cross": dict(depth="SHORT", strong=["GO", "DRAG", "DRAG"], weak=["DRAG", "GO"], back="FLAT",
                          target=("weak", 0), need=(2, 1), qb="DROP3"),
    "Spacing": dict(depth="SHORT", strong=["HITCH", "SNAG", "FLAT"], weak=["HITCH", "HITCH"], back="FLAT",
                    target=("strong", 1), need=(2, 0), qb="DROP3"),
    # dropback
    "Four Verts": dict(depth="DEEP", strong=["GO", "SEAM", "SEAM", "SEAM"], weak=["GO", "SEAM", "SEAM"],
                       target=("strong", 0)),
    "Dagger": dict(depth="MEDIUM", strong=["GO", "DIG", "DIG"], weak=["CURL", "CURL"], target=("strong", 1),
                   need=(2, 0)),
    "Levels": dict(depth="MEDIUM", strong=["DIG", "DRAG", "DRAG"], weak=["DIG", "CURL"], back="FLAT",
                   target=("strong", 0)),
    "Flood": dict(depth="MEDIUM", strong=["CORNER", "OUT", "FLAT"], weak=["GO", "DRAG"], target=("strong", 1),
                  need=(2, 0), qb="ROLL"),
    "Y-Cross": dict(depth="MEDIUM", strong=["GO", "DIG", "CROSS"], weak=["CORNER", "POST"], target=("strong", 2),
                    need=(2, 0)),
    "Double Post": dict(depth="DEEP", strong=["POST", "POST", "FLAT"], weak=["GO", "GO"], target=("strong", 0),
                        need=(2, 0), qb="DROP7"),
    "Corner Post": dict(depth="DEEP", strong=["CORNER", "POST", "CURL"], weak=["GO", "CURL"], target=("strong", 1),
                        need=(2, 0), qb="DROP7"),
    "Dig": dict(depth="MEDIUM", strong=["DIG", "GO", "CURL"], weak=["DIG", "CURL"], target=("strong", 0)),
    "Post Wheel": dict(depth="DEEP", strong=["GO", "POST", "BLOCK"], weak=["GO", "CURL"], back="WHEEL",
                       target=("back", 0), back_required=True, qb="DROP7"),
    "Deep Out": dict(depth="MEDIUM", strong=["OUT", "GO", "CURL"], weak=["OUT", "CURL"], target=("strong", 0)),
    "Fade": dict(depth="MEDIUM", strong=["FADE", "FADE", "FADE"], weak=["FADE", "FADE"], target=("strong", 0),
                 qb="DROP3"),
    "Hail Mary": dict(depth="DEEP", strong=["GO"] * 5, weak=["GO"] * 4, target=("strong", 0), qb="DROP7",
                      style="HAIL_MARY"),
    # play action
    "PA Boot": dict(depth="MEDIUM", strong=["GO", "CROSS", "FLAT"], weak=["DRAG", "DRAG"], back="FAKE",
                    target=("strong", 1), qb="BOOT", style="PLAY_ACTION", back_required=True),
    "PA Deep Post": dict(depth="DEEP", strong=["GO", "POST", "BLOCK"], weak=["CORNER", "CURL"], back="FAKE",
                         target=("strong", 1), qb="DROP7", style="PLAY_ACTION", back_required=True),
    "PA Crossers": dict(depth="MEDIUM", strong=["DIG", "CROSS", "FLAT"], weak=["GO", "CROSS"], back="FAKE",
                        target=("strong", 1), style="PLAY_ACTION", back_required=True),
    "PA Flood": dict(depth="MEDIUM", strong=["CORNER", "OUT", "FLAT"], weak=["GO"], back="FAKE",
                     target=("strong", 1), qb="BOOT", style="PLAY_ACTION", back_required=True),
    # RPO / trick
    "RPO Slant": dict(depth="SHORT", strong=["SLANT"] * 3, weak=["SLANT"] * 2, target=("strong", 1), qb="FAKE",
                      style="RPO", rpo=True, back_required=True),
    "RPO Bubble": dict(depth="SHORT", strong=["BLOCK", "BUBBLE", "BLOCK"], weak=["BLOCK", "BLOCK"],
                       target=("strong", 1), qb="FAKE", style="RPO", rpo=True, back_required=True, need=(2, 0)),
    "RPO Glance": dict(depth="SHORT", strong=["GO", "SLANT", "SLANT"], weak=["SLANT"], target=("strong", 1),
                       qb="FAKE", style="RPO", rpo=True, back_required=True, need=(2, 0)),
    "Flea Flicker": dict(depth="DEEP", strong=["GO", "SEAM", "SEAM"], weak=["GO", "GO"], back="FLEA",
                         target=("strong", 0), style="TRICK", back_required=True, qb="DROP5"),
    "HB Pass": dict(depth="MEDIUM", strong=["GO", "CORNER", "FLAT"], weak=["DRAG"], back="SWING",
                    target=("strong", 0), style="TRICK", back_required=True, qb="ROLL"),
}


def build_pass(align, spec):
    c = _ctx(align)
    ns, nw = spec.get("need", (1, 0))
    if len(c["strong"]) < ns or len(c["weak"]) < nw:
        return None
    if spec.get("back_required") and not c["backs"]:
        return None
    d = c["d"]
    route = _base_pass_route(align, spec.get("qb", "DROP5"), d)
    for key in ("strong", "weak"):
        kinds = spec.get(key, [])
        for rank, l in enumerate(c[key]):
            route[l] = route_for(kinds[rank] if rank < len(kinds) else "BLOCK", *align[l])
    for i, l in enumerate(c["backs"]):
        route[l] = back_path(spec.get("back", "BLOCK") if i == 0 else "BLOCK", *align[l], d)
    if spec.get("rpo"):
        for l in OL:
            x, y = align[l]
            route[l] = [_xy(x + 2 * YD, y + d * 1.5 * YD)]
        x, y = align[c["backs"][0]]
        route[c["backs"][0]] = [_xy(x + 2 * YD, y), _xy(x + 6 * YD, y + d * 1.5 * YD)]
    return {"is_run": False, "depth": spec["depth"], "style": spec.get("style", "DROPBACK"),
            "target_receiver": _target(c, spec.get("target", ("strong", 0))), "route": route}


SCREENS = ("RB Screen", "WR Screen", "Tunnel Screen")


def build_screen(align, kind):
    c = _ctx(align)
    d = c["d"]
    route = _base_pass_route(align, "DROP5", d)
    strong = c["strong"]
    if kind == "RB Screen":
        if not c["backs"]:
            return None
        b = c["backs"][0]
        bx, by = align[b]
        route[b] = [_xy(bx - YD, by + d * 7 * YD), _xy(bx + 2 * YD, by + d * 11 * YD)]
        for l in (("RT", "RG") if d > 0 else ("LT", "LG")):
            x, y = align[l]
            route[l] = [_xy(x + 5 * YD, y + d * 7 * YD)]
        for l in strong[:1] + c["weak"][:1]:
            route[l] = route_for("GO", *align[l])
        target = b
    elif kind == "WR Screen":
        if not strong:
            return None
        target = strong[1] if len(strong) > 1 else strong[0]
        route[target] = route_for("BUBBLE", *align[target])
        if strong[0] != target:
            x, y = align[strong[0]]
            route[strong[0]] = [_xy(x + 4 * YD, y)]
        route["QB"] = qb_path("DROP3", *align["QB"], d)
    else:  # Tunnel Screen
        if not strong:
            return None
        target = strong[0]
        route[target] = route_for("TUNNEL", *align[target])
        for l in strong[1:2]:
            x, y = align[l]
            route[l] = [_xy(x + 3 * YD, y + d * 4 * YD)]
        route["QB"] = qb_path("DROP3", *align["QB"], d)
    return {"is_run": False, "depth": "SHORT", "style": "SCREEN", "target_receiver": target, "route": route}


# ----------------------------------------------------------------------------
# Run concepts
# ----------------------------------------------------------------------------
# rb = (yards forward, yards toward play side) waypoints; ol = (forward, lateral) block step
RUN_SPECS = {
    "Inside Zone": dict(style="INSIDE", rb=[(2, 0), (6, 1.5), (14, 3)], ol=(2.5, 1.2)),
    "Outside Zone": dict(style="OUTSIDE", rb=[(0, 3), (3, 8), (14, 12)], ol=(2, 2.5)),
    "Stretch": dict(style="OUTSIDE", rb=[(0, 4), (3, 10), (15, 14)], ol=(2, 3)),
    "Duo": dict(style="INSIDE", rb=[(2, 0), (10, 1)], ol=(3, 0)),
    "Power": dict(style="INSIDE", rb=[(2, 1), (8, 3), (16, 5)], ol=(2.5, 0.5), pull=True),
    "Counter": dict(style="INSIDE", rb=[(0.5, -1.5), (3, 1), (12, 5)], ol=(2, 1), pull=True),
    "Iso": dict(style="INSIDE", rb=[(3, 0), (12, 0.5)], ol=(3, 0)),
    "Dive": dict(style="INSIDE", rb=[(2.5, 0), (9, 0.5)], ol=(2.5, 0)),
    "Toss Sweep": dict(style="OUTSIDE", rb=[(-1, 6), (2, 14), (13, 18)], ol=(1.5, 4)),
    "Trap": dict(style="INSIDE", rb=[(2, 0), (9, -0.5)], ol=(2.5, 0), pull=True),
    "Draw": dict(style="DRAW", rb=[(1, 0), (4, 0.5), (12, 1)], ol=(-0.8, 0), qbdrop=True),
}


def _blockers(align, c, route, d, skip=()):
    for l in c["strong"] + c["weak"]:
        if l in skip:
            continue
        x, y = align[l]
        if l == "TE":
            route[l] = [_xy(x + 2 * YD, y + d * 1.5 * YD)]
        else:
            route[l] = [_xy(x + 3 * YD, y)]


def build_run(align, spec, d):
    c = _ctx(align)
    if not c["backs"]:
        return None
    primary = c["backs"][0]
    route = {}
    olf, oll = spec["ol"]
    for l in OL:
        x, y = align[l]
        route[l] = [_xy(x + olf * YD, y + d * oll * YD)]
    if spec.get("pull"):
        g = "LG" if d > 0 else "RG"
        x, y = align[g]
        route[g] = [_xy(x - YD, y + d * 4 * YD), _xy(x + 5 * YD, y + d * 9 * YD)]
    x, y = align["QB"]
    route["QB"] = [_xy(x - 12, y)] if spec.get("qbdrop") else [_xy(x - YD, y + d * 2 * YD)]
    x, y = align[primary]
    route[primary] = [_xy(x + f * YD, y + d * lat * YD) for f, lat in spec["rb"]]
    for l in c["backs"][1:]:
        x, y = align[l]
        route[l] = [_xy(x + 2 * YD, y + d * 3 * YD), _xy(x + 6 * YD, y + d * 4 * YD)]
    _blockers(align, c, route, d)
    return {"is_run": True, "depth": "SHORT", "style": spec["style"], "target_receiver": primary, "route": route}


QB_RUNS = ("Zone Read", "QB Draw", "Power Read", "Jet Sweep", "QB Sneak")
OPTIONS = ("Triple Option", "Midline", "Speed Option", "Counter Option")
OPTION_T = {
    "Triple Option": dict(qb=[(2, 3), (9, 10), (17, 14)], dive=[(3, 0)], pitch=[(0, 6), (7, 13), (16, 19)]),
    "Midline": dict(qb=[(2, 0), (9, 0.5)], dive=[(3, 0)], pitch=None),
    "Speed Option": dict(qb=[(0, 5), (7, 13), (16, 19)], dive=[(2, 4), (7, 9)], pitch=[(-1, 8), (6, 16), (15, 22)]),
    "Counter Option": dict(qb=[(0, -2), (3, 4), (10, 12)], dive=[(2, 0)], pitch=[(0, 4), (8, 12), (16, 18)]),
}


def _rel(x, y, pts, d):
    return [_xy(x + f * YD, y + d * lat * YD) for f, lat in pts]


def build_qb_run(align, name, d):
    c = _ctx(align)
    route = {}
    qx, qy = align["QB"]
    for l in OL:
        x, y = align[l]
        route[l] = [_xy(x + 2.5 * YD, y + d * YD)] if name != "QB Draw" else [_xy(x - 4, y)]
    if name == "QB Sneak":
        for l in OL:
            x, y = align[l]
            route[l] = [_xy(x + 2.5 * YD, y)]
        route["QB"] = [_xy(qx + 4 * YD, qy)]
        for l in c["backs"]:
            x, y = align[l]
            route[l] = [_xy(x + 2 * YD, y)]
        _blockers(align, c, route, d)
        return {"is_run": True, "depth": "SHORT", "style": "QB_RUN", "target_receiver": "QB", "route": route}
    if name == "QB Draw":
        route["QB"] = [_xy(qx - YD, qy), _xy(qx + 4 * YD, qy + d * YD), _xy(qx + 12 * YD, qy + d * 2 * YD)]
        for l in c["backs"]:
            x, y = align[l]
            route[l] = [_xy(x + YD, y)]
        _blockers(align, c, route, d)
        return {"is_run": True, "depth": "SHORT", "style": "QB_RUN", "target_receiver": "QB", "route": route}
    if name == "Jet Sweep":
        cands = [l for l in c["strong"] + c["weak"] if l != "TE"]
        if not cands:
            return None
        jet = min(cands, key=lambda l: abs(align[l][1] - 360))
        jx, jy = align[jet]
        route[jet] = [_xy(jx - YD, jy + d * 8 * YD), _xy(jx + 2 * YD, jy + d * 16 * YD), _xy(jx + 12 * YD, jy + d * 22 * YD)]
        route["QB"] = [_xy(qx - YD, qy + d * 2 * YD)]
        for l in c["backs"]:
            x, y = align[l]
            route[l] = [_xy(x + 2 * YD, y + d * 3 * YD), _xy(x + 6 * YD, y + d * 4 * YD)]
        _blockers(align, c, route, d, skip=(jet,))
        return {"is_run": True, "depth": "SHORT", "style": "OUTSIDE", "target_receiver": jet, "route": route}
    # Zone Read / Power Read need a back
    if not c["backs"]:
        return None
    b = c["backs"][0]
    bx, by = align[b]
    route["QB"] = _rel(qx, qy, [(2, 3), (10, 8)], d)
    _blockers(align, c, route, d)
    if name == "Zone Read":
        route[b] = _rel(bx, by, [(2, 1), (8, 3)], d)
        for l in c["backs"][1:]:
            x, y = align[l]
            route[l] = [_xy(x + 2 * YD, y + d * 3 * YD)]
        return {"is_run": True, "depth": "SHORT", "style": "OPTION", "target_receiver": b, "route": route}
    g = "LG" if d > 0 else "RG"  # Power Read: backside guard pulls, QB keeps
    x, y = align[g]
    route[g] = [_xy(x - YD, y + d * 4 * YD), _xy(x + 5 * YD, y + d * 9 * YD)]
    route[b] = _rel(bx, by, [(2, 1), (7, 3)], d)
    return {"is_run": True, "depth": "SHORT", "style": "OPTION", "target_receiver": "QB", "route": route}


def build_option(align, name, d):
    c = _ctx(align)
    t = OPTION_T[name]
    if not c["backs"]:
        return None
    qx, qy = align["QB"]
    route = {"QB": _rel(qx, qy, t["qb"], d)}
    for l in OL:
        x, y = align[l]
        route[l] = [_xy(x + 2 * YD, y + d * 2 * YD)]
    dive = max(c["backs"], key=lambda l: align[l][0])
    dx, dy = align[dive]
    route[dive] = _rel(dx, dy, t["dive"], d if name != "Midline" else 0)
    cands = [l for l in c["backs"] + c["strong"] + c["weak"]
             if l != dive and (align[l][1] >= 360) == (d > 0)]
    if t["pitch"] and cands:
        pitch = min(cands, key=lambda l: abs(align[l][1] - 360))
        px, py = align[pitch]
        route[pitch] = _rel(px, py, t["pitch"], d)
    else:
        pitch = None
    _blockers(align, c, route, d, skip=(pitch,) if pitch else ())
    for l in c["backs"]:
        if l not in route:
            x, y = align[l]
            route[l] = [_xy(x + 2 * YD, y + d * 3 * YD)]
    return {"is_run": True, "depth": "SHORT", "style": "OPTION", "target_receiver": "QB", "route": route}


def build_reverse(align, d):
    c = _ctx(align)
    cands = [l for l in (c["weak"] + c["strong"]) if l != "TE"]
    if not cands:
        return None
    carrier = cands[0]
    x, y = align[carrier]
    route = {"QB": [_xy(align["QB"][0] - YD, align["QB"][1] + d * 2 * YD)]}
    for l in OL:
        ox, oy = align[l]
        route[l] = [_xy(ox + 2 * YD, oy + d * 2 * YD)]
    route[carrier] = [_xy(x - 4 * YD, y + d * 10 * YD), _xy(x - 3 * YD, y + d * 24 * YD),
                      _xy(x + 8 * YD, y + d * 30 * YD)]
    for l in c["backs"]:
        bx, by = align[l]
        route[l] = [_xy(bx + 2 * YD, by + d * 3 * YD)]
    _blockers(align, c, route, d, skip=(carrier,))
    return {"is_run": True, "depth": "SHORT", "style": "TRICK", "target_receiver": carrier, "route": route}


DIRECTIONAL = (set(RUN_SPECS) | {"Zone Read", "QB Draw", "Power Read", "Jet Sweep", "WR Reverse"} | set(OPTIONS))


def make_concept(align, cname):
    """Return [(suffix, play), ...] for one concept in one formation (empty if it does not fit)."""
    out = []
    dirs = ((-1, " Left"), (1, " Right")) if cname in DIRECTIONAL else ((1, ""),)
    for d, suffix in dirs:
        if cname in PASS_SPECS:
            p = build_pass(align, PASS_SPECS[cname])
        elif cname in SCREENS:
            p = build_screen(align, cname)
        elif cname in RUN_SPECS:
            p = build_run(align, RUN_SPECS[cname], d)
        elif cname in QB_RUNS:
            p = build_qb_run(align, cname, d)
        elif cname in OPTIONS:
            p = build_option(align, cname, d)
        elif cname == "WR Reverse":
            p = build_reverse(align, d)
        else:
            raise KeyError(cname)
        if p:
            out.append((suffix, p))
    return out


# ----------------------------------------------------------------------------
# Offensive formations: name, group, QB, RB, TE, WR1, WR2, WR3, display-name overrides
# (OL always lines up at x=500; a "back" is any skill player with x < 480)
# ----------------------------------------------------------------------------
_WT, _WB = (500, 125), (500, 640)
_ST, _SB = (488, 215), (488, 505)
_TT, _TB = (488, 262), (488, 458)
_ER, _EL = (500, 436), (500, 284)
_WGR = (486, 462)
_QG, _QP, _QC = (468, 360), (476, 360), (488, 360)
_BR, _BL = (466, 398), (466, 322)
_PB = (448, 360)

OFF_FORMS = [
    ("Gun Doubles", "GUN", _QG, _BR, _TB, _WT, _ST, _WB, {"TE": "Y"}),
    ("Gun Trips Right", "GUN", _QG, _BL, _TB, _WT, _WB, _SB, {"TE": "Y"}),
    ("Gun Trips Left", "GUN", _QG, _BR, _TT, _WB, _WT, _ST, {"TE": "Y"}),
    ("Gun Bunch Right", "GUN", _QG, _BL, (487, 514), _WT, (500, 540), (487, 566), {"TE": "Y"}),
    ("Gun Bunch Left", "GUN", _QG, _BR, (487, 206), _WB, (500, 180), (487, 154), {"TE": "Y"}),
    ("Gun Ace", "GUN", _QG, _BR, _ER, _WT, _ST, _WB, {}),
    ("Gun Y-Off Right", "GUN", _QG, _BL, _WGR, _WT, _ST, _WB, {"TE": "Y"}),
    ("Gun Tight", "GUN", _QG, _BR, _ER, _WT, _WB, _EL, {"WR3": "Y2"}),
    ("Gun Deuce", "GUN", _QG, (466, 322), _ER, _WT, _WB, (466, 398), {"WR3": "HB"}),
    ("Gun Deuce Close", "GUN", _QG, (462, 336), _ER, _WT, _WB, (462, 384), {"WR3": "HB"}),
    ("Gun Wing Right", "GUN", _QG, _BL, _ER, _WT, _WB, _WGR, {"WR3": "WB"}),
    ("Gun Empty Trey", "EMPTY", _QG, _ST, _TB, _WT, _WB, _SB, {"RB": "H", "TE": "Y"}),
    ("Gun Empty Trey Left", "EMPTY", _QG, _SB, _TT, _WB, _WT, _ST, {"RB": "H", "TE": "Y"}),
    ("Gun Empty Quads Right", "EMPTY", _QG, (488, 475), (488, 530), _WT, _WB, (488, 585), {"RB": "H", "TE": "Y"}),
    ("Gun Empty Quads Left", "EMPTY", _QG, (488, 285), (488, 230), _WB, _WT, (488, 175), {"RB": "H", "TE": "Y"}),
    ("Pistol Doubles", "PISTOL", _QP, _PB, _TB, _WT, _ST, _WB, {"TE": "Y"}),
    ("Pistol Trips Right", "PISTOL", _QP, _PB, _TB, _WT, _WB, _SB, {"TE": "Y"}),
    ("Pistol Trips Left", "PISTOL", _QP, _PB, _TT, _WB, _WT, _ST, {"TE": "Y"}),
    ("Pistol Ace", "PISTOL", _QP, _PB, _ER, _WT, _WB, _ST, {}),
    ("Pistol Strong Right", "PISTOL", _QP, _PB, _ER, _WT, _WB, _EL, {"WR3": "Y2"}),
    ("Pistol Bunch Right", "PISTOL", _QP, _PB, (487, 514), _WT, (500, 540), (487, 566), {"TE": "Y"}),
    ("Pistol Full House", "PISTOL", _QP, _PB, (448, 322), _WT, _WB, (448, 398), {"TE": "HB", "WR3": "HB", "RB": "FB"}),
    ("Pistol Flexbone", "OPTION", _QP, _PB, (490, 285), _WT, _WB, (490, 435), {"TE": "SB", "WR3": "SB", "RB": "FB"}),
    ("I-Form Pro", "PRO", _QC, (438, 360), _ER, _WT, _WB, (462, 360), {"WR3": "FB", "RB": "HB"}),
    ("I-Form Twins Right", "PRO", _QC, (438, 360), _EL, _WB, _SB, (462, 360), {"WR3": "FB", "RB": "HB"}),
    ("Strong I Right", "PRO", _QC, (438, 360), _ER, _WT, _WB, (462, 395), {"WR3": "FB", "RB": "HB"}),
    ("Offset I Left", "PRO", _QC, (438, 360), _ER, _WT, _WB, (462, 325), {"WR3": "FB", "RB": "HB"}),
    ("Singleback Ace", "PRO", _QC, (450, 360), _ER, _WT, _WB, _ST, {}),
    ("Singleback Trips Right", "PRO", _QC, (450, 360), _TB, _WT, _WB, _SB, {"TE": "Y"}),
    ("Singleback Doubles", "PRO", _QC, (450, 360), _ER, _WT, _ST, _WB, {}),
    ("Singleback Twin TE", "PRO", _QC, (450, 360), _ER, _WT, _WB, _EL, {"WR3": "Y2"}),
    ("Split Backs Pro", "PRO", _QC, (456, 322), _ER, _WT, _WB, (456, 398), {"WR3": "HB"}),
    ("Split Backs Flip", "PRO", _QC, (456, 322), _EL, _WT, _WB, (456, 398), {"WR3": "HB"}),
    ("Jumbo I", "PRO", _QC, (438, 360), _ER, _WB, _EL, (462, 360), {"WR2": "Y2", "WR3": "FB", "RB": "HB"}),
    ("Flexbone", "OPTION", _QC, (462, 360), (490, 285), _WT, _WB, (490, 435), {"TE": "SB", "WR3": "SB", "RB": "FB"}),
    ("Wishbone", "OPTION", _QC, (462, 360), _ER, _WT, (440, 325), (440, 395), {"WR2": "HB", "WR3": "HB", "RB": "FB"}),
    ("Full House", "OPTION", _QC, (452, 360), _ER, _WT, (452, 322), (452, 398), {"WR2": "HB", "WR3": "HB", "RB": "FB"}),
    ("Wing-T Right", "OPTION", _QC, (448, 360), _ER, _WT, (452, 322), _WGR, {"WR2": "HB", "WR3": "WB", "RB": "FB"}),
    ("Goal Line", "GOAL", _QC, (438, 360), _ER, (486, 258), _EL, (462, 360), {"WR1": "TE", "WR2": "TE", "WR3": "FB", "RB": "HB"}),
]

_Q = ["Hitch", "Slants", "Stick", "Curl Flat", "Snag", "Mesh", "Smash", "Shallow Cross", "Spacing"]
_DP = ["Four Verts", "Dagger", "Levels", "Flood", "Y-Cross", "Double Post", "Corner Post", "Dig", "Post Wheel", "Deep Out"]
_SC = list(SCREENS)
_PA = ["PA Boot", "PA Deep Post", "PA Crossers", "PA Flood"]
_RPO = ["RPO Slant", "RPO Bubble", "RPO Glance"]
_ZN = ["Inside Zone", "Outside Zone", "Stretch", "Duo", "Draw"]
_GP = ["Power", "Counter", "Iso", "Toss Sweep", "Trap", "Dive"]
_QR = ["Zone Read", "QB Draw", "Power Read", "Jet Sweep", "QB Sneak"]

OFF_CONCEPTS = {
    "GUN": _Q + _DP[:8] + _SC + _PA[:2] + _RPO + ["Inside Zone", "Outside Zone", "Stretch", "Draw"]
           + ["Power", "Counter", "Toss Sweep"] + _QR + ["WR Reverse", "Flea Flicker"],
    "EMPTY": _Q + _DP + ["WR Screen", "Tunnel Screen", "Hail Mary", "Fade", "QB Draw", "QB Sneak"],
    "PISTOL": _Q[:8] + _DP[:7] + _SC + _PA + _RPO + _ZN + _GP[:5] + _QR + ["WR Reverse", "Flea Flicker"],
    "PRO": _Q[:7] + _DP[:9] + _SC[:2] + _PA + _ZN[:4] + _GP + ["HB Pass", "Flea Flicker", "QB Sneak", "WR Reverse"],
    "OPTION": list(OPTIONS) + _GP + ["Zone Read", "QB Sneak"] + _PA
              + ["Four Verts", "Post Wheel", "Corner Post", "Hitch", "Slants", "Flood"],
    "GOAL": ["Iso", "Power", "Dive", "Duo", "Toss Sweep", "QB Sneak", "PA Boot", "Fade", "Slants"],
}


# ----------------------------------------------------------------------------
# Defense
# ----------------------------------------------------------------------------
def dmove(kind, x, y):
    o = 1 if y >= 360 else -1
    tc = 360 - y
    if kind == "PRESS":
        return [_xy(x + 8, y), _xy(x + 72, y + tc * 0.1)]
    t = {
        "RUSH": (x - 16, y + tc * 0.30), "BLITZ": (x - 32, y + tc * 0.65), "HOOK": (x + 22, y + tc * 0.15),
        "FLAT": (x + 10, y + o * 45), "DEEP_THIRD": (x + 95, y), "DEEP_MID": (x + 100, 360),
        "DEEP_HALF": (x + 95, 360 + (y - 360) * 0.55), "QUARTER": (x + 85, y), "MAN": (x + 75, y + tc * 0.1),
        "ROBBER": (x + 28, 360), "SPY": (x + 8, 360), "FILL": (x - 8, y),
    }[kind]
    return [_xy(*t)]


def _roles(overrides):
    r = dict(DEFAULT_ROLES)
    r.update(overrides or {})
    return r


# name, group, box, position overrides, display names, role overrides
DEF_FORMS = [
    ("4-3 Over", "43", "NORMAL", {"LE": (520, 300), "DT1": (520, 340), "DT2": (520, 380), "RE": (520, 420),
        "OLB1": (556, 296), "MLB": (566, 360), "OLB2": (556, 424), "FS": (640, 300), "SS": (614, 436)}, {}, {}),
    ("4-3 Under", "43", "NORMAL", {"LE": (520, 296), "DT1": (520, 344), "DT2": (520, 384), "RE": (520, 424),
        "OLB1": (556, 288), "MLB": (566, 352), "OLB2": (556, 418), "FS": (640, 290), "SS": (604, 444)}, {}, {}),
    ("4-3 Wide 9", "43", "NORMAL", {"LE": (520, 280), "DT1": (520, 338), "DT2": (520, 382), "RE": (520, 440),
        "OLB1": (560, 310), "MLB": (566, 360), "OLB2": (560, 410), "FS": (640, 300), "SS": (640, 430)}, {}, {}),
    ("4-3 Tite", "43", "NORMAL", {"LE": (520, 312), "DT1": (520, 342), "DT2": (520, 378), "RE": (520, 408),
        "OLB1": (556, 320), "MLB": (562, 360), "OLB2": (556, 400)}, {}, {}),
    ("4-2-5 Nickel Over", "NICKEL", "NORMAL", {"LE": (520, 300), "DT1": (520, 340), "DT2": (520, 380),
        "RE": (520, 420), "OLB1": (566, 335), "MLB": (566, 385), "OLB2": (546, 480), "FS": (640, 300),
        "SS": (620, 436)}, {"OLB1": "MIKE", "MLB": "WILL", "OLB2": "NB"}, {"OLB2": "CB"}),
    ("4-2-5 Nickel Under", "NICKEL", "NORMAL", {"LE": (520, 296), "DT1": (520, 344), "DT2": (520, 384),
        "RE": (520, 424), "OLB1": (566, 330), "MLB": (566, 388), "OLB2": (546, 480), "FS": (640, 290),
        "SS": (610, 444)}, {"OLB1": "MIKE", "MLB": "WILL", "OLB2": "NB"}, {"OLB2": "CB"}),
    ("4-2-5 Wide 9", "NICKEL", "NORMAL", {"LE": (520, 280), "DT1": (520, 338), "DT2": (520, 382),
        "RE": (520, 440), "OLB1": (566, 335), "MLB": (566, 385), "OLB2": (546, 480), "FS": (640, 300),
        "SS": (640, 430)}, {"OLB1": "MIKE", "MLB": "WILL", "OLB2": "NB"}, {"OLB2": "CB"}),
    ("4-4 Eagle", "BEAR", "HEAVY", {"LE": (520, 300), "DT1": (520, 340), "DT2": (520, 380), "RE": (520, 420),
        "OLB1": (552, 300), "MLB": (556, 342), "OLB2": (552, 420), "SS": (556, 382), "FS": (620, 360),
        "CB1": (532, 190), "CB2": (532, 530)}, {"SS": "ILB"}, {"SS": "LB"}),
    ("3-4 Base", "34", "NORMAL", {"LE": (520, 325), "DT1": (520, 360), "RE": (520, 395), "DT2": (565, 380),
        "MLB": (565, 340), "OLB1": (528, 296), "OLB2": (528, 424)},
        {"LE": "DE", "DT1": "NT", "RE": "DE", "DT2": "ILB", "MLB": "ILB", "OLB1": "OLB", "OLB2": "OLB"},
        {"DT2": "LB"}),
    ("3-4 Okie", "34", "NORMAL", {"LE": (520, 325), "DT1": (520, 360), "RE": (520, 395), "DT2": (565, 380),
        "MLB": (565, 340), "OLB1": (522, 296), "OLB2": (540, 424)},
        {"LE": "DE", "DT1": "NT", "RE": "DE", "DT2": "ILB", "MLB": "ILB", "OLB1": "OLB", "OLB2": "OLB"},
        {"DT2": "LB", "OLB1": "DL"}),
    ("3-4 Eagle", "34", "NORMAL", {"LE": (520, 320), "DT1": (520, 360), "RE": (520, 400), "DT2": (562, 384),
        "MLB": (562, 336), "OLB1": (540, 290), "OLB2": (522, 430)},
        {"LE": "DE", "DT1": "NT", "RE": "DE", "DT2": "ILB", "MLB": "ILB", "OLB1": "OLB", "OLB2": "OLB"},
        {"DT2": "LB", "OLB2": "DL"}),
    ("3-3-5 Stack", "NICKEL", "NORMAL", {"LE": (520, 325), "DT1": (520, 360), "RE": (520, 395),
        "OLB1": (560, 322), "MLB": (562, 360), "OLB2": (560, 398), "DT2": (610, 290), "FS": (640, 360),
        "SS": (610, 430)}, {"DT2": "S", "LE": "DE", "RE": "DE", "DT1": "NT"}, {"DT2": "SS"}),
    ("3-3-5 Tite", "NICKEL", "NORMAL", {"LE": (520, 328), "DT1": (520, 360), "RE": (520, 392),
        "OLB1": (556, 318), "MLB": (558, 360), "OLB2": (556, 402), "DT2": (606, 296), "FS": (640, 360),
        "SS": (606, 424)}, {"DT2": "S", "LE": "DE", "RE": "DE", "DT1": "NT"}, {"DT2": "SS"}),
    ("4-1-6 Dime", "DIME", "LIGHT", {"MLB": (570, 360), "OLB1": (548, 235), "OLB2": (548, 485)},
        {"OLB1": "NB", "OLB2": "DB"}, {"OLB1": "CB", "OLB2": "CB"}),
    ("3-2-6 Dime", "DIME", "LIGHT", {"LE": (520, 325), "DT1": (520, 360), "RE": (520, 395), "DT2": (548, 235),
        "MLB": (548, 485), "OLB1": (560, 310), "OLB2": (560, 410)},
        {"DT2": "DB", "MLB": "DB", "LE": "DE", "RE": "DE", "DT1": "NT"}, {"DT2": "CB", "MLB": "CB"}),
    ("4-6 Bear", "BEAR", "HEAVY", {"LE": (520, 300), "DT1": (520, 338), "DT2": (520, 382), "RE": (520, 420),
        "OLB1": (540, 324), "MLB": (542, 360), "OLB2": (540, 396), "SS": (562, 440), "FS": (640, 360),
        "CB1": (534, 190), "CB2": (534, 530)}, {}, {}),
    ("2-4-5 Edge", "NICKEL", "NORMAL", {"DT1": (520, 340), "DT2": (520, 380), "LE": (526, 296), "RE": (526, 424),
        "OLB1": (566, 335), "MLB": (566, 385), "OLB2": (546, 480)},
        {"LE": "EDGE", "RE": "EDGE", "OLB2": "NB"}, {"LE": "LB", "RE": "LB", "OLB2": "CB"}),
    ("Goal Line 5-3-3", "GOAL", "HEAVY", {"LE": (520, 298), "DT1": (520, 330), "DT2": (520, 362), "RE": (520, 394),
        "OLB1": (520, 426), "OLB2": (548, 330), "SS": (548, 362), "MLB": (548, 394), "CB1": (545, 200),
        "CB2": (545, 520), "FS": (600, 360)}, {"OLB1": "DL", "SS": "LB"}, {"OLB1": "DL", "SS": "LB"}),
    ("4-2-5 Tite", "NICKEL", "NORMAL", {"LE": (520, 314), "DT1": (520, 344), "DT2": (520, 376), "RE": (520, 406),
        "OLB1": (562, 335), "MLB": (562, 385), "OLB2": (546, 480), "FS": (640, 300), "SS": (620, 436)},
        {"OLB1": "MIKE", "MLB": "WILL", "OLB2": "NB"}, {"OLB2": "CB"}),
    ("3-4 Tite", "34", "NORMAL", {"LE": (520, 328), "DT1": (520, 360), "RE": (520, 392), "DT2": (562, 382),
        "MLB": (562, 338), "OLB1": (532, 304), "OLB2": (532, 416)},
        {"LE": "DE", "DT1": "NT", "RE": "DE", "DT2": "ILB", "MLB": "ILB", "OLB1": "OLB", "OLB2": "OLB"},
        {"DT2": "LB"}),
    ("4-3 Stack", "43", "NORMAL", {"LE": (520, 304), "DT1": (520, 342), "DT2": (520, 378), "RE": (520, 416),
        "OLB1": (550, 304), "MLB": (552, 360), "OLB2": (550, 416), "FS": (636, 330), "SS": (620, 420)}, {}, {}),
]

_COV = ["Cover 2 Zone", "Tampa 2", "Cover 2 Man", "Cover 3 Sky", "Cover 3 Cloud", "Cover 3 Buzz", "Cover 3 Match",
        "Cover 4 Quarters", "Cover 4 Palms", "Cover 6", "Cover 1 Robber", "Cover 1 Man"]
_BLZ = ["Cover 0 Blitz", "Fire Zone", "Sim Pressure", "Double A-Gap", "Corner Blitz", "Safety Blitz", "Nickel Blitz",
        "LB Dog", "Cross Fire", "Zone Blitz DL Drop", "All-Out Blitz"]
DEF_CONCEPTS = {
    "43": [c for c in _COV if c not in ("Cover 4 Palms", "Cover 6")] + [b for b in _BLZ if b not in ("Nickel Blitz", "All-Out Blitz")],
    "NICKEL": _COV + [b for b in _BLZ if b != "All-Out Blitz"],
    "DIME": ["Prevent", "Cover 2 Zone", "Cover 3 Sky", "Cover 4 Quarters", "Cover 4 Palms", "Cover 6", "Cover 1 Man",
             "Cover 2 Man", "Cover 0 Blitz", "Nickel Blitz", "Safety Blitz", "Corner Blitz", "Fire Zone", "Sim Pressure"],
    "34": ["Cover 3 Sky", "Cover 3 Buzz", "Cover 3 Match", "Cover 2 Zone", "Cover 4 Quarters", "Cover 1 Robber",
           "Cover 2 Man", "Fire Zone", "Sim Pressure", "Cross Fire", "Zone Blitz DL Drop", "LB Dog", "Double A-Gap",
           "Cover 0 Blitz", "Corner Blitz", "Safety Blitz"],
    "BEAR": ["Cover 1 Man", "Cover 1 Robber", "Cover 3 Sky", "Cover 0 Blitz", "Double A-Gap", "LB Dog", "Safety Blitz",
             "All-Out Blitz", "Cross Fire", "Corner Blitz"],
    "GOAL": ["Goal Line Base", "Goal Line Blitz", "Goal Line Man"],
}


def _m(cov, blitz, DL, LB, CB_OUT, CB_IN, FS, SS, **kw):
    d = dict(cov=cov, blitz=blitz, moves=dict(DL=DL, LB=LB, CB_OUT=CB_OUT, CB_IN=CB_IN, FS=FS, SS=SS))
    d.update(kw)
    return d


R = ["RUSH"]
DEF_SPECS = {
    "Cover 2 Zone": _m("ZONE", False, R, ["HOOK"], ["FLAT"], ["FLAT"], "DEEP_HALF", "DEEP_HALF"),
    "Tampa 2": _m("ZONE", False, R, ["HOOK", "DEEP_MID", "HOOK"], ["FLAT"], ["FLAT"], "DEEP_HALF", "DEEP_HALF"),
    "Cover 2 Man": _m("MAN", False, R, ["MAN"], ["PRESS"], ["MAN"], "DEEP_HALF", "DEEP_HALF"),
    "Cover 3 Sky": _m("ZONE", False, R, ["HOOK"], ["DEEP_THIRD"], ["FLAT"], "DEEP_MID", "FLAT"),
    "Cover 3 Cloud": _m("ZONE", False, R, ["HOOK"], ["FLAT"], ["FLAT"], "DEEP_THIRD", "DEEP_THIRD"),
    "Cover 3 Buzz": _m("ZONE", False, R, ["HOOK"], ["DEEP_THIRD"], ["FLAT"], "DEEP_MID", "HOOK"),
    "Cover 3 Match": _m("ZONE", False, R, ["HOOK"], ["DEEP_THIRD"], ["MAN"], "DEEP_MID", "HOOK"),
    "Cover 4 Quarters": _m("ZONE", False, R, ["HOOK"], ["QUARTER"], ["FLAT"], "QUARTER", "QUARTER"),
    "Cover 4 Palms": _m("ZONE", False, R, ["FLAT", "HOOK"], ["QUARTER"], ["HOOK"], "QUARTER", "QUARTER"),
    "Cover 6": _m("ZONE", False, R, ["HOOK"], ["QUARTER", "FLAT"], ["FLAT"], "QUARTER", "DEEP_HALF"),
    "Cover 1 Robber": _m("MAN", False, R, ["MAN"], ["PRESS"], ["MAN"], "DEEP_MID", "ROBBER"),
    "Cover 1 Man": _m("MAN", False, R, ["MAN"], ["PRESS"], ["MAN"], "DEEP_MID", "FILL"),
    "Prevent": _m("ZONE", False, R, ["HOOK"], ["DEEP_THIRD"], ["DEEP_HALF"], "DEEP_MID", "DEEP_HALF", box="LIGHT"),
    "Cover 0 Blitz": _m("MAN", True, R, ["BLITZ"], ["PRESS"], ["MAN"], "MAN", "MAN"),
    "Fire Zone": _m("ZONE", True, R, ["BLITZ", "HOOK", "BLITZ"], ["DEEP_THIRD"], ["FLAT"], "DEEP_MID", "FLAT"),
    "Sim Pressure": _m("ZONE", True, R, ["BLITZ", "SPY", "HOOK"], ["DEEP_THIRD"], ["FLAT"], "DEEP_MID", "FLAT"),
    "Double A-Gap": _m("MAN", True, R, ["BLITZ", "BLITZ", "SPY"], ["PRESS"], ["MAN"], "DEEP_MID", "MAN"),
    "Corner Blitz": _m("MAN", True, R, ["MAN"], ["BLITZ", "PRESS"], ["MAN"], "DEEP_MID", "MAN"),
    "Safety Blitz": _m("MAN", True, R, ["MAN"], ["PRESS"], ["MAN"], "DEEP_MID", "BLITZ"),
    "Nickel Blitz": _m("MAN", True, R, ["MAN"], ["PRESS"], ["BLITZ"], "DEEP_MID", "MAN", need_cb_in=True),
    "LB Dog": _m("MAN", True, R, ["BLITZ", "MAN", "BLITZ"], ["PRESS"], ["MAN"], "DEEP_MID", "MAN"),
    "Cross Fire": _m("ZONE", True, R, ["BLITZ", "BLITZ", "HOOK"], ["DEEP_THIRD"], ["FLAT"], "DEEP_MID", "FLAT"),
    "Zone Blitz DL Drop": _m("ZONE", True, ["RUSH", "HOOK", "HOOK", "RUSH"], ["BLITZ"], ["DEEP_THIRD"], ["FLAT"],
                             "DEEP_MID", "FLAT"),
    "All-Out Blitz": _m("MAN", True, R, ["BLITZ"], ["PRESS"], ["BLITZ"], "MAN", "BLITZ"),
    "Goal Line Base": _m("ZONE", False, R, ["FILL"], ["FLAT"], ["FLAT"], "ROBBER", "FILL"),
    "Goal Line Blitz": _m("ZONE", True, R, ["BLITZ"], ["FLAT"], ["FLAT"], "ROBBER", "BLITZ"),
    "Goal Line Man": _m("MAN", False, R, ["FILL"], ["PRESS"], ["MAN"], "MAN", "FILL"),
}


def build_defense(align, roles, spec, box):
    groups = {"DL": [], "LB": [], "CB": [], "FS": [], "SS": []}
    for lbl, role in roles.items():
        groups[role].append(lbl)
    moves = spec["moves"]
    cbs = sorted(groups["CB"], key=lambda l: align[l][1])
    if spec.get("need_cb_in") and len(cbs) <= 2:
        return None
    route = {}
    for role, default in (("DL", "RUSH"), ("LB", "HOOK")):
        lst = sorted(groups[role], key=lambda l: align[l][1])
        mv = moves.get(role) or [default]
        for i, l in enumerate(lst):
            route[l] = dmove(mv[i] if i < len(mv) else mv[-1], *align[l])
    for i, l in enumerate(cbs):
        outside = i == 0 or i == len(cbs) - 1
        if outside:
            lst = moves["CB_OUT"]
            k = lst[0] if i == 0 else lst[min(1, len(lst) - 1)]
        else:
            lst = moves["CB_IN"]
            k = lst[min(i - 1, len(lst) - 1)]
        route[l] = dmove(k, *align[l])
    for role in ("FS", "SS"):
        for l in groups[role]:
            route[l] = dmove(moves[role], *align[l])
    return {"coverage": spec["cov"], "blitz": spec["blitz"], "box": spec.get("box", box), "route": route}


# ----------------------------------------------------------------------------
# Generation
# ----------------------------------------------------------------------------
BUILTIN_FORMS = {"OFFENSE": {f[0] for f in OFF_FORMS}, "DEFENSE": {f[0] for f in DEF_FORMS}}


def generate_playbook():
    data = {"version": 3, "builtin_version": BUILD_VERSION,
            "FAVORITES": ["Gun Doubles / Mesh", "I-Form Pro / Power Right", "4-2-5 Nickel Over / Cover 3 Sky"],
            "OFFENSE": {}, "DEFENSE": {}}
    for name, group, qb, rb, te, w1, w2, w3, names in OFF_FORMS:
        align = copy.deepcopy(DEFAULT_ALIGN["OFFENSE"])
        align.update({"QB": list(qb), "RB": list(rb), "TE": list(te), "WR1": list(w1), "WR2": list(w2),
                      "WR3": list(w3)})
        plays = {}
        for cname in OFF_CONCEPTS[group]:
            for suffix, play in make_concept(align, cname):
                plays[f"{name} / {cname}{suffix}"] = play
        data["OFFENSE"][name] = {"alignment": align, "names": dict(names), "plays": plays}
    for name, group, box, pos, names, roles in DEF_FORMS:
        align = copy.deepcopy(DEFAULT_ALIGN["DEFENSE"])
        align.update({k: list(v) for k, v in pos.items()})
        rl = _roles(roles)
        plays = {}
        for cname in DEF_CONCEPTS[group]:
            play = build_defense(align, rl, DEF_SPECS[cname], box)
            if play:
                plays[f"{name} / {cname}"] = play
        data["DEFENSE"][name] = {"alignment": align, "names": dict(names), "plays": plays}
    return data


# ----------------------------------------------------------------------------
# Philosophies ("playbooks")
# ----------------------------------------------------------------------------
PHILOSOPHIES = {
    "OFFENSE": {
        "Spread RPO": dict(run_bias=0.0, desc="Shotgun and pistol, three-wide sets, zone-read, RPOs and bubble screens. "
                           "Plays at tempo and punishes light boxes.",
                           formations=["Gun Doubles", "Gun Trips Right", "Gun Trips Left", "Gun Bunch Right",
                                       "Gun Bunch Left", "Gun Ace", "Gun Y-Off Right", "Gun Empty Trey",
                                       "Pistol Doubles", "Pistol Trips Right", "Pistol Trips Left", "Pistol Ace"]),
        "Air Raid": dict(run_bias=-0.6, desc="Empty, trips and bunch looks with mesh, four verts, shallow cross and "
                         "levels. The offense lives on the quarterback's arm.",
                         formations=["Gun Doubles", "Gun Trips Right", "Gun Trips Left", "Gun Bunch Right",
                                     "Gun Bunch Left", "Gun Empty Trey", "Gun Empty Trey Left",
                                     "Gun Empty Quads Right", "Gun Empty Quads Left"]),
        "Pro Style": dict(run_bias=0.2, desc="Under-center I-form and singleback sets, play-action off the run, "
                          "and a multiple tight-end package.",
                          formations=["I-Form Pro", "I-Form Twins Right", "Strong I Right", "Offset I Left",
                                      "Singleback Ace", "Singleback Doubles", "Singleback Trips Right",
                                      "Singleback Twin TE", "Split Backs Pro", "Split Backs Flip", "Jumbo I",
                                      "Gun Ace", "Goal Line"]),
        "Power Run": dict(run_bias=0.5, desc="Two-back and two-tight-end sets that grind with power, counter, iso and "
                          "toss, then hit play-action shots.",
                          formations=["Gun Deuce", "Gun Deuce Close", "Gun Tight", "Gun Wing Right",
                                      "Pistol Strong Right", "Pistol Full House", "I-Form Pro", "Strong I Right",
                                      "Offset I Left", "Jumbo I", "Split Backs Pro", "Goal Line"]),
        "Pistol": dict(run_bias=0.15, desc="Quarterback close to the line with a back directly behind: inside and "
                       "outside zone, zone-read and play-action.",
                       formations=["Pistol Doubles", "Pistol Trips Right", "Pistol Trips Left", "Pistol Ace",
                                   "Pistol Strong Right", "Pistol Bunch Right", "Pistol Full House",
                                   "Pistol Flexbone", "Goal Line"]),
        "Triple Option": dict(run_bias=0.85, desc="Flexbone, wishbone and full-house sets. Triple option, midline and "
                              "speed option with the occasional deep play-action shot.",
                              formations=["Flexbone", "Wishbone", "Full House", "Wing-T Right", "Pistol Flexbone",
                                          "Pistol Full House", "Goal Line"]),
        "West Coast": dict(run_bias=-0.1, desc="Short, timed throws (slants, stick, snag, curl-flat) that set up play-"
                           "action and the intermediate game.",
                           formations=["Singleback Ace", "Singleback Doubles", "Singleback Trips Right",
                                       "Singleback Twin TE", "Split Backs Pro", "Split Backs Flip", "I-Form Pro",
                                       "Gun Doubles", "Gun Deuce", "Goal Line"]),
        "Multiple": dict(run_bias=0.0, desc="A balanced mix of shotgun, pistol and under-center looks.",
                         formations=["Gun Doubles", "Gun Trips Right", "Gun Ace", "Gun Deuce", "Pistol Doubles",
                                     "Pistol Strong Right", "I-Form Pro", "Singleback Ace", "Singleback Doubles",
                                     "Split Backs Pro", "Jumbo I", "Goal Line"]),
    },
    "DEFENSE": {
        "4-3 Over": dict(blitz=0.0, man=0.0, desc="Four down linemen, three linebackers, balanced run and pass "
                         "coverage with a nickel and dime package.",
                         formations=["4-3 Over", "4-3 Tite", "4-2-5 Nickel Over", "4-1-6 Dime", "Goal Line 5-3-3"]),
        "4-3 Under": dict(blitz=0.1, man=0.0, desc="Shaded front and wide-9 ends that create pass-rush and "
                          "single-gap pressure.",
                          formations=["4-3 Under", "4-3 Wide 9", "4-2-5 Nickel Under", "4-1-6 Dime", "Goal Line 5-3-3"]),
        "3-4 Base": dict(blitz=0.3, man=0.0, desc="Three linemen and four linebackers that disguise who rushes.",
                         formations=["3-4 Base", "3-4 Okie", "3-4 Eagle", "3-3-5 Stack", "4-2-5 Nickel Over",
                                     "3-2-6 Dime", "Goal Line 5-3-3"]),
        "4-2-5 Nickel": dict(blitz=0.0, man=0.0, desc="Five defensive backs as the base to defend spread offenses "
                             "without losing run fits.",
                             formations=["4-2-5 Nickel Over", "4-2-5 Nickel Under", "4-2-5 Wide 9", "4-1-6 Dime",
                                         "3-2-6 Dime", "2-4-5 Edge", "Goal Line 5-3-3"]),
        "3-3-5 Stack": dict(blitz=0.25, man=-0.2, desc="Three down linemen, stacked linebackers and extra "
                            "defensive backs with plenty of disguise.",
                            formations=["3-3-5 Stack", "3-3-5 Tite", "3-2-6 Dime", "4-2-5 Nickel Over",
                                        "Goal Line 5-3-3"]),
        "46 Pressure": dict(blitz=0.6, man=0.5, desc="Bear fronts and eight-man boxes that bring pressure and "
                            "dare you to throw.",
                            formations=["4-6 Bear", "4-4 Eagle", "4-3 Over", "Goal Line 5-3-3"]),
        "Press Man": dict(blitz=0.2, man=0.8, desc="Nickel and dime sets with corners pressed up and safeties "
                          "helping over the top.",
                          formations=["4-2-5 Nickel Over", "4-1-6 Dime", "4-3 Over", "3-2-6 Dime", "Goal Line 5-3-3"]),
        "Tampa 2 / Quarters": dict(blitz=-0.2, man=-0.6, desc="Disciplined zone shells that keep everything in front "
                                   "of the defense.",
                                   formations=["4-3 Over", "4-3 Under", "4-2-5 Nickel Under", "4-1-6 Dime",
                                               "Goal Line 5-3-3"]),
        "Multiple": dict(blitz=0.1, man=0.0, desc="A mix of four- and three-man fronts and sub packages.",
                         formations=["4-3 Over", "4-3 Under", "3-4 Base", "4-2-5 Nickel Over", "4-1-6 Dime",
                                     "3-3-5 Stack", "Goal Line 5-3-3"]),
    },
}

# Stylized default playbooks (offense, defense). Anything not listed is chosen from the team's ratings.
TEAM_BOOKS = {
    "Army": ("Triple Option", "4-3 Under"), "Navy": ("Triple Option", "4-3 Over"),
    "Air Force": ("Triple Option", "3-4 Base"), "Texas Tech": ("Air Raid", "4-2-5 Nickel"),
    "Wisconsin": ("Power Run", "3-4 Base"), "Iowa": ("Pro Style", "Tampa 2 / Quarters"),
    "Michigan": ("Power Run", "4-3 Under"), "Notre Dame": ("Pro Style", "4-3 Over"),
    "Oregon": ("Spread RPO", "4-2-5 Nickel"), "Georgia": ("Pro Style", "3-4 Base"),
    "Alabama": ("Pro Style", "3-4 Base"), "Ohio State": ("Spread RPO", "4-3 Over"),
}


def default_books(team, attrs):
    if team in TEAM_BOOKS:
        return {"OFFENSE": TEAM_BOOKS[team][0], "DEFENSE": TEAM_BOOKS[team][1]}
    off = list(PHILOSOPHIES["OFFENSE"])
    dfn = list(PHILOSOPHIES["DEFENSE"])
    h = sum(ord(ch) for ch in team)
    if attrs["OFF"] - attrs["DEF"] >= 3:
        off_pool = ["Spread RPO", "Air Raid", "Pistol", "Multiple"]
    elif attrs["DEF"] - attrs["OFF"] >= 3:
        off_pool = ["Pro Style", "Power Run", "West Coast", "Multiple"]
    else:
        off_pool = off
    return {"OFFENSE": off_pool[h % len(off_pool)], "DEFENSE": dfn[(h // 7) % len(dfn)]}


def visible_formations(data, side, book):
    forms = data[side]
    phil = PHILOSOPHIES[side].get(book)
    if not phil:
        return list(forms)
    names = set(phil["formations"])
    return [f for f in forms if f in names or f not in BUILTIN_FORMS[side]]


def book_names(side):
    return [FULL_LIBRARY] + list(PHILOSOPHIES[side])


# ----------------------------------------------------------------------------
# Persistence
# ----------------------------------------------------------------------------
def write_json_atomic(path, obj, compact=False):
    text = json.dumps(obj, separators=(",", ":")) if compact else json.dumps(obj, indent=2)
    storage.write_text(path, text)


def read_json(path):
    return json.loads(storage.read_text(path))


def normalize_play(side, name, p):
    p.setdefault("route", {})
    if side == "OFFENSE":
        p["is_run"] = bool(p.get("is_run", False))
        if p.get("target_receiver") not in LABELS["OFFENSE"]:
            p["target_receiver"] = "RB" if p["is_run"] else "WR1"
        if p.get("depth") not in DEPTHS:
            pts = p["route"].get(p["target_receiver"], [])
            reach = max((pt[0] for pt in pts), default=500) - 500
            p["depth"] = "SHORT" if reach < 130 else "MEDIUM" if reach < 260 else "DEEP"
        valid = RUN_STYLES if p["is_run"] else PASS_STYLES
        if p.get("style") not in valid:
            p["style"] = "INSIDE" if p["is_run"] else "DROPBACK"
    else:
        if p.get("coverage") not in ("MAN", "ZONE"):
            p["coverage"] = "ZONE"
        p["blitz"] = bool(p.get("blitz", False))
        if p.get("box") not in BOXES:
            p["box"] = "NORMAL"


def migrate_playbook(raw):
    """Accepts v1 (waypoints incl. start), v2 or v3 files and returns a clean v3 dict."""
    if raw.get("version", 1) >= 2:
        data = raw
    else:
        data = {"version": 2, "FAVORITES": list(raw.get("FAVORITES", []))}
        for side in SIDES:
            data[side] = {}
            for fname, plays in raw.get(side, {}).items():
                new_plays = {}
                for pname, p in plays.items():
                    p = dict(p)
                    wps = p.pop("waypoints", {})
                    p["route"] = {lbl: [list(pt) for pt in pts[1:]] for lbl, pts in wps.items()}
                    new_plays[pname] = p
                data[side][fname] = {"alignment": copy.deepcopy(DEFAULT_ALIGN[side]), "plays": new_plays}
    if data.get("builtin_version", 0) < BUILD_VERSION:  # add new built-in formations/plays, keep user data
        gen = generate_playbook()
        for side in SIDES:
            forms = data.setdefault(side, {})
            for fname, gform in gen[side].items():
                if fname not in forms:
                    forms[fname] = gform
                else:
                    for pname, play in gform["plays"].items():
                        forms[fname]["plays"].setdefault(pname, play)
                    forms[fname].setdefault("names", gform["names"])
        if not data.get("FAVORITES"):
            data["FAVORITES"] = gen["FAVORITES"]
    for side in SIDES:
        forms = data.setdefault(side, {})
        for fname, form in forms.items():
            align = form.setdefault("alignment", {})
            for lbl, pos in DEFAULT_ALIGN[side].items():
                align.setdefault(lbl, list(pos))
            form.setdefault("names", {})
            for pname, p in form.setdefault("plays", {}).items():
                normalize_play(side, pname, p)
    data.setdefault("FAVORITES", [])
    data["version"] = 3
    data["builtin_version"] = BUILD_VERSION
    return data


def load_playbook(path):
    data = None
    try:
        data = migrate_playbook(read_json(path))
    except FileNotFoundError:
        pass
    except Exception as exc:  # unreadable data: start fresh
        print(f"[playbook] could not read {path}: {exc}")
    if data is None:
        data = migrate_playbook(generate_playbook())
    try:
        write_json_atomic(path, data, compact=True)
    except Exception:
        pass
    return data
